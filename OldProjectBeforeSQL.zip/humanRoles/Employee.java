package humanRoles;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.time.LocalDate;

import dataBases.UserDataBase;

public class Employee extends Human {
	private int employeeNumber;
	private String username;

	public Employee(int employeeNumber, String ID, String firstName, String lastName, LocalDate dateOfBirth,
			String phoneNumber, String username) {
		super(ID, firstName, lastName, dateOfBirth, phoneNumber);
		this.employeeNumber = employeeNumber;
		this.username = username;
	}

	public boolean checkPassword(String password) {
		if (UserDataBase.getDB().checkValue(username, password))
			return true;
		else
			return false;
	}

	public int getNumber() {
		return employeeNumber;
	}

	public void setNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		return "[Employee] number:" + employeeNumber + ", ID:" + ID + ", first name:" + firstName + ", last name:"
				+ lastName + ", birth date:" + dateOfBirth + ", phone number:" + phoneNumber;
	}
}
