package visitorManagement;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import javax.swing.*;

import dataBases.EmployeeDataBase;
import dataBases.TicketDataBase;
import dataBases.UserDataBase;
import dataBases.VisitorDataBase;

import humanRoles.Employee;
import humanRoles.Visitor;
import ticket.Ticket;
import ticket.TicketOptionEnum;
import ticket.TicketStatusEnum;
import vistorDistributionGroup.VisitorDiscountDistribution;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.*;
import java.lang.Exception;
import java.time.LocalDate;
import java.time.LocalTime;

//class extends JFrame to create a window where our component add  
//class implements ActionListener to perform an action on button click  
public class EmployeeLoginForm extends JFrame implements ActionListener {
	/**
	 * 
	 */
	public static LocalDate loginDate;
	public static LocalTime loginTime;
	public static int cash = 0;
	public static int card = 0;
	public static String userValue;

	private static Employee david = new Employee(12345678, "312345987", "David", "Yakov", LocalDate.parse("1998-01-04"),
			"054-54567789", "davidbeny1");
	private static Employee kris = new Employee(23345566, "317958700", "Kristina", "Gold",
			LocalDate.parse("1998-08-05"), "054-7577584", "k");
	private static Employee test = new Employee(00000000, "00000000", "test", "test", LocalDate.parse("2002-01-14"),
			"000000000", "test");
	private static Visitor ben = new Visitor("123456789", "ben", "mor", LocalDate.parse("2023-01-04"), "054-6543465");
	private static Visitor ron = new Visitor("987654321", "ron", "win", LocalDate.parse("2003-12-04"), "054-6543465");
	private static Ticket t1 = new Ticket(12345, ben.getID(), TicketOptionEnum.Yearly_Adult,
			LocalDate.parse("2023-12-12"), TicketStatusEnum.ACTIVE, 0);
	private static Ticket t2 = new Ticket(21234, ben.getID(), TicketOptionEnum.Yearly_Couple_Plus_Five,
			LocalDate.parse("2023-10-30"), TicketStatusEnum.USED, 0);
	private static Ticket t3 = new Ticket(98372, ben.getID(), TicketOptionEnum.Basic_Special_And_Elderly,
			LocalDate.parse("2023-11-30"), TicketStatusEnum.ACTIVE, 0);

	private static final long serialVersionUID = 1L;

	private static EmployeeLoginForm systemLogin;

	// initialize button, panel, label, and text field
	JButton check;
	JPanel login;
	JLabel username, password, request, warning;
	final JTextField userText, passText;

	public synchronized static EmployeeLoginForm getSystemLogin() {
		if (systemLogin == null) {
			startBasicInfo();
			systemLogin = new EmployeeLoginForm();
		} else
			systemLogin = new EmployeeLoginForm();
		return systemLogin;
	}

	// private constructor
	private EmployeeLoginForm() {
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setAlwaysOnTop(true);
		setSize(400, 250);
		setLocationByPlatform(true);
		setVisible(true);
		setLocationRelativeTo(null);
		setTitle("Login");
		setResizable(false);

		login = new JPanel(null);
		add(login);

		request = new JLabel();
		request.setText("Please enter your credentials:");
		request.setBounds(48, 10, 220, 30);
		login.add(request);

		username = new JLabel();
		username.setText("Enter Username: ");
		username.setBounds(48, 57, 110, 30);
		login.add(username);

		userText = new JTextField(15);
		userText.setBounds(150, 58, 200, 30);
		login.add(userText);

		password = new JLabel();
		password.setText("Enter Password: ");
		password.setBounds(48, 100, 110, 30);
		login.add(password);

		passText = new JPasswordField(15);
		passText.setBounds(150, 100, 200, 30);
		login.add(passText);

		check = new JButton("Ok");
		check.setBounds(150, 150, 100, 30);
		check.setBorder(BorderFactory.createEtchedBorder());
		check.addActionListener(this);
		getRootPane().setDefaultButton(check);
		login.add(check);
		repaint();
	}

	private static void startBasicInfo() {
		EmployeeDataBase.getEmployeeDB().addEmployee(david);
		UserDataBase.getDB().addUser(david.getUsername(), "Ddby850918");
		EmployeeDataBase.getEmployeeDB().addEmployee(kris);
		UserDataBase.getDB().addUser(kris.getUsername(), "1");
		EmployeeDataBase.getEmployeeDB().addEmployee(test);
		UserDataBase.getDB().addUser(test.getUsername(), "123456");
		VisitorDataBase.getVisitorDB().addVisitor(ben);
		VisitorDataBase.getVisitorDB().addVisitor(ron);
		TicketDataBase.getTicketDB().addTicket(t1);
		TicketDataBase.getTicketDB().addTicket(t2);
		TicketDataBase.getTicketDB().addTicket(t3);
		ben.setDistribution(true);
		VisitorDiscountDistribution.getDistribution().addObserver(ben);
		ron.setDistribution(true);
		VisitorDiscountDistribution.getDistribution().addObserver(ron);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == check) {
			userValue = userText.getText();
			String passValue = passText.getText();
			for (Employee employee : EmployeeDataBase.getEmployeeDB().getEmployees()) {
				if (employee.getUsername().equalsIgnoreCase(userValue)) {
					if (UserDataBase.getDB().isUser(userValue) && employee.checkPassword(passValue)) {
						request.setText("The authentication was succesesful");
						loginDate = LocalDate.now();
						loginTime = LocalTime.now();
						dispose();
						try {
							// create instance of the VisitorManagmentMenu
							new VisitorManagementMenu();
						} catch (Exception ex) {
							JOptionPane.showMessageDialog(null, ex.getMessage());
						}
						return;
					}
				}
			}
			passText.requestFocusInWindow();
			passText.setText("");
			Toolkit.getDefaultToolkit().beep();
			request.setText("Wrong username/password");
			request.setForeground(Color.RED);
			repaint();
		}
	}
}