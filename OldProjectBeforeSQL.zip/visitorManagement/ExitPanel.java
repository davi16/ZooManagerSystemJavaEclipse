package visitorManagement;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import mainPackage.Application;
import mainPackage.MainMenu;

public class ExitPanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton exit;
	VisitorManagementMenu myMenu;

	ExitPanel(VisitorManagementMenu menu) {
		myMenu = menu;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		add(Box.createRigidArea(new Dimension(0, 10)));
		
		exit = new JButton("Exit");
		exit.setBorder(BorderFactory.createEtchedBorder());
		exit.setMaximumSize(new Dimension(100, 30));
		exit.setAlignmentX(CENTER_ALIGNMENT);
		exit.addActionListener(this);
		add(exit);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == exit) {
			new MainMenu();
			Application.inVisitorSystem = false;
			myMenu.exit();
		}
	}

}
