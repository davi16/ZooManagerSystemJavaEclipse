package mainPackage;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

import animalEnums.FishColorEnum;
import animalEnums.FishPrintEnum;
import animalEnums.FishTypeEnum;
import animalEnums.GenderEnum;
import animalExceptions.HigherThanLeaderException;
import animalExceptions.MaleTooOldInHerdExeption;
import animalExceptions.OlderThanMatriarchException;
import animalExceptions.PandaArrayFullException;
import animalSuperClasses.Fish;
import animalSuperClasses.Predator;
import animals.AquariumFish;
import animals.ClownFish;
import animals.Elephant;
import animals.GoldFish;
import animals.Lion;
import animals.Penguin;
import animals.Tiger;
import animals.Panda;
import dataStractures.PenguinLine;

public class Zoo {

	private Random random = new Random(); // New randomizer

	static final String ANSI_RESET = "\u001B[0m"; // Console text color reset
	static final String ANSI_GREEN = "\033[1;32m"; // Console green + BOLD text color
	static final String ANSI_RED = "\u001B[31m"; // Console red text color
	static final String ANSI_BOLD = "\u001B[1m"; // Console bold text

	static int pandasIndex = 0; // Index for pandas

	private String zooName, zooAdress; // Basic zoo info
	private PenguinLine penguinLine = new PenguinLine(); // Line of Penguins in the zoo
	private ArrayList<Predator> predators = new ArrayList<Predator>(); // List of all the predators in the zoo
	private ArrayList<Fish> aquarium = new ArrayList<Fish>(); // Aquarium of Fish in the zoo
	private LinkedList<Elephant> elephantHerd = new LinkedList<Elephant>(); // Elephant herd
	private Panda[] pandas = new Panda[8]; // Panda family

	public String getZooName() {
		// Returns the name of the zoo
		return zooName;
	}

	public void setZooName(String zooName) {
		// Sets the name of the zoo
		this.zooName = zooName;
	}

	public String getZooAddress() {
		// Returns the address of the zoo
		return zooAdress;
	}

	public void setZooAddress(String zooAddress) {
		// Sets the address of the zoo
		this.zooAdress = zooAddress;
	}

	/** Panda methods */

	private void removeNullPandas() {
		// Removes the null Pandas from the array
		Panda[] temp = new Panda[8];
		int counter = 0;
		for (Panda panda : pandas) {
			if (panda != null) {
				temp[counter] = panda;
				counter++;
			}
		}
		pandas = temp;
	}

	public void relapsePandas() {
		// Gets older Pandas ready to make a new baby
		for (Panda panda : pandas) {
			if (panda != null && panda.babyRelapseCounter > -1) {
				panda.babyRelapseCounter++;
				if (panda.babyRelapseCounter > 2) {
					panda.canMakeBaby = true;
				}
			}
		}
	}

	public String checkNewPandaBirth() {
		// Checking if there can be a new panda born, if true than creates a new Panda
		// and sets up the hierarchy of Pandas
		relapsePandas();
		if (pandas[pandas.length - 1] == null) {
			ArrayList<Integer> motherIndex = new ArrayList<>(), fatherIndex = new ArrayList<>();
			for (int i = 0; i < pandas.length; i++) {
				if (pandas[i] != null && pandas[i].canMakeBaby) {
					switch (pandas[i].getGender()) {
					case MALE:
						fatherIndex.add(i);
						break;
					case FEMALE:
						motherIndex.add(i);
						break;
					}
				}
			}
			if (!motherIndex.isEmpty() && !fatherIndex.isEmpty()) {
				int length = motherIndex.size() <= fatherIndex.size() ? motherIndex.size() : fatherIndex.size();
				for (int i = 0; i < length; i++) {
					if (pandas[motherIndex.get(i)].babyRelapseCounter > 2
							&& pandas[fatherIndex.get(i)].babyRelapseCounter > 2
							&& pandas[motherIndex.get(i)].canMakeBaby && pandas[fatherIndex.get(i)].canMakeBaby) {
						pandas[fatherIndex.get(i)].canMakeBaby = false;
						pandas[motherIndex.get(i)].canMakeBaby = false;
						int random = Math.random() > 0.5 ? 1 : 0;
						GenderEnum newGender;
						double minWeight = 0;
						int maxWeight = 0;
						switch (random) {
						case 0:
							newGender = GenderEnum.MALE;
							minWeight = 0.5;
							maxWeight = 5;
							break;
						case 1:
							newGender = GenderEnum.FEMALE;
							minWeight = 0.2;
							maxWeight = 3;
							break;
						default:
							throw new IllegalArgumentException("Unexpected value: " + random);
						}
						double newWeight = minWeight + (Math.random() * maxWeight);
						int newAge = 0;
						String newName = Application.generateRandomName().toString().replace("_", " ");
						Panda child = new Panda(newName, newAge, newWeight, newGender);
						child.setFather(pandas[fatherIndex.get(i)]);
						child.setMother(pandas[motherIndex.get(i)]);
						String output;
						try {
							setPanda(child);
							pandas[fatherIndex.get(i)].setChild(child);
							pandas[motherIndex.get(i)].setChild(child);
							pandas[fatherIndex.get(i)].babyRelapseCounter = 0;
							pandas[motherIndex.get(i)].babyRelapseCounter = 0;
							output = "The following panda was born: \n" + ANSI_RESET + child.toString(true) + "!\n";
						} catch (PandaArrayFullException e) {
							output = e.getMessage();
						}
						return output;
					}
				}
			}
			return " - No panda was born this year.\n";
		}
		return " - There is no more space for a newborn panda\n";
	}

	public Panda[] getPandas() {
		// Returns the array of Pandas
		return pandas;
	}

	public void setPanda(Panda newPanda) throws PandaArrayFullException {
		// Adds a new Panda to the array
		if (pandasIndex < pandas.length) {
			this.pandas[pandasIndex] = newPanda;
			pandasIndex++;
		} else {
			throw new PandaArrayFullException(
					ANSI_RED + ANSI_BOLD + "The Panda wasn't added to the zoo, the array is full" + ANSI_RESET);
		}
	}

	public String pandaNoise() {
		// Returns the noise all Pandas make
		String noise = "";
		for (Panda panda : pandas) {
			noise += panda.makeNoise() + " ";
		}
		return noise;
	}

	public double numberOfMealsPandas() {
		// Returns the number of bamboo all Pandas eat
		double bamboos = 0;
		for (Panda panda : pandas) {
			if (panda != null)
				bamboos += panda.feed();
		}
		return bamboos;
	}

	public int getNumberOfPandas() {
		// Returns the number of Pandas in the zoo
		int counter = 0;
		for (Panda panda : pandas) {
			if (panda != null) {
				counter++;
			}
		}
		return counter;
	}

	/** Elephant methods */

	public LinkedList<Elephant> getHerd() {
		return elephantHerd;
	}

	public int getNumberOfElephants() {
		// Returns the number of Elephants in herd
		return elephantHerd.size();
	}

	public void setElephant(Elephant elephant) {
		// sets hard-coded Elephants to the herd
		elephantHerd.add(elephant);
	}

	public void addElephant(Elephant newElephant) throws OlderThanMatriarchException, MaleTooOldInHerdExeption {
		// Adds new elephant
		if (newElephant.getAge() > getMatriarchAge())
			throw new OlderThanMatriarchException("You can't add a female elephant older than the matriarch\n"
					+ "Matriarch age is: " + getMatriarchAge());
		if (newElephant.getGender() == GenderEnum.MALE && newElephant.getAge() > Elephant.MAX_MALE_AGE)
			throw new MaleTooOldInHerdExeption(
					"You can't add a male elephant older then " + Elephant.MAX_MALE_AGE + " to the herd");
		elephantHerd.add(newElephant);
	}

	public int getMatriarchAge() {
		// Returns the age of the matriarch in the herd
		int max = 0;
		for (Elephant elephant : elephantHerd) {
			if (elephant.getGender() == GenderEnum.FEMALE && elephant.getAge() > max) {
				max = elephant.getAge();
			}
		}
		return max;
	}

	public void sortElephantsByAge() {
		// Sorts Elephants by age
		Comparator<Elephant> compareByAge = new Comparator<Elephant>() {

			@Override
			public int compare(Elephant elephant1, Elephant elephant2) {
				// Inner method to compare 2 specific Elephants
				int rv;
				if (elephant1.getAge() > elephant2.getAge()) {
					rv = -1;
				} else if (elephant1.getAge() < elephant2.getAge()) {
					rv = 1;
				} else
					rv = 0;
				return rv;
			}
		};
		Collections.sort(elephantHerd, compareByAge);
	}

	public String elephantNoise() {
		// Returns all the noise the Elephants make
		String noise = "";
		for (Elephant elephant : elephantHerd) {
			noise += elephant.makeNoise() + " ";
		}
		return noise;
	}

	public double numberOfMealsElephants() {
		// Returns the number of plants the Elephants ate
		double meals = 0;
		for (Elephant elephant : elephantHerd) {
			meals += elephant.feed();
		}
		return meals;
	}

	/** Penguin methods */

	public void setPenguin(Penguin penguin) {
		// sets hard-coded Penguins to the line
		this.penguinLine.add(penguin);
	}

	public void addPenguin(Penguin newPenguin) throws HigherThanLeaderException {
		// Adds a new Penguin to the line
		if (newPenguin.getHeight() > getLeaderHeight())
			throw new HigherThanLeaderException(
					"The penguin can't be higher than leader, Leader height: " + getLeaderHeight());
		this.penguinLine.add(newPenguin);
	}

	public void printPenguins() {
		// Prints all Penguins in the zoo
		this.penguinLine.printPenguins();
	}

	public double getLeaderHeight() {
		// Returns the height of the leader Penguin
		return this.penguinLine.getLeaderHeight();
	}

	public int countPenguinsInLine() {
		// Returns the number of Penguins there are in the zoo
		return this.penguinLine.countPenguinsInLine();
	}

	public double numberOfFishPenguins() {
		// Returns the number of fish the Penguins ate
		return this.penguinLine.feed();
	}

	public String penguinNoise() {
		// Making all penguins in the zoo make a noise
		return this.penguinLine.noise();
	}

	public void sortPenguinsByName() {
		// Rearranges the Penguins in the zoo by name
		this.penguinLine.sortByName();
	}

	public void sortPenguinsByHeight() {
		// Rearranges the Penguins in the zoo by height
		this.penguinLine.sortByHeight();
	}

	public void sortPenguinsByAge() {
		// Rearranges the Penguins in the zoo by age
		this.penguinLine.sortByAge();
	}

	/** Predator methods */

	public void setPredator(Predator newPredator) {
		// Adds a Lion to the zoo
		this.predators.add(newPredator);
	}

	public int getNumberOfLions() {
		// Returns the number of Lions there are in the zoo
		int counter = 0;
		for (Predator lion : predators) {
			if (lion instanceof Lion) {
				counter++;
			}
		}
		return counter;
	}

	public int getNumberOfTigers() {
		// Returns the number of Lions there are in the zoo
		int counter = 0;
		for (Predator tiger : predators) {
			if (tiger instanceof Tiger) {
				counter++;
			}
		}
		return counter;
	}

	public ArrayList<Predator> getPredators() {
		// Returns the data about all the predators in the zoo
		return this.predators;
	}

	public double numberOfMealsLions() {
		// Returns the number of meat the Lions ate
		double meals = 0;
		for (Predator lion : predators) {
			if (lion instanceof Lion) {
				meals += lion.feed();
			}
		}
		return meals;
	}

	public double numberOfMealsTigers() {
		// Returns the number of meat the Tiger ate
		double meals = 0;
		for (Predator tiger : predators) {
			if (tiger instanceof Tiger) {
				meals += tiger.feed();
			}
		}
		return meals;
	}

	public String lionNoise() {
		// Returns the noise the Lions make
		String noise = "";
		for (Predator lion : predators) {
			if (lion instanceof Lion) {
				noise += lion.makeNoise() + " ";
			}
		}
		return noise;
	}

	public String tigerNoise() {
		// Returns the noise the Tigers make
		String noise = "";
		for (Predator tiger : predators) {
			if (tiger instanceof Tiger) {
				noise += tiger.makeNoise() + " ";
			}
		}
		return noise;
	}

	/** Fish methods */

	public void setFish(Fish newFish) {
		// Adds a specific fish to the zoo
		aquarium.add(newFish);
	}

	public void addFish(int amount) {
		// Adds Random fish to aquarium
		int randomTypeIndex;
		for (int i = 0; i < amount; i++) {
			randomTypeIndex = random.nextInt(FishTypeEnum.values().length);
			FishTypeEnum fishType = FishTypeEnum.values()[randomTypeIndex];
			if (fishType == FishTypeEnum.AQUARIUM)
				aquarium.add(generateRandomAquariumFish());
			if (fishType == FishTypeEnum.GOLD)
				aquarium.add(generateRandomGoldFish());
			if (fishType == FishTypeEnum.CLOWN)
				aquarium.add(generateRandomClownFish());
		}
	}

	private AquariumFish generateRandomAquariumFish() {
		// Generates a random AquariumFish
		int randomPrint = random.nextInt(FishPrintEnum.values().length);
		FishPrintEnum fishPrint = FishPrintEnum.values()[randomPrint];
		if (fishPrint == FishPrintEnum.SMOOTH)
			return new AquariumFish(random.nextInt(AquariumFish.LIFESPAN), random.nextDouble(149.5) + 0.5, fishPrint,
					1);
		else
			return new AquariumFish(random.nextInt(AquariumFish.LIFESPAN), random.nextDouble(149.5) + 0.5, fishPrint,
					random.nextInt(4) + 1);
		// We think 4 colors in a single fish is enough
	}

	private GoldFish generateRandomGoldFish() {
		// Generates a random GoldFish
		return new GoldFish(random.nextInt(GoldFish.LIFESPAN), random.nextDouble(40.5) + 0.5);
	}

	private ClownFish generateRandomClownFish() {
		// Generates a random ClownFish
		return new ClownFish(random.nextInt(ClownFish.LIFESPAN), random.nextDouble(14.5) + 0.5);

	}

	public ArrayList<Fish> getAquarium() {
		// Returns the whole aquarium of Fish
		return this.aquarium;
	}

	public double numberOfMealsAquariumFish() {
		// Returns the number of portions the AquariumFish ate
		double meals = 0;
		for (Fish fish : aquarium) {
			if (fish instanceof AquariumFish) {
				meals += fish.feed();
			}
		}
		return meals;
	}

	public double numberOfMealsGoldFish() {
		// Returns the number of portions the GoldFish ate
		double meals = 0;
		for (Fish fish : aquarium) {
			if (fish instanceof GoldFish) {
				meals += fish.feed();
			}
		}
		return meals;
	}

	public double numberOfMealsClownFish() {
		// Returns the number of portions the ClownFish ate
		double meals = 0;
		for (Fish fish : aquarium) {
			if (fish instanceof ClownFish) {
				meals += fish.feed();
			}
		}
		return meals;
	}

	public int getNumberOfGoldFish() {
		// Returns the number of Gold fish there are in the zoo
		int count = 0;
		for (Fish fish : aquarium) {
			if (fish instanceof GoldFish)
				count++;
		}
		return count;
	}

	public int getNumberOfAquariumFish() {
		// Returns the number of Aquarium fish there are in the zoo
		int count = 0;
		for (Fish fish : aquarium) {
			if (fish instanceof AquariumFish)
				count++;
		}
		return count;
	}

	public int getNumberOfClownFish() {
		// Returns the number of Clown fish there are in the zoo
		int count = 0;
		for (Fish fish : aquarium) {
			if (fish instanceof ClownFish)
				count++;
		}
		return count;
	}

	public int getNumberOfAllFish() {
		// Returns the total number of Fish in the zoo
		return getNumberOfAquariumFish() + getNumberOfClownFish() + getNumberOfGoldFish();
	}

	public Collection<FishColorEnum> getAllColorsOfAllFish() {
		// Returns all colors of Fish in the zoo
		Collection<FishColorEnum> allColorsExistInFish = new HashSet<FishColorEnum>();
		for (Fish fish : aquarium) {
			for (int i = 0; i < fish.getFishColors().size(); i++) {
				allColorsExistInFish.add(fish.getFishColors().get(i));
			}
		}
		return allColorsExistInFish;
	}

	public String getDominantColorsOfAllFish() {
		// Returns the 2 most dominant Fish colors in the zoo
		FishColorEnum[] dominantColors = FishColorEnum.values();
		FishColorEnum temp;
		for (int i = 0; i < dominantColors.length; i++) {
			for (int j = i + 1; j < dominantColors.length; j++) {
				if (dominantColors[i].getCounter() > dominantColors[j].getCounter()) {
					temp = dominantColors[i];
					dominantColors[i] = dominantColors[j];
					dominantColors[j] = temp;
				}
			}
		}
		return dominantColors[dominantColors.length - 1].getCode() + dominantColors[dominantColors.length - 1].name()
				+ ANSI_RESET + " + " + dominantColors[dominantColors.length - 2].getCode()
				+ dominantColors[dominantColors.length - 2].name() + ANSI_RESET;
	}

	public String fishNoise() {
		// Returns the noise the Fish make
		String noise = "";
		for (Fish fish : aquarium) {
			noise += fish.makeNoise() + " ";
		}
		return noise;
	}

	/** Animal methods */

	public String ageAllAnimals() {
		// Returns a string representation of all animals saved in this zoo
		String output = "These are the animals that died because they got old:\n" + ANSI_RESET;
		String temp = output;
		Iterator<Fish> fishIterator = this.aquarium.iterator();
		while (fishIterator.hasNext()) {
			Fish fish = fishIterator.next();
			fish.ageOneYear();
			if (!fish.isAlive()) {
				output += fish.toString(true) + "\n";
				fishIterator.remove();
			}

		}
		Iterator<Predator> predatorIterator = this.predators.iterator();
		while (predatorIterator.hasNext()) {
			Predator predator = predatorIterator.next();
			predator.ageOneYear();
			if (!predator.isAlive()) {
				output += predator.toString(true) + "\n";
				predatorIterator.remove();
			}
		}
		output += this.penguinLine.ageAllPenguins(true);

		Iterator<Elephant> elephantIterator = this.elephantHerd.iterator();
		while (elephantIterator.hasNext()) {
			Elephant elephant = elephantIterator.next();
			elephant.ageOneYear();
			if (!elephant.isAlive()) {
				output += elephant.toString(true) + "\n";
				elephantIterator.remove();
			}
		}
		for (int i = 0; i < pandas.length; i++) {
			Panda panda = pandas[i];
			if (panda != null) {
				panda.ageOneYear();
				if (!panda.isAlive()) {
					output += panda.toString(true) + "\n";
					pandas[i] = null;
					pandasIndex--;
				}
			}
		}
		removeNullPandas();
		if (output.contentEquals(temp))
			return " - No animals died this year.\n";
		return output;
	}

	public String ageMaleElephants() {

		String output = "These are the male elephants reached their max age to be in herd and left the zoo:\n"
				+ ANSI_RESET;
		String temp = output;
		Iterator<Elephant> elephantIterator = this.elephantHerd.iterator();
		while (elephantIterator.hasNext()) {
			Elephant elephant = elephantIterator.next();
			if (elephant.getGender() == GenderEnum.MALE && elephant.getAge() > Elephant.MAX_MALE_AGE) {
				output += elephant.toString(true) + "\n";
				elephantIterator.remove();
			}
		}
		if (output == temp)
			return " - No male elephants left the herd this year.\n";
		return output;
	}

	public String makeAnimalsHungry() {
		// Makes the happiness of all animals in the zoo go down (representing them
		// getting hungry)
		String output = "These are the animals that died because they were hungry: \n";
		String temp = output;
		Iterator<Fish> fishIterator = this.aquarium.iterator();
		while (fishIterator.hasNext()) {
			Fish fish = fishIterator.next();
			fish.removeHappiness();
			if (!fish.isAlive()) {
				output += fish.toString(false) + "\n";
				fishIterator.remove();
			}

		}
		Iterator<Predator> predatorIterator = this.predators.iterator();
		while (predatorIterator.hasNext()) {
			Predator predator = predatorIterator.next();
			predator.removeHappiness();
			if (!predator.isAlive()) {
				output += predator.toString(false) + "\n";
				predatorIterator.remove();
			}
		}
		output += this.penguinLine.removeHappiness(false);

		Iterator<Elephant> elephantIterator = this.elephantHerd.iterator();
		while (elephantIterator.hasNext()) {
			Elephant elephant = elephantIterator.next();
			elephant.removeHappiness();
			if (!elephant.isAlive()) {
				output += elephant.toString(false) + "\n";
				elephantIterator.remove();
			}
		}
		for (int i = 0; i < pandas.length; i++) {
			Panda panda = pandas[i];
			if (panda != null) {
				panda.removeHappiness();
				if (!panda.isAlive()) {
					output += panda.toString(false) + "\n";
					pandas[i] = null;
					pandasIndex--;
				}
			}
		}
		removeNullPandas();
		if (output.contentEquals(temp)) {
			output = "All animals are fine, for now.\n";
		}
		return output;
	}

}
