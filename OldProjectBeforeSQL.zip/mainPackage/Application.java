package mainPackage;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

import animalEnums.*;
import animalExceptions.*;
import animalSuperClasses.*;
import animals.*;
import appInput.*;
import dataStractures.*;
import ticket.TicketPrice;
import ticket.TicketPriceMemento;
import visitorManagement.*;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public class Application {

	public static Zoo myZoo = new Zoo(); // Sets up a new zoo

	static Scanner input = new Scanner(System.in); // Input scanner from console

	static final String ANSI_BLUE = "\u001B[34m"; // Console blue text color
	static final String ANSI_RED = "\u001B[31m"; // Console red text color
	static final String ANSI_GREEN = "\033[1;32m"; // Console green + BOLD text color
	static final String ANSI_RESET = "\u001B[0m"; // Console black text color
	static final String ANSI_BOLD = "\u001B[1m"; // Console bold text

	static NumberFormat formatter = new DecimalFormat("#0.00"); // New decimal formatter

	static String newAnimalName = ""; // Holder of all new names from input
	static int newAnimalAge; // Holder of all new ages from input
	static double newPenguinHeight; // Holder of all new heights from input
	static double newAnimalWeight; // Holder of all new weights from input
	static GenderEnum newAnimalGender; // Holder of all new genders from input

	static double newFishLength; // Holder of all new fish lengths from input
	static FishPrintEnum newFishPrint; // Holder of all new fish prints from input
	static FishTypeEnum newFishType; // Holder of all new fish types from input

	static String mainInput; // Holder of all input from main method

	static Random random = new Random(); // New randomizer

	static PandaNameEnum[] pandaNameValues = PandaNameEnum.values(); // Array of all names available for Pandas

	public static TicketPrice price = new TicketPrice();
	public static TicketPriceMemento save = price.saveMemento();
	public static boolean inVisitorSystem = false;

	public static void main(String[] args) {
		// Starts the application

		/** Canceled for now */
//		MyTimerTask timerTask = new MyTimerTask();
//		// A reminder to feed the animals every minute and a half
//		try {
//			timerTask.timer.scheduleAtFixedRate(timerTask, 5 * 1000, 90 * 1000);
//		} catch (Exception e) {
//			// Catches any unexpected exception
//			e.getMessage();
//		}

		// Basic details
		myZoo.setZooName("KiDZoo");
		myZoo.setZooAddress("Mivtza Kadesh 38");
		// Setting up first 3 basic Penguins
		myZoo.setPenguin(new Penguin(200, 6, "Rut"));
		myZoo.setPenguin(new Penguin(20.8, 1, "Bob"));
		myZoo.setPenguin(new Penguin(50, 3, "Adam"));
		// Setting up first 4 basic Lions
		myZoo.setPredator(new Lion("David", 10, 260, GenderEnum.MALE));
		myZoo.setPredator(new Lion("Solomon", 12, 175, GenderEnum.MALE));
		myZoo.setPredator(new Lion("Esther", 14, 260, GenderEnum.FEMALE));
		myZoo.setPredator(new Lion("Elizabeth", 20, 150, GenderEnum.FEMALE));
		// Setting up first 4 basic tigers
		myZoo.setPredator(new Tiger("Goliath", 5, 260, GenderEnum.MALE));
		myZoo.setPredator(new Tiger("Balak", 1, 175, GenderEnum.MALE));
		myZoo.setPredator(new Tiger("Dlilah", 4, 260, GenderEnum.FEMALE));
		myZoo.setPredator(new Tiger("Eve", 13, 150, GenderEnum.FEMALE));
		// Setting up first 10 random Fishes
		myZoo.addFish(10);
		// Setting up elephant herd
		myZoo.setElephant(new Elephant("Matilda", 60, GenderEnum.FEMALE, 5000));
		myZoo.setElephant(new Elephant("Kira", 30, GenderEnum.FEMALE, 3000));
		myZoo.setElephant(new Elephant("Jojo", 3, GenderEnum.MALE, 2000));
		myZoo.setElephant(new Elephant("Moris", 15, GenderEnum.MALE, 1700));
		myZoo.setElephant(new Elephant("Bob", 12, GenderEnum.MALE, 3200));
		myZoo.setElephant(new Elephant("Camila", 22, GenderEnum.FEMALE, 3700));
		myZoo.setElephant(new Elephant("Papaya", 1, GenderEnum.FEMALE, 2000));
		myZoo.setElephant(new Elephant("Momo", 5, GenderEnum.MALE, 2300));
		myZoo.setElephant(new Elephant("Mary", 55, GenderEnum.FEMALE, 5600));
		// Setting up panda family
		try {
			myZoo.setPanda(new Panda("Mei Pong", 10, 90, GenderEnum.FEMALE));
			myZoo.setPanda(new Panda("Shinjo Greatpaw", 15, 110, GenderEnum.MALE));
		} catch (PandaArrayFullException e) {
			System.out.println(e.getMessage());
		}

		boolean wantToContinue = true; // Value to know if the user wants to quit the application
		String choice;

		while (wantToContinue) {
			// Setting up visible main menu for user
			if (!inVisitorSystem)
				new MainMenu();
			choice = input.nextLine().trim();
			System.out.println();

			// Main menu implementation
			switch (choice) {
			case "1":
				System.out.println(ANSI_GREEN + "Zoo name: " + ANSI_RESET + myZoo.getZooName() + ANSI_GREEN
						+ ".\nZoo adress: " + ANSI_RESET + myZoo.getZooAddress() + ".\nThis zoo has "
						+ myZoo.getNumberOfLions() + " Lions.\nThis zoo has " + myZoo.getNumberOfTigers()
						+ " Tigers.\nThis zoo has " + myZoo.countPenguinsInLine() + " Penguins.\nThis zoo has "
						+ myZoo.getNumberOfAquariumFish() + " Aquarium Fish.\nThis zoo has "
						+ myZoo.getNumberOfClownFish() + " Clown fish.\nThis zoo has " + myZoo.getNumberOfGoldFish()
						+ " Gold fish.\nThis zoo has " + myZoo.getNumberOfElephants() + " Elephants.\nThis zoo has "
						+ myZoo.getNumberOfPandas() + " Pandas." + ANSI_RESET);
				break;
			case "2":
				boolean penguinMenu = true;
				while (penguinMenu) {
					System.out.println(ANSI_BLUE + ANSI_BOLD);
					System.out.println("\t1 - Arrange Pinguins by name (Alphabetically)");
					System.out.println("\t2 - Arrange Pinguins by height (High to low)");
					System.out.println("\t3 - Arrange Pinguins by age (Young to old)");
					System.out.println("\t4 - Return to main menu");
					System.out.println("-----------------------------------------------------");
					System.out.print("\tEnter your choise (1-4) ----> " + ANSI_RESET);
					switch (input.nextLine().trim()) {
					case "1":
						myZoo.sortPenguinsByName();
						penguinMenu = false;
						System.out.println(ANSI_GREEN + "Arrangment by name selected successfully!" + ANSI_RESET);
						break;
					case "2":
						myZoo.sortPenguinsByHeight();
						penguinMenu = false;
						System.out.println(ANSI_GREEN + "Arrangment by height selected successfully!" + ANSI_RESET);
						break;
					case "3":
						myZoo.sortPenguinsByAge();
						penguinMenu = false;
						System.out.println(ANSI_GREEN + "Arrangment by age selected successfully!" + ANSI_RESET);
						break;
					case "4":
						penguinMenu = false;
						break;
					default:
						System.out.println(ANSI_RED + "Wrong input, Try again!\n" + ANSI_RESET);
					}
				}
				break;
			case "3":
				System.out.println(ANSI_GREEN + "The Penguins in the zoo are:" + ANSI_RESET);
				if (PenguinLine.arrangePinguinByName)
					System.out.println(ANSI_RED + "Arranged by name:" + ANSI_RESET);
				else if (PenguinLine.arrangePinguinByAge)
					System.out.println(ANSI_RED + "Arranged by age:" + ANSI_RESET);
				else if (PenguinLine.arrangePinguinByHeight)
					System.out.println(ANSI_RED + "Arranged by height:" + ANSI_RESET);
				myZoo.printPenguins();
				break;
			case "4":
				addPenguinToZoo();
				break;
			case "5":
				System.out.println(ANSI_GREEN + "The Predators in the zoo are:" + ANSI_RESET);
				for (Predator predator : myZoo.getPredators()) {
					System.out.println(predator.toString(true));
				}
				break;
			case "6":
				addPredatorToZoo();
				break;
			case "7":
				System.out.println(
						ANSI_GREEN + "The number of fish in the zoo: " + ANSI_RESET + myZoo.getNumberOfAllFish());
				System.out.println(ANSI_GREEN + "The colors exist in the fish are: " + ANSI_RESET);
				System.out.println(FishColorEnum.convertToColorfulList(myZoo.getAllColorsOfAllFish()).toString());
				System.out.println(ANSI_GREEN + "The two dominant colors are: " + ANSI_RESET);
				System.out.println(myZoo.getDominantColorsOfAllFish());
				System.out.println(ANSI_GREEN + "All fish in the zoo are: " + ANSI_RESET);
				for (Fish fish : myZoo.getAquarium()) {
					System.out.println(fish.toString(true));
				}
				break;
			case "8":
				addFishToZoo();
				break;
			case "9":
				myZoo.sortElephantsByAge();
				System.out.println(ANSI_GREEN + "The elephants walking in a line sorted by age: " + ANSI_RESET);
				myZoo.getHerd().forEach(elephant -> System.out.println(elephant.toString(true)));
				System.out.println();
				break;
			case "10":
				addElephantToZoo();
				break;
			case "11":
				System.out.println(ANSI_GREEN + "The Pandas in the zoo are:" + ANSI_RESET);
				for (Panda panda : myZoo.getPandas()) {
					if (panda != null)
						System.out.println(panda.toString(true));
				}
				break;
			case "12":
				addPandaToZoo();
				break;
			case "13":
				System.out.println(ANSI_RED + "You fed the animals in the zoo!!\n" + ANSI_GREEN + "The Lions ate "
						+ formatter.format(myZoo.numberOfMealsLions()) + " kilograms of meat.\nThe Tigers ate "
						+ formatter.format(myZoo.numberOfMealsTigers()) + " kilograms of meat.\nThe Penguins ate "
						+ myZoo.countPenguinsInLine() + " fishes.\nThe Aquarium Fish ate "
						+ formatter.format(myZoo.numberOfMealsAquariumFish()) + " portions of food.\nThe Gold Fish ate "
						+ myZoo.numberOfMealsGoldFish() + " portions of food.\nThe Clown Fish ate "
						+ myZoo.numberOfMealsClownFish() + " portions of food." + "\nThe Elephants ate "
						+ formatter.format(myZoo.numberOfMealsElephants())
						+ " kilograms of grass, plants and tree roots.\nThe Pandas ate "
						+ formatter.format(myZoo.numberOfMealsPandas()) + " bamboo." + ANSI_RESET);
				break;
			case "14":
				System.out.println(myZoo.fishNoise() + myZoo.lionNoise() + myZoo.tigerNoise() + myZoo.penguinNoise()
						+ myZoo.elephantNoise());
				break;
			case "15":
				System.out.print(ANSI_RED + myZoo.ageAllAnimals() + ANSI_RESET);
				System.out.print(ANSI_RED + myZoo.ageMaleElephants() + ANSI_RESET);
				System.out.println(ANSI_RED + myZoo.checkNewPandaBirth() + ANSI_RESET);
				System.out.println(ANSI_RED + ANSI_BOLD + "The whole zoo is a year older!" + ANSI_RESET);
				break;
			case "16":
				inVisitorSystem = true;
				EmployeeLoginForm.getSystemLogin();
				break;
			case "17":
				System.out.println(ANSI_RED + "Exiting!!!" + ANSI_RESET);
				wantToContinue = false;
				System.exit(0);
				break;
			default:
				System.out.println(ANSI_RED + "Wrong input, Try again!\n" + ANSI_RESET);

			}
		}
	}

	/** Panda Methods */

	private static void addPandaToZoo() {
		// Adding a new Panda to the zoo
		if (myZoo.getPandas()[myZoo.getPandas().length - 1] != null) {
			System.out.println("You reached maximum number of Pandas in the zoo.\n Maximum number is: "
					+ myZoo.getPandas().length);
			return;
		}
		System.out.println(ANSI_GREEN + "To add a Panda to the zoo you need to enter the Pandas:" + ANSI_RESET
				+ "\n1. Gender (M/F).\n2. Age (a whole number).\n3. Weight in kg (a number, whole/decimal).\n"
				+ ANSI_BLUE + "The Pandas name will be generated automatically.");
		System.out.print(ANSI_RED + ANSI_BOLD + "Press 'y' to continue:" + ANSI_RESET);
		if (input.nextLine().trim().equalsIgnoreCase("y")) {
			newAnimalName = generateRandomName().toString().replace("_", " ");
			;
			System.out.print("Enter your Pandas gender: ");
			newAnimalGender = ApplicationInputCheck.checkAnimalGender(input);
			System.out.print("Enter your Pandas age: ");
			newAnimalAge = ApplicationInputCheck.readNumberInRange(0, Panda.LIFESPAN, input,
					"Please enter Pandas age again (integer): ");
			System.out.print("Enter your Pandas weight in kg: ");
			newAnimalWeight = switch (newAnimalGender) {
			case MALE -> ApplicationInputCheck.readNumberInRange(100.0, 160.0, input,
					"Please enter male panda weight again (double): ");
			case FEMALE -> ApplicationInputCheck.readNumberInRange(70.0, 120.0, input,
					"Please enter female panda weight again (double): ");
			};
			confirmMamalInput("Panda");
			if (mainInput.equalsIgnoreCase("y")) {
				Panda newPanda = new Panda(newAnimalName, newAnimalAge, newAnimalWeight, newAnimalGender);
				try {
					myZoo.setPanda(newPanda);
					System.out.println(ANSI_GREEN + "The new Panda: " + ANSI_RESET + newPanda.toString(true)
							+ ANSI_GREEN + " was succesfully added to the zoo!" + ANSI_RESET);
				} catch (PandaArrayFullException e) {
					System.out.println(e.getMessage());
				}
			} else {
				System.out.println(ANSI_RED + ANSI_BOLD + "The operation cancelled successfully" + ANSI_RESET);
				System.out.println("Returning to menu...");
			}

		}
	}

	static PandaNameEnum generateRandomName() {
		// Generates a random name for a new Panda
		int randomIndex = random.nextInt(pandaNameValues.length);
		return pandaNameValues[randomIndex];
	}

	/** Mamal methods */

	private static void confirmMamalInput(String animal) {
		// Show input
		System.out.println(ANSI_GREEN + "The values you entered are : " + ANSI_RESET + "\nName: " + newAnimalName
				+ "\nGender: " + newAnimalGender.name() + "\nAge: " + newAnimalAge + "\nWeight: " + newAnimalWeight);
		System.out.println(ANSI_GREEN + "Press 'y' to add the " + animal
				+ ", press 'n' to cancel operation and return to menu" + ANSI_RESET);
		mainInput = input.nextLine().trim();
		// Confirm animal
		while (!mainInput.equalsIgnoreCase("y") && !mainInput.equalsIgnoreCase("n")) {
			System.out.println(ANSI_RED + "Wrong input, Try again" + ANSI_RESET);
			System.out.print("Enter choice again: ");
			mainInput = input.nextLine().trim();
		}
	}

	/** Elephant methods */

	private static void addElephantToZoo() {
		// Adding a new Elephant to the zoo
		if (myZoo.getNumberOfElephants() == Elephant.MAX_IN_HERD) {
			System.out.println(
					"You reached maximum number of elephants in herd.\n Maximum number is: " + Elephant.MAX_IN_HERD);
			return;
		}
		System.out.println(ANSI_GREEN + "To add an Elephant to the zoo you need to enter the Elephants:" + ANSI_RESET
				+ "\n1. Name (in letters a-z/A-Z).\n2. Gender (M/F).\n3. Age (a whole number).\n4. Weight in kg (a number, whole/decimal).");
		System.out.print(ANSI_RED + ANSI_BOLD + "Press 'y' to continue:" + ANSI_RESET);
		if (input.nextLine().trim().equalsIgnoreCase("y")) {
			System.out.print("Enter your Elephants name: ");
			newAnimalName = ApplicationInputCheck.checkAnimalName(input);
			System.out.print("Enter your Elephants gender: ");
			newAnimalGender = ApplicationInputCheck.checkAnimalGender(input);
			System.out.print("Enter your Elephants age: ");
			newAnimalAge = ApplicationInputCheck.readNumberInRange(0, Elephant.LIFESPAN, input,
					"Please enter Elephants age again (integer): ");
			System.out.print("Enter your Elephants weight in kg: ");
			newAnimalWeight = switch (newAnimalGender) {
			case MALE -> ApplicationInputCheck.readNumberInRange(1800.0, 6300.0, input,
					"Please enter male elephant weight again (double): ");
			case FEMALE -> ApplicationInputCheck.readNumberInRange(2700.0, 3600.0, input,
					"Please enter female elephant weight again (double): ");
			};
			confirmMamalInput("Elephant");
			if (mainInput.equalsIgnoreCase("y")) {
				Elephant newElephant = new Elephant(newAnimalName, newAnimalAge, newAnimalGender, newAnimalWeight);
				try {
					myZoo.addElephant(newElephant);
					System.out.println(ANSI_GREEN + "The new Elephant: " + ANSI_RESET + newElephant.toString(true)
							+ ANSI_GREEN + " was succesfully added to the zoo!" + ANSI_RESET);
				} catch (OlderThanMatriarchException e) {
					System.out.println(ANSI_RED + e.getMessage());
					System.out.println(ANSI_BOLD + "Elephant wasn't added to zoo.." + ANSI_RESET);
				} catch (MaleTooOldInHerdExeption a) {
					System.out.println(ANSI_RED + a.getMessage());
					System.out.println(ANSI_BOLD + "Elephant wasn't added to zoo.." + ANSI_RESET);
				}
			} else {
				System.out.println(ANSI_RED + ANSI_BOLD + "The operation cancelled successfully" + ANSI_RESET);
				System.out.println("Returning to menu...");
			}

		}

	}

	/** Predator methods */

	private static void addPredatorToZoo() {
		// Adding a new Predator to the zoo
		System.out.println(
				ANSI_GREEN + "To add a Predator to the zoo first choose if you want to enter a lion or a tiger: (l/t)"
						+ ANSI_RESET);
		try {
			char type = input.nextLine().trim().toLowerCase().charAt(0);
			if (type == 'l') {
				addLionToZoo();
			} else if (type == 't') {
				addTigerToZoo();
			} else
				throw new InputMismatchException();
		} catch (InputMismatchException e) {
			System.out.println(ANSI_RED + "Wrong input, Try again" + ANSI_RESET);
			addPredatorToZoo();
		}
	}

	private static void addTigerToZoo() {
		// Adding a new Tiger to the zoo
		System.out.println(ANSI_GREEN + "To add a Tiger to the zoo you need to enter the Tigers:" + ANSI_RESET
				+ "\n1. Name (in letters a-z/A-Z).\n2. Gender (M/F).\n3. Age (a whole number (0-15 for male).\n4. Weight in kg(a number, whole/decimal ( 90-310 for male, 65-170 for female).");
		System.out.print(ANSI_RED + ANSI_BOLD + "Press 'y' to continue:" + ANSI_RESET);
		if (input.nextLine().trim().equalsIgnoreCase("y")) {
			System.out.print("Enter your Tigers name: ");
			newAnimalName = ApplicationInputCheck.checkAnimalName(input);
			System.out.print("Enter your Tigers gender: ");
			newAnimalGender = ApplicationInputCheck.checkAnimalGender(input);
			System.out.print("Enter your Tigers age: ");
			newAnimalAge = ApplicationInputCheck.readNumberInRange(0, Predator.LIFESPAN, input,
					"Please enter Tiger age again (integer): ");
			System.out.print("Enter your Tigers weight: ");
			newAnimalWeight = switch (newAnimalGender) {
			case MALE -> ApplicationInputCheck.readNumberInRange((double) 150, (double) 258, input,
					"Please enter Tiger weight again (double): ");
			case FEMALE -> ApplicationInputCheck.readNumberInRange((double) 122, (double) 181, input,
					"Please enter Tiger weight again (double): ");
			};
			confirmMamalInput("Tiger");
			if (mainInput.equalsIgnoreCase("y")) {
				Animal newTiger = new Tiger(newAnimalName, newAnimalAge, newAnimalWeight, newAnimalGender);
				myZoo.setPredator((Tiger) newTiger);
				System.out.println(ANSI_GREEN + "The new Tiger: " + ANSI_RESET + newTiger.toString(true) + ANSI_GREEN
						+ " was succesfully added to the zoo!" + ANSI_RESET);
			} else {
				System.out.println(ANSI_RED + ANSI_BOLD + "The operation cancelled successfully" + ANSI_RESET);
				System.out.println("Returning to menu...");
			}
		}
	}

	private static void addLionToZoo() {
		// Adding a new Lion to the zoo
		System.out.println(ANSI_GREEN + "To add a Lion to the zoo you need to enter the Lions:" + ANSI_RESET
				+ "\n1. Name (in letters a-z/A-Z).\n2. Gender (M/F).\n3. Age (a whole number (0-10 for male, 0-16 for female).\n4. Weight in kg(a number, whole/decimal ( 150-258 for male, 122-181 for female).");
		System.out.print(ANSI_RED + ANSI_BOLD + "Press 'y' to continue:" + ANSI_RESET);
		if (input.nextLine().trim().equalsIgnoreCase("y")) {
			System.out.print("Enter your Lions name: ");
			newAnimalName = ApplicationInputCheck.checkAnimalName(input);
			System.out.print("Enter your Lions gender: ");
			newAnimalGender = ApplicationInputCheck.checkAnimalGender(input);
			System.out.print("Enter your Lions age: ");
			newAnimalAge = ApplicationInputCheck.readNumberInRange(0, Predator.LIFESPAN, input,
					"Please enter Lion age again (integer): ");
			System.out.print("Enter your Lions weight: ");
			newAnimalWeight = switch (newAnimalGender) {
			case MALE -> ApplicationInputCheck.readNumberInRange((double) 150, (double) 258, input,
					"Please enter Lion weight again (double): ");
			case FEMALE -> ApplicationInputCheck.readNumberInRange((double) 122, (double) 181, input,
					"Please enter Lion wieght again (double): ");
			};
			confirmMamalInput("Lion");
			if (mainInput.equalsIgnoreCase("y")) {
				Animal newLion = new Lion(newAnimalName, newAnimalAge, newAnimalWeight, newAnimalGender);
				myZoo.setPredator((Lion) newLion);
				System.out.println(ANSI_GREEN + "The new Lion: " + ANSI_RESET + newLion.toString(true) + ANSI_GREEN
						+ " was succesfully added to the zoo!" + ANSI_RESET);
			} else {
				System.out.println(ANSI_RED + ANSI_BOLD + "The operation cancelled successfully" + ANSI_RESET);
				System.out.println("Returning to menu...");
			}
		}
	}

	/** Fish methods */

	private static void addFishToZoo() {
		// Adding new Fishes to the zoo
		boolean wantMoreFish = true;
		while (wantMoreFish) {
			// Setting up visible Fish menu for user
			System.out.println(ANSI_BLUE + ANSI_BOLD);
			System.out.println("\t1 - Add one spesific fish");
			System.out.println("\t2 - Add a number of random fish");
			System.out.println("\t3 - Back to main menu");
			System.out.println("----------------------------------------------------------------");
			System.out.print("\tEnter your choise (1-3) ----> " + ANSI_RESET);
			// Fish menu implementation
			switch (input.nextLine().trim()) {
			case "1":
				System.out.println();
				System.out.println(ANSI_GREEN + "Enter a type of fish:" + ANSI_RESET);
				System.out.println("Your choices are: Gold / Aquarium / Clown ");
				newFishType = ApplicationInputCheck.checkFishType(input);
				if (newFishType == FishTypeEnum.AQUARIUM) {
					aquariumFishInput();
				}
				if (newFishType == FishTypeEnum.GOLD) {
					goldFishInput();
				}
				if (newFishType == FishTypeEnum.CLOWN) {
					clownFishInput();
				}
				break;
			case "2":
				System.out.println();
				System.out.println(ANSI_BLUE + "How many random fish do you want to add?" + ANSI_RESET);
				System.out.print(ANSI_RED + ANSI_BOLD + "Press 'y' to continue: " + ANSI_RESET);
				if (input.nextLine().trim().equalsIgnoreCase("y")) {
					System.out.println(ANSI_BLUE + "Enter a number:" + ANSI_RESET);
					String numberOfRandomFish = input.nextLine().trim();
					while (!numberOfRandomFish.matches("[0-9]+")) {
						System.out.println(ANSI_RED + "Invalid Input, Try Again " + ANSI_RESET);
						numberOfRandomFish = input.nextLine().trim();
					}
					myZoo.addFish(Integer.parseInt(numberOfRandomFish));
					for (int i = myZoo.getNumberOfAllFish() - Integer.parseInt(numberOfRandomFish); i < myZoo
							.getAquarium().size(); i++) {
						System.out.print(ANSI_GREEN + "The fish: " + ANSI_RESET);
						System.out
								.println(myZoo.getAquarium().get(i) + ANSI_GREEN + " Added successfully" + ANSI_RESET);
					}
				}
				System.out.println();
				break;
			case "3":
				wantMoreFish = false;
				break;
			default:
				System.out.println(ANSI_RED + "Wrong input, Try again!\n" + ANSI_RESET);
			}
		}

	}

	private static void confirmFishInput(ArrayList<FishColorEnum> tempList) {
		// Show input
		System.out.println(ANSI_GREEN + "The values you entered are : " + ANSI_RESET + "\nAge: " + newAnimalAge
				+ "\nLength: " + newFishLength + "\nPrint: " + newFishPrint.name() + "\nColors: "
				+ FishColorEnum.convertToColorfulList(tempList).toString());
		System.out.println(ANSI_GREEN + "Press 'y' to add the Fish, press 'n' to cancel operation and return to menu"
				+ ANSI_RESET);
		mainInput = input.nextLine().trim();
		// Confirm fish
		while (!mainInput.equalsIgnoreCase("y") && !mainInput.equalsIgnoreCase("n")) {
			System.out.println(ANSI_RED + "Wrong input, Try again" + ANSI_RESET);
			System.out.print("Enter choice again: ");
			mainInput = input.nextLine().trim();
		}
	}

	private static void aquariumFishInput() {
		// Adding a new AquariumFish to the zoo
		System.out.println(ANSI_GREEN + "To add an Aquarium fish into the zoo you need to enter the fishes: "
				+ ANSI_RESET + "\n1. Age (a whole number 0-" + AquariumFish.LIFESPAN
				+ ").\n2. Length in cm (a number, whole/decimal 0.5-150).\n3. Print (Spotted / Striped / Stained / Smooth).\n4. Color (Black / White / Green / Orange / Blue"
				+ " / Yellow / Brown / Gold / Red / Cyan).");
		System.out.print(ANSI_RED + ANSI_BOLD + "Press 'y' to continue:" + ANSI_RESET);
		if (input.nextLine().trim().equalsIgnoreCase("y")) {
			System.out.print("Enter age of the fish: ");
			newAnimalAge = ApplicationInputCheck.readNumberInRange(0, AquariumFish.LIFESPAN, input,
					"Please enter fish age again (integer): ");
			System.out.print("Enter length of the fish: ");
			newFishLength = ApplicationInputCheck.readNumberInRange(0.5, 150.0, input,
					"Please enter fish length again (double): ");
			System.out.print("Enter the print of the fish: ");
			newFishPrint = ApplicationInputCheck.checkFishPrint(input);
			System.out.println("Enter the colors of the fish: ");
			ArrayList<FishColorEnum> tempList = ApplicationInputCheck.checkFishColor(newFishType, newFishPrint, input);
			confirmFishInput(tempList);
			if (mainInput.equalsIgnoreCase("y")) {
				Animal newFish = new AquariumFish(newAnimalAge, newFishLength, tempList, newFishPrint);
				myZoo.setFish((AquariumFish) newFish);
				System.out.println(ANSI_GREEN + "The fish: " + ANSI_RESET + newFish.toString(true) + ANSI_GREEN
						+ " added successfully" + ANSI_RESET);
			} else {
				System.out.println(ANSI_RED + ANSI_BOLD + "The operation cancelled successfully" + ANSI_RESET);
				System.out.println("Returning to menu...");
			}
		}
	}

	private static void goldFishInput() {
		// Adding a new GoldFish to the zoo
		System.out.println(ANSI_GREEN + "To add a Gold fish into the zoo you need to enter the fishes: " + ANSI_RESET
				+ "\n1. Age (a whole number 0-" + GoldFish.LIFESPAN
				+ ").\n2. Length in cm (a number, whole/decimal 0.5-41).\n3. Color (Gold / Yellow / Orange / Black)");
		System.out.print(ANSI_RED + ANSI_BOLD + "Press 'y' to continue:" + ANSI_RESET);
		if (input.nextLine().trim().equalsIgnoreCase("y")) {
			System.out.print("Enter age of the fish: ");
			newAnimalAge = ApplicationInputCheck.readNumberInRange(0, GoldFish.LIFESPAN, input,
					"Please enter fish age again (integer): ");
			System.out.print("Enter length of the fish: ");
			newFishLength = ApplicationInputCheck.readNumberInRange(0.5, 41.0, input,
					"Please enter fish length again (double): ");
			newFishPrint = FishPrintEnum.SMOOTH;
			System.out.println("Enter the colors of the fish: ");
			ArrayList<FishColorEnum> tempList = ApplicationInputCheck.checkFishColor(newFishType, newFishPrint, input);
			confirmFishInput(tempList);
			if (mainInput.equalsIgnoreCase("y")) {
				Animal newFish = new GoldFish(newAnimalAge, newFishLength, tempList);
				myZoo.setFish((GoldFish) newFish);
				System.out.println(ANSI_GREEN + "The fish: " + ANSI_RESET + newFish.toString(true) + ANSI_GREEN
						+ " added successfully" + ANSI_RESET);
			} else {
				System.out.println(ANSI_RED + ANSI_BOLD + "The operation cancelled successfully" + ANSI_RESET);
				System.out.println("Returning to menu...");
			}
		}
	}

	private static void clownFishInput() {
		// Adding a new ClownFish to the zoo
		System.out.println(ANSI_GREEN + "To add a Clown fish into the zoo you need to enter the fishes: " + ANSI_RESET
				+ "\n1. Age (a whole number 0-" + ClownFish.LIFESPAN
				+ ").\n2. Length in cm (a number, whole/decimal 0.5-15).");
		System.out.print(ANSI_RED + ANSI_BOLD + "Press 'y' to continue:" + ANSI_RESET);
		if (input.nextLine().trim().equalsIgnoreCase("y")) {
			System.out.print("Enter age of the fish: ");
			newAnimalAge = ApplicationInputCheck.readNumberInRange(0, ClownFish.LIFESPAN, input,
					"Please enter fish age again (integer): ");
			System.out.print("Enter length of the fish: ");
			newFishLength = ApplicationInputCheck.readNumberInRange(0.5, 15.0, input,
					"Please enter fish length again (double): ");
			newFishPrint = FishPrintEnum.STRIPED;
			confirmFishInput(ClownFish.generateClownColors());
			if (mainInput.equalsIgnoreCase("y")) {
				Animal newFish = new ClownFish(newAnimalAge, newFishLength);
				myZoo.setFish((ClownFish) newFish);
				System.out.println(ANSI_GREEN + "The fish: " + ANSI_RESET + newFish.toString(true) + ANSI_GREEN
						+ " added successfully" + ANSI_RESET);
			} else {
				System.out.println(ANSI_RED + ANSI_BOLD + "The operation cancelled successfully" + ANSI_RESET);
				System.out.println("Returning to menu...");
			}
		}
	}

	/** Penguin methods */

	private static void addPenguinToZoo() {
		// Adding a new Penguin to the zoo
		System.out.println(ANSI_GREEN + "To add a Penguin into the zoo you need to enter the Penguins:" + ANSI_RESET
				+ "\n1. Name (in letters a-z/A-Z).\n2. Age (a whole number 0-" + Penguin.LIFESPAN
				+ ").\n3. Height in cm (a number, whole/decimal 15-200)." + ANSI_RESET);
		System.out.print(ANSI_RED + ANSI_BOLD + "Press 'y' to continue:" + ANSI_RESET);
		if (input.nextLine().trim().equalsIgnoreCase("y")) {
			System.out.print("Enter your Penguins name: ");
			newAnimalName = ApplicationInputCheck.checkAnimalName(input);
			System.out.print("Enter your Penguins age: ");
			newAnimalAge = ApplicationInputCheck.readNumberInRange(0, Penguin.LIFESPAN, input,
					"Please enter Penguin age again (integer): ");
			System.out.print("Enter your Penguins height: ");
			newPenguinHeight = ApplicationInputCheck.readNumberInRange((double) 15, (double) 1000, input,
					"Please enter Penguin height again (double): ");
			// Show input
			System.out.println(ANSI_GREEN + "The values you entered are : " + ANSI_RESET + "\nName: " + newAnimalName
					+ "\nAge: " + newAnimalAge + "\nHeight: " + newPenguinHeight);
			System.out.println(ANSI_GREEN
					+ "Press 'y' to add the Penguin, press 'n' to cancel operation and return to menu" + ANSI_RESET);
			mainInput = input.nextLine().trim();
			// Confirm penguin
			while (!mainInput.equalsIgnoreCase("y") && !mainInput.equalsIgnoreCase("n")) {
				System.out.println(ANSI_RED + "Wrong input, Try again" + ANSI_RESET);
				System.out.print("Enter choice again: ");
				mainInput = input.nextLine().trim();
			}
			if (mainInput.equalsIgnoreCase("y")) {
				Animal newPenguin = new Penguin(newPenguinHeight, newAnimalAge, newAnimalName);
				try {
					myZoo.addPenguin((Penguin) newPenguin);
					System.out.println(ANSI_GREEN + "The new Penguin: " + ANSI_RESET + newPenguin.toString(true)
							+ ANSI_GREEN + " was succesfully added to the zoo!" + ANSI_RESET);
				} catch (HigherThanLeaderException e) {
					System.out.println(ANSI_RED + e.getMessage());
					System.out.println(ANSI_BOLD + "Penguin wasn't added to zoo.." + ANSI_RESET);
				}
			} else {
				System.out.println(ANSI_RED + ANSI_BOLD + "The operation cancelled successfully" + ANSI_RESET);
				System.out.println("Returning to menu...");
			}
		}
	}
}
