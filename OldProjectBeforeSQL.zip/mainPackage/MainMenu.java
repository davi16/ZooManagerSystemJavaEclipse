package mainPackage;

public class MainMenu {
	//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

	static final String ANSI_BLUE = "\u001B[34m"; // Console blue text color
	static final String ANSI_RED = "\u001B[31m"; // Console red text color
	static final String ANSI_GREEN = "\033[1;32m"; // Console green + BOLD text color
	static final String ANSI_RESET = "\u001B[0m"; // Console black text color
	static final String ANSI_BOLD = "\u001B[1m"; // Console bold text

	public MainMenu() {
		System.out.println();
		System.out.println(ANSI_BLUE + ANSI_BOLD + "\t\t\t\t=====MENU=====");
		System.out.println("-----------------------------------------------------");
		System.out.println("\t1 - Display Zoo details");
		System.out.println("\t2 - Choose arrangment for Penguins");
		System.out.println("\t3 - Display all Penguins in zoo");
		System.out.println("\t4 - Add new Penguin");
		System.out.println("\t5 - Display all Predators in zoo");
		System.out.println("\t6 - Add new Predator");
		System.out.println("\t7 - Display all Fish in aquarium and all colors");
		System.out.println("\t8 - Add new Fish");
		System.out.println("\t9 - Display all Elephants in the herd");
		System.out.println("\t10 - Add new Elephant to herd");
		System.out.println("\t11 - Display all Pandas");
		System.out.println("\t12 - Add new Panda to zoo");
		System.out.println("\t13 - Feed all animals");
		System.out.println("\t14 - Listen to zoo animal noises");
		System.out.println("\t15 - Go forward one year");
		System.out.println("\t16 - Enter 'Visitor Managment System'");
		System.out.println("\t17 - Exit program");
		System.out.println("-----------------------------------------------------");
		System.out.print("\tEnter your choise (1-17) ----> " + ANSI_RESET);
	}
}
