package ticketHistory;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import visitorManagement.VisitorManagementMenu;

public class HistoryPanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTextField visitorID;
	JButton id, date;
	JLabel warning;
	VisitorManagementMenu myMenu;

	public HistoryPanel(VisitorManagementMenu menu) {
		myMenu = menu;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		add(Box.createRigidArea(new Dimension(0, 10)));
		setMaximumSize(new Dimension(300, 30));
		setAlignmentX(CENTER_ALIGNMENT);

		JLabel visitorId = new JLabel("How do you want to search ticket history?");
		visitorId.setAlignmentX(CENTER_ALIGNMENT);
		add(visitorId);
		
		JPanel inside = new JPanel();
		inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
		inside.setAlignmentX(CENTER_ALIGNMENT);
		inside.setMaximumSize(new Dimension(200, 30));
		add(inside);

		id = new JButton("By ID");
		id.setBorder(BorderFactory.createEtchedBorder());
		id.setMaximumSize(new Dimension(100, 30));
		id.addActionListener(this);
		inside.add(id);

		date = new JButton("By Date");
		date.setBorder(BorderFactory.createEtchedBorder());
		date.setMaximumSize(new Dimension(100, 30));
		date.addActionListener(this);
		inside.add(date);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == id) {
			removeAll();
			myMenu.printPurchaseHistory("ID");
			return;
		}
		if (e.getSource() == date) {
			removeAll();
			myMenu.printPurchaseHistory("Date");
			return;
		}
	}
}
