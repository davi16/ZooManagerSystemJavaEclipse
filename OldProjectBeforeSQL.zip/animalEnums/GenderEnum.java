package animalEnums;

public enum GenderEnum {
	//This enum contains all genders available for Mamals
	MALE, FEMALE;
}
