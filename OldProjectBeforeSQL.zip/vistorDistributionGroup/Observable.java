package vistorDistributionGroup;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public interface Observable {

	public void setChanged(boolean isChanged);
	public boolean isChanged();
	public void addObserver(Observer visitor);
	public void removeObserver(Observer visitor);
	public void notifyAllObservers();
	public int countObservers();
}