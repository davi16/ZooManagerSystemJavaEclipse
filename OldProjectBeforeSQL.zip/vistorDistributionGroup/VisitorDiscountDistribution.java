package vistorDistributionGroup;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class VisitorDiscountDistribution implements Observable{

	private boolean isChanged;
	private int discount;
    private List<Observer> observers;
    private static VisitorDiscountDistribution mailingDistribution;

	private VisitorDiscountDistribution() {
    	this.isChanged = false;
    	this.discount = 0;
    	this.observers = new ArrayList<>();
	}

	public synchronized static VisitorDiscountDistribution getDistribution() {
		if (mailingDistribution == null)
			mailingDistribution = new VisitorDiscountDistribution();
		return mailingDistribution;
	}

    @Override
    public void addObserver(Observer visitor) {
        this.observers.add(visitor);
    }

    @Override
    public void removeObserver(Observer visitor) {
        this.observers.remove(visitor);
    }
    

    public void setDiscount(int discount) {
    	if (discount != this.discount) {
    		this.discount = discount;
    		setChanged(true);
    	}
    }
    
    public int getDiscount() {
    	return discount;
    }

	@Override
	public void setChanged(boolean isChanged) {
		this.isChanged = isChanged;
		
	}

	@Override
	public boolean isChanged() {
		return isChanged;
	}

	@Override
	public void notifyAllObservers() {
		if (!isChanged)
			return;
		for (Iterator<Observer> it = observers.iterator(); it.hasNext();) {
			Observer observer = (Observer) it.next();
			observer.notify(this);
		}
		setChanged(false);
		
	}
	@Override
	public int countObservers() {
		return observers.size();
	}


	
}
