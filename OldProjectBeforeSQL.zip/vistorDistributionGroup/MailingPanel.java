package vistorDistributionGroup;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import mainPackage.Application;
import visitorManagement.VisitorManagementMenu;

public class MailingPanel extends JPanel implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTextField visitorID;
	JCheckBox zero, ten, twenty, thirty;
	JLabel warning;
	int discount;
	VisitorManagementMenu myMenu;

	public MailingPanel(VisitorManagementMenu menu) {
		myMenu = menu;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		add(Box.createRigidArea(new Dimension(0, 10)));

		JPanel inside = new JPanel();
		inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
		inside.setMaximumSize(new Dimension(300, 30));
		inside.setAlignmentX(CENTER_ALIGNMENT);
		add(inside);

		JLabel choose = new JLabel("How much discount?");
		choose.setMaximumSize(new Dimension(200, 30));
		choose.setAlignmentX(CENTER_ALIGNMENT);

		zero = new JCheckBox("0%");
		zero.setMaximumSize(new Dimension(200, 30));
		zero.setAlignmentX(CENTER_ALIGNMENT);
		zero.addActionListener(this);

		ten = new JCheckBox("10%");
		ten.setMaximumSize(new Dimension(200, 30));
		ten.setAlignmentX(CENTER_ALIGNMENT);
		ten.addActionListener(this);

		twenty = new JCheckBox("20%");
		twenty.setMaximumSize(new Dimension(200, 30));
		twenty.setAlignmentX(CENTER_ALIGNMENT);
		twenty.addActionListener(this);

		thirty = new JCheckBox("30%");
		thirty.setMaximumSize(new Dimension(200, 30));
		thirty.setAlignmentX(CENTER_ALIGNMENT);
		thirty.addActionListener(this);

		add(choose);
		add(zero);
		add(ten);
		add(twenty);
		add(thirty);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == zero) {
			removeAll();
			System.out.println(Application.save);
			myMenu.mailingSystem(0);
			myMenu.repaint();
		}
		if (e.getSource() == ten) {
			removeAll();
			System.out.println(Application.save);
			myMenu.mailingSystem(10);
			myMenu.repaint();
		}
		if (e.getSource() == twenty) {
			removeAll();
			System.out.println(Application.save);
			myMenu.mailingSystem(20);
			myMenu.repaint();
		}
		if (e.getSource() == thirty) {
			removeAll();
			System.out.println(Application.save);
			myMenu.mailingSystem(30);
			myMenu.repaint();
		}
	}
}
