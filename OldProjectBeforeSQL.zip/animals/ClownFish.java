package animals;

import java.util.ArrayList;

import animalEnums.FishColorEnum;
import animalEnums.FishPrintEnum;
import animalSuperClasses.Fish;

public class ClownFish extends Fish {
	public static final int LIFESPAN = 8;

	public ClownFish(int age, double length) {
		// Constructor for ClownFish
		super(age, length, generateClownColors(), FishPrintEnum.STRIPED);
	}

	/** Basic Methods */

	public static ArrayList<FishColorEnum> generateClownColors() {
		ArrayList<FishColorEnum> fishColors = new ArrayList<FishColorEnum>();
		fishColors.add(FishColorEnum.BLACK);
		fishColors.add(FishColorEnum.ORANGE);
		fishColors.add(FishColorEnum.WHITE);
		return fishColors;
	}

	/** All Overridden Methods */

	@Override
	public double feed() {
		// Returns the number of portions this Fish eats
		this.happiness = 100;
		return 2;
	}

	@Override
	public void ageOneYear() {
		// Ages this Fish by one year
		if (this.age >= LIFESPAN) {
			this.alive = false;
			this.happiness = 0;
			return;
		}
		removeHappiness();
		this.age++;
	}

}
