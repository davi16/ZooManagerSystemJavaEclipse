package animals;

import java.text.DecimalFormat;
import java.text.NumberFormat;

import animalSuperClasses.Animal;

public class Penguin implements Animal {
	// Penguins basic parameters
	private double height;
	private int age;
	private String name;
	public static final int LIFESPAN = 6;
	private boolean alive;
	private int happiness = 100;
	NumberFormat formatter = new DecimalFormat("#0.0");
	private final String ANSI_RESET = "\u001B[0m"; // Console black text color
	private final String ANSI_BOLD = "\u001B[1m";

	public Penguin(double height, int age, String name) {
		// Constructor
		this.age = age;
		this.height = height;
		this.name = name;
		this.alive = true;
	}

	/** Basic Methods */

	public double getHeight() {
		// Returns the height of the Penguin
		return height;
	}

	public void setHeight(double height) {
		// Sets the height of the Penguin
		this.height = height;
	}

	public int getAge() {
		// Returns the age of the Penguin
		return age;
	}

	public void setAge(int age) {
		// Sets the age of the Penguin
		this.age = age;
	}

	public String getName() {
		// Returns the name of the Penguin
		return name;
	}

	public void setName(String name) {
		// Sets the name of the Penguin
		this.name = name;
	}

	public boolean isAlive() {
		// Returns the state of this Penguin
		return alive;
	}

	public void setAlive(boolean alive) {
		// Sets the state of this Penguin
		this.alive = alive;
	}

	/** All Overridden Methods */

	@Override
	public double feed() {
		// Returns the amount of fish this Penguin eats
		this.happiness = 100;
		return 1;
	}

	@Override
	public String makeNoise() {
		// Returns the sound this Penguin makes
		return "squack";
	}

	@Override
	public void ageOneYear() {
		// Ages this Penguin by one year
		if (this.age >= LIFESPAN) {
			this.alive = false;
			this.happiness = 0;
			return;
		}
		removeHappiness();
		this.age++;
	}

	protected String happinessPrint() {
		// Changes the happiness print color based on its value
		if (happiness > 80)
			return "\033[0;32m" + happiness + "\033[0;30m";
		else if (happiness <= 80 && happiness > 60)
			return "\033[0;33m" + happiness + "\033[0;30m";
		else if (happiness <= 60 && happiness > 30)
			return "\033[0;91m" + happiness + "\033[0;30m";
		else
			return "\033[0;31m" + happiness + "\033[0;30m";
	}

	@Override
	public void removeHappiness() {
		// Removes happiness from this Penguin
		this.happiness -= Math.random() * 10;
		if (this.happiness < 1) {
			this.alive = false;
			this.happiness = 0;
		}
	}

	@Override
	public String toString(boolean consoleColor) {
		// Return all values of this Penguin in string format
		if (consoleColor) {
			return ANSI_BOLD + "Type: " + ANSI_RESET + getClass().getSimpleName() + ANSI_BOLD + " Name: " + ANSI_RESET
					+ this.name + ANSI_BOLD + " Age: " + ANSI_RESET + this.age + ANSI_BOLD + " Height: " + ANSI_RESET
					+ formatter.format(this.height) + ANSI_BOLD + " Happiness: " + ANSI_RESET + happinessPrint();
		} else {
			return "Type: " + getClass().getSimpleName() + " Name: " + this.name + " Age: " + this.age + " Height: "
					+ formatter.format(this.height) + " Happiness: " + happiness;
		}
	}
}
