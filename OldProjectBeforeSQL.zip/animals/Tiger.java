package animals;

import animalEnums.GenderEnum;
import animalSuperClasses.Predator;

public class Tiger extends Predator {

	public Tiger(String name, int age, double weight, GenderEnum gender) {
		// Constructor
		super(name, age, weight, gender);
	}

	/**All Overridden Methods */
	
	@Override
	public double feed() {
		// Returns the amount of meat this Tiger eats
		this.happiness = 100;
		return switch (this.gender) {
		case MALE -> (int) (double) this.weight * this.age * 0.02;
		case FEMALE -> (int) (double) this.weight * this.age * 0.03;
		};
	}

	@Override
	public String makeNoise() {
		// Returns the noise this Tiger makes
		return "roar";
	}

}
