package animalExceptions;

public class MaleTooOldInHerdExeption extends Exception {

	/**
	 * An exception for trying to add an Elephant older than the max age
	 */
	private static final long serialVersionUID = 1L;

	public MaleTooOldInHerdExeption(String errorMessage) {
		// Constructor
		super(errorMessage);
	}

}
