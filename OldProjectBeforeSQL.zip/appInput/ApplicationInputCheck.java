package appInput;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import animalEnums.FishColorEnum;
import animalEnums.FishPrintEnum;
import animalEnums.FishTypeEnum;
import animalEnums.GenderEnum;

public class ApplicationInputCheck {

	/**
	 * A helper Class for all input checks of the main application
	 */

	static final String ANSI_BLUE = "\u001B[34m"; // Console blue text color
	static final String ANSI_RED = "\u001B[31m"; // Console red text color
	static final String ANSI_GREEN = "\033[1;32m"; // Console green + BOLD text color
	static final String ANSI_RESET = "\u001B[0m"; // Console black text color
	static final String ANSI_BOLD = "\u001B[1m"; // Console bold text
	static NumberFormat formatter = new DecimalFormat("#0.00"); // New decimal formatter

	/** Basic Methods */

	public static String checkAnimalName(Scanner input) {
		// Checking if the input name is valid
		String newAnimalName = "";
		boolean finished = false;
		while (!finished) {
			try {
				newAnimalName = input.nextLine().trim();
				if (!newAnimalName.matches("[a-zA-Z]+"))
					throw new InputMismatchException();
				finished = true;

			} catch (InputMismatchException e) {
				System.out.println(ANSI_RED + "Invalid characters entered, try again." + ANSI_RESET);
				System.out.print("Enter your Animal name again: ");
			}

		}
		return capitalize(newAnimalName);
	}

	private static final String capitalize(String str) {
		// Capitalizes all the character in input String
		if (str == null || str.length() == 0)
			return str;
		return str.substring(0, 1).toUpperCase() + str.substring(1);
	}

	@SuppressWarnings("unchecked")
	public static <T extends Number> T readNumberInRange(T min, T max, Scanner input, String massage) {
		// Checks if the next input from console is between the range specified
		T value = null;
		boolean finished = false;
		while (!finished) {
			try {
				if (min instanceof Integer) {
					value = (T) Integer.valueOf(input.nextInt());
				} else if (min instanceof Double) {
					value = (T) Double.valueOf(input.nextDouble());
				} else if (min instanceof Long) {
					value = (T) Long.valueOf(input.nextLong());
				} else {
					System.out.println(ANSI_RED + "Wrong input, Try again" + ANSI_RESET);
				}
				if (min.doubleValue() <= value.doubleValue() && value.doubleValue() <= max.doubleValue()) {
					finished = true;
				} else {
					System.out.println(ANSI_RED + "Wrong input, Try again" + ANSI_RESET);
					System.out.print("Please enter a value between " + min + " and " + max + ": ");
				}
			} catch (InputMismatchException e) {
				System.out.println(ANSI_RED + "Wrong input, Try again" + ANSI_RESET);
				System.out.print(massage);
				input.nextLine();
			}
		}
		input.nextLine();
		return value;
	}

	public static FishTypeEnum checkFishType(Scanner input) {
		// Checks if the next input is a valid type of Fish
		FishTypeEnum newFishType = null;
		boolean finished = false;
		while (!finished) {
			try {
				newFishType = FishTypeEnum.valueOf(input.nextLine().trim().toUpperCase());
				finished = true;
			} catch (IllegalArgumentException a) {
				System.out.println(ANSI_RED + "Type doesn't exist, try again." + ANSI_RESET);
				System.out.println(ANSI_RED + "The options are: Aquarium / Gold / Clown" + ANSI_RESET);
				System.out.print("Enter fish type again: ");
			}
		}
		return newFishType;
	}

	public static FishPrintEnum checkFishPrint(Scanner input) {
		// Checking if the input print is valid
		FishPrintEnum newFishPrint = null;
		boolean finished = false;
		while (!finished) {
			try {
				newFishPrint = FishPrintEnum.valueOf(input.nextLine().trim().toUpperCase());
				finished = true;
			} catch (IllegalArgumentException a) {
				System.out.println(ANSI_RED + "Invalid input, try again." + ANSI_RESET);
				System.out.println(ANSI_RED + "The options are: Spotted / Striped / Stained / Smooth" + ANSI_RESET);
				System.out.print("Enter fish print again: ");
			}
		}
		return newFishPrint;

	}

	public static ArrayList<FishColorEnum> checkFishColor(FishTypeEnum newFishType, FishPrintEnum newFishPrint,
			Scanner input) {
		// Checking if the input color is valid, and if there can be another color added
		// to the fish
		ArrayList<FishColorEnum> tempColorList = new ArrayList<FishColorEnum>();
		int numberOfColors = 0;
		String color = "";
		if (newFishPrint != FishPrintEnum.SMOOTH) {
			System.out.println(ANSI_GREEN + "You can enter up to 4 colors" + ANSI_RESET);
			System.out.print("Enter a Color: ");
			color = input.nextLine().trim().toUpperCase();
			while (!color.equalsIgnoreCase("no")) {
				boolean finished = false;
				while (!finished) {
					try {
						if (!tempColorList.contains(FishColorEnum.valueOf(color))) {
							tempColorList.add(FishColorEnum.valueOf(color));
							numberOfColors++;
							System.out.println(ANSI_GREEN + "Color added successfully!" + ANSI_RESET);
							if (numberOfColors == 4)
								return tempColorList;
							System.out
									.print("Add another color: " + ANSI_BLUE + "(insert 'no' to finish) " + ANSI_RESET);
							color = input.nextLine().trim().toUpperCase();
						} else {
							System.out.println(ANSI_RED + "The color already exists, Try again" + ANSI_RESET);
							System.out
									.print("Add another color: " + ANSI_BLUE + "(insert 'no' to finish) " + ANSI_RESET);
							color = input.nextLine().trim().toUpperCase();
						}
						finished = true;
					} catch (IllegalArgumentException e) {
						System.out.println(ANSI_RED + "Color doesn't exist, Try again" + ANSI_RESET);
						System.out.println(ANSI_RED
								+ "The options are: Black / White / Green / Orange / Blue / Yellow / Brown / Gold / Red / Cyan "
								+ ANSI_RESET);
						color = input.nextLine().trim().toUpperCase();
					}
				}
			}
			return tempColorList;
		} else {
			if (newFishType == FishTypeEnum.GOLD) {
				System.out.println(ANSI_GREEN
						+ "You can enter only one color (Gold / Yellow / Orange / Black) because your fish type is Gold"
						+ ANSI_RESET);
				color = input.nextLine().trim().toUpperCase();
				boolean finished = false;
				while (!finished) {
					try {
						if (FishColorEnum.goldFishColors().contains(FishColorEnum.valueOf(color))) {
							tempColorList.add(FishColorEnum.valueOf(color));
							finished = true;
						} else
							throw new IllegalArgumentException();
					} catch (IllegalArgumentException e) {
						System.out.println(ANSI_RED + "Incorrect color input, Try again" + ANSI_RESET);
						System.out.println(ANSI_RED + "The options are : Gold / Yellow / Orange / Black" + ANSI_RESET);
						System.out.print("Enter fish color again: ");
						color = input.nextLine().trim().toUpperCase();
					}
				}
				return tempColorList;
			} else {
				System.out
						.println(ANSI_GREEN + "You can enter only one color (Your fish print is Smooth)" + ANSI_RESET);
				color = input.nextLine().trim().toUpperCase();
				boolean finished = false;
				while (!finished) {
					try {
						tempColorList.add(FishColorEnum.valueOf(color));
						finished = true;
					} catch (IllegalArgumentException e) {
						System.out.println(ANSI_RED + "Color doesn't exist, Try again" + ANSI_RESET);
						System.out.println(ANSI_RED
								+ "The options are: Black / White /Green / Orange / Blue / Yellow / Brown /Gold /Red / Cyan "
								+ ANSI_RESET);
						System.out.print("Enter fish color again: ");
						color = input.nextLine().trim().toUpperCase();
					}
				}
				return tempColorList;
			}
		}
	}

	public static GenderEnum checkAnimalGender(Scanner input) {
		// Checking if the input gender is valid
		GenderEnum newAnimalGender = null;
		boolean finished = false;
		while (!finished) {
			try {
				char gender = input.nextLine().trim().toLowerCase().charAt(0);
				if (gender == 'm') {
					newAnimalGender = GenderEnum.MALE;
					finished = true;
				} else if (gender == 'f') {
					newAnimalGender = GenderEnum.FEMALE;
					finished = true;
				} else {
					throw new InputMismatchException();
				}
			} catch (InputMismatchException e) {
				System.out.println(ANSI_RED + "Invalid characters entered, try again." + ANSI_RESET);
				System.out.println(ANSI_RED + "Your options are M/F" + ANSI_RESET);
				System.out.print("Enter your Lions gender again: ");
			}

		}
		return newAnimalGender;
	}
}
