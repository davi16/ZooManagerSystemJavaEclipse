package dataBases;

//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921
import java.util.HashSet;
import java.util.Set;
import humanRoles.Employee;

public class EmployeeDataBase {

	private Set<Employee> employees;
	private static EmployeeDataBase emploDataBase;

	private EmployeeDataBase() {
		this.employees = new HashSet<Employee>();
	}

	public synchronized static EmployeeDataBase getEmployeeDB() {
		if (emploDataBase == null)
			emploDataBase = new EmployeeDataBase();
		return emploDataBase;
	}

	public void addEmployee(Employee employee) {
		employees.add(employee);
	}

	public Set<Employee> getEmployees() {
		return employees;
	}

	public boolean isEmployee(Employee employee) {
		return employees.contains(employee);
	}

	public boolean isEmployeeByID(String ID) {
		for (Employee employee : employees) {
			if (employee.getID().compareTo(ID) == 0)
				return true;
		}
		return false;
	}

	public Employee getEmployeeByUser(String user) {
		for (Employee employee : employees) {
			if (employee.getUsername().compareTo(user) == 0)
				return employee;
		}
		return null;
	}

}
