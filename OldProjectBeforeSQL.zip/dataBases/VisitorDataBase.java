package dataBases;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.util.HashSet;
import java.util.Set;

import humanRoles.Visitor;
import vistorDistributionGroup.VisitorDiscountDistribution;

public class VisitorDataBase {

	private Set<Visitor> visitiors;
	private static VisitorDataBase visitorDataBase;
	public static VisitorDiscountDistribution distributionGroup;

	private VisitorDataBase() {
		this.visitiors = new HashSet<Visitor>();
	}

	public synchronized static VisitorDataBase getVisitorDB() {
		if (visitorDataBase == null) {
			visitorDataBase = new VisitorDataBase();
		}
		return visitorDataBase;
	}

	public void addVisitor(Visitor visitor) {
		visitiors.add(visitor);
		if(visitor.isDistribution == true)
			VisitorDiscountDistribution.getDistribution().addObserver(visitor);
	}
	
	public Set<Visitor> getVisitors(){
		return visitiors;
	}

	public boolean isVisitor(Visitor visitor) {
		return visitiors.contains(visitor);
	}

	public boolean isID(String ID) {
		for (Visitor visitor : visitiors) {
			if (visitor.getID().compareTo(ID) == 0)
				return true;
		}
		return false;
	}
	
	public Visitor getVisitorByID(String ID) {
		for (Visitor visitor : visitiors) {
			if (visitor.getID().compareTo(ID) == 0)
				return visitor;
		}
		return null;
	}

}
