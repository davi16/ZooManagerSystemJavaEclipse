package dataBases;

import java.time.LocalDate;
import java.util.ArrayList;

import parkEntrance.*;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public class EntranceDataBase {

	private ArrayList<Entrance> allEntrances;
	private static EntranceDataBase entranceDB;

	private EntranceDataBase() {
		this.allEntrances = new ArrayList<Entrance>();
	}

	public synchronized static EntranceDataBase getEntranceDB() {
		if (entranceDB == null)
			entranceDB = new EntranceDataBase();
		return entranceDB;
	}
	
	
	public void addEntrance(Entrance entrance) {
		allEntrances.add(entrance);
	}
	
	public ArrayList<Entrance> searchEntranceByID(String ID){
		ArrayList<Entrance> entranceByID = new ArrayList<Entrance>();
		for(Entrance entrance : allEntrances) {
			if(entrance.getTicket().getHolderID().compareTo(ID)==0)
				entranceByID.add(entrance);
		}
		return entranceByID;
	}
	
	public ArrayList<Entrance> searchEntranceByDate(LocalDate date){
		ArrayList<Entrance> entrancesByDate = new ArrayList<Entrance>();
		for(Entrance entrance : allEntrances) {
			if(entrance.getEntranceDate().isEqual(date))
				entrancesByDate.add(entrance);
		}
		return entrancesByDate;
	}

}
