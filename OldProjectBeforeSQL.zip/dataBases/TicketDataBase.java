package dataBases;

import java.time.LocalDate;
import java.util.ArrayList;

import ticket.Ticket;
import ticket.TicketStatusEnum;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public class TicketDataBase {
	
	private ArrayList<Ticket> allTickets;
	private static TicketDataBase ticketDB;

	private TicketDataBase() {
		this.allTickets = new ArrayList<Ticket>();
	}

	public synchronized static TicketDataBase getTicketDB() {
		if (ticketDB == null)
			ticketDB = new TicketDataBase();
		return ticketDB;
	}
	public void addTicket(Ticket ticket) {
		allTickets.add(ticket);
	}

	
	public ArrayList<Ticket> searchTicketsByID(String ID){
		ArrayList<Ticket> ticketsByID = new ArrayList<Ticket>();
		for(Ticket ticket : allTickets) {
			if(ticket.getHolderID().compareTo(ID)==0)
				ticketsByID.add(ticket);
		}
		return ticketsByID;
	}
	
	public ArrayList<Ticket> searchTicketsByDate(LocalDate date){
		ArrayList<Ticket> ticketsByDate = new ArrayList<Ticket>();
		for(Ticket ticket : allTickets) {
			if(ticket.getCreationDate().isEqual(date))
				ticketsByDate.add(ticket);
		}
		return ticketsByDate;
	}
	
	public ArrayList<Ticket> activeTicketsByID(String ID){
		ArrayList<Ticket> activeTicketsByID = new ArrayList<Ticket>();
		for(Ticket ticket : searchTicketsByID(ID)) {
			if(ticket.getStatus() == TicketStatusEnum.ACTIVE)
				activeTicketsByID.add(ticket);
		}
		return activeTicketsByID;
	}
	
	public ArrayList<Ticket> canCancelTicketsByID(String ID){
		ArrayList<Ticket> canCancelTicketsByID = new ArrayList<Ticket>();
		for(Ticket ticket : searchTicketsByID(ID)) {
			if(ticket.getStatus() == TicketStatusEnum.ACTIVE && ticket.isCanCancel() == true)
				canCancelTicketsByID.add(ticket);
		}
		return canCancelTicketsByID;
	}
	

}
