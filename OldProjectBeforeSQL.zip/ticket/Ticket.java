package ticket;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.time.LocalDate;

public class Ticket {
	private int number;
	private String holderID;
	private TicketOptionEnum type;
	private int price;
	private boolean canCancel;
	private LocalDate creationDate;
	private LocalDate expirationDate;
	private TicketStatusEnum status;

	public Ticket(int number, String holderID, TicketOptionEnum type, LocalDate creationDate, TicketStatusEnum status, int state) {
		// Constructor for general ticket in database
		this.number = number;
		this.holderID = holderID;
		this.type = type;
		this.price = (int)(type.getPrice() - ((double)type.getPrice() / 100) * state);
		this.creationDate = creationDate;
		this.expirationDate = creationDate.plusYears(1);
		this.status = status;
		this.canCancel = this.status.canCancel();
	}

	public Ticket(int number, String holderID, TicketOptionEnum type, int state) {
		// Constructor for new ticket created
		this.number = number;
		this.holderID = holderID;
		this.type = type;
		this.price = (int)(type.getPrice() - ((double)type.getPrice() / 100) * state);
		this.creationDate = LocalDate.now();
		this.expirationDate = LocalDate.now().plusYears(1);
		this.status = TicketStatusEnum.ACTIVE;
		this.canCancel = this.status.canCancel();
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getHolderID() {
		return holderID;
	}

	public void setHolderID(String holderID) {
		this.holderID = holderID;
	}

	public TicketOptionEnum getType() {
		return type;
	}

	public void setType(TicketOptionEnum type) {
		this.type = type;
	}

	public boolean isCanCancel() {
		return canCancel;
	}

	public void setCanCancel(boolean canCancel) {
		this.canCancel = canCancel;
	}

	public LocalDate getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(LocalDate creationDate) {
		this.creationDate = creationDate;
	}

	public LocalDate getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(LocalDate expirationDate) {
		this.expirationDate = expirationDate;
	}

	public TicketStatusEnum getStatus() {
		return status;
	}

	public void setStatus(TicketStatusEnum status) {
		this.status = status;
		setCanCancel(status.canCancel());
	}

	@Override
	public String toString() {
		return "[Ticket] number:" + number + ", holderID:" + holderID + ", type:" + type + ", price:" + price
				+ ", status:" + status + ", creationDate:" + creationDate + ", expirationDate:" + expirationDate;
	}

}
