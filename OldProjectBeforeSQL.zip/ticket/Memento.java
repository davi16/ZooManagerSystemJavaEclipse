package ticket;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public interface Memento {
	public void restoreMemento();
}
