package ticket;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public enum TicketStatusEnum {

	ACTIVE(true), CANCELED(false), USED(false), EXPIRED(false);

	private boolean canCancel;
	
	private TicketStatusEnum(boolean canCancel) {
		this.canCancel = canCancel;
	}
	
	public boolean canCancel() {
		return canCancel;
	}
}
