package visitorPayment;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921
import visitorManagement.EmployeeLoginForm;

public class Cash {
	
	public void charge(int amount) {
		// Cash specific payment processing logic
		EmployeeLoginForm.cash =+ amount;
		System.out.println("Paid ₪" + amount + " via Cash.");
	}
}
