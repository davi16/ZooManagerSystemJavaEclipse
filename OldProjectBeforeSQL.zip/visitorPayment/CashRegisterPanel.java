package visitorPayment;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import dataBases.EmployeeDataBase;
import humanRoles.Employee;
import visitorManagement.EmployeeLoginForm;
import visitorManagement.VisitorManagementMenu;

public class CashRegisterPanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton again;
	VisitorManagementMenu myMenu;
	int observers;

	public CashRegisterPanel(VisitorManagementMenu menu) {
		myMenu = menu;
		setAlignmentX(CENTER_ALIGNMENT);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		Employee employee = EmployeeDataBase.getEmployeeDB().getEmployeeByUser(EmployeeLoginForm.userValue);
		JLabel em = new JLabel(employee.toString());
		em.setAlignmentX(CENTER_ALIGNMENT);
		add(Box.createRigidArea(new Dimension(0, 50)));

		JLabel space = new JLabel("---------------------------------------------------------");
		space.setAlignmentX(CENTER_ALIGNMENT);
		
		JLabel date = new JLabel("Login date: " + EmployeeLoginForm.loginDate);
		date.setAlignmentX(CENTER_ALIGNMENT);
		date.setMaximumSize(new Dimension(300, 30));

		JLabel time = new JLabel("Login time: " + EmployeeLoginForm.loginTime);
		time.setAlignmentX(CENTER_ALIGNMENT);
		time.setMaximumSize(new Dimension(300, 30));

		JLabel cash = new JLabel("Cash in register: " + EmployeeLoginForm.cash + "₪");
		cash.setAlignmentX(CENTER_ALIGNMENT);
		cash.setMaximumSize(new Dimension(300, 30));
		

		JLabel card = new JLabel("Credit Card charge : " + EmployeeLoginForm.card + "₪");
		card.setAlignmentX(CENTER_ALIGNMENT);
		card.setMaximumSize(new Dimension(300, 30));
	

		JPanel inside = new JPanel();
		inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
		inside.setAlignmentX(CENTER_ALIGNMENT);
		inside.setMaximumSize(new Dimension(200, 30));
		
		again = new JButton("Go Back");
		again.setBorder(BorderFactory.createEtchedBorder());
		again.setMaximumSize(new Dimension(100, 30));
		again.setAlignmentX(CENTER_ALIGNMENT);
		again.addActionListener(this);

		inside.add(again);
		add(em);
		add(space);
		add(date);
		add(time);
		add(cash);
		add(card);
		add(inside);
		
		myMenu.repaint();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		myMenu.dispose();
		myMenu = new VisitorManagementMenu();
		myMenu.repaint();
		return;

	}

}
