package visitorPayment;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public class CashAdapter implements PaymentGateway {
    private Cash paymentGateway;

    public CashAdapter(Cash paymentGateway) {
        this.paymentGateway = paymentGateway;
    }

    @Override
    public void processPayment(int amount) {
        paymentGateway.charge(amount);
    }

}
