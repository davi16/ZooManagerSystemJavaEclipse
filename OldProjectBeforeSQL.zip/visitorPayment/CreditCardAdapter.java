package visitorPayment;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public class CreditCardAdapter implements PaymentGateway {
    private CreditCard paymentGateway;

    public CreditCardAdapter(CreditCard paymentGateway) {
        this.paymentGateway = paymentGateway;
    }

    @Override
    public void processPayment(int amount) {
        paymentGateway.makePayment(amount);
    }
}
