package visitorPayment;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import visitorManagement.EmployeeLoginForm;

public class CreditCard {
	public void makePayment(int amount) {
		// Credit Card-specific payment processing logic
		EmployeeLoginForm.card += amount;
		System.out.println("Paid ₪" + amount + " via Credit Card.");
	}

}
