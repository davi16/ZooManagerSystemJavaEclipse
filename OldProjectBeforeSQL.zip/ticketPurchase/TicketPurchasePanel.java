package ticketPurchase;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import visitorManagement.VisitorManagementMenu;

public class TicketPurchasePanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton no, yes;
	VisitorManagementMenu myMenu;

	public TicketPurchasePanel(VisitorManagementMenu menu) {
		myMenu = menu;
		setAlignmentX(CENTER_ALIGNMENT);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		JLabel yearly = new JLabel("Do you want a yearly subscription?");
		yearly.setMaximumSize(new Dimension(250, 30));
		yearly.setAlignmentX(CENTER_ALIGNMENT);
		
		JPanel inside = new JPanel();
		inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
		inside.setMaximumSize(new Dimension(200, 30));
		inside.setAlignmentX(CENTER_ALIGNMENT);

		yes = new JButton("Yes");
		yes.setBorder(BorderFactory.createEtchedBorder());
		yes.setMaximumSize(new Dimension(100, 30));
		yes.setAlignmentX(CENTER_ALIGNMENT);
		yes.addActionListener(this);

		no = new JButton("No");
		no.setBorder(BorderFactory.createEtchedBorder());
		no.setMaximumSize(new Dimension(100, 30));
		no.setAlignmentX(CENTER_ALIGNMENT);
		no.addActionListener(this);

		inside.add(yes);
		inside.add(no);

		add(yearly);
		add(inside);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == yes) {
			removeAll();
			add(new YearlySubPanel(myMenu));
			myMenu.repaint();
			return;
		}
		if (e.getSource() == no) {
			removeAll();
			add(new RegularTicketPanel(myMenu));
			myMenu.repaint();
			return;
		}
	}

}
