package ticketPurchase;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.*;

import dataBases.TicketDataBase;
import mainPackage.Application;
import ticket.Ticket;
import ticket.TicketOptionEnum;
import visitorManagement.VisitorManagementMenu;
import visitorPayment.PaymentPanel;

public class HowManyChildrenPanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	final String[] one = { "1", "2", "3", "4", "5", "6+" };
	final String[] zero = { "0", "1", "2", "3", "4", "5", "6+" };
	JComboBox<String> children;
	JButton choose , accept, back;
	String ticketType;
	VisitorManagementMenu myMenu;
	int price = 0;

	HowManyChildrenPanel(int i, String ticketType, VisitorManagementMenu menu) {
		myMenu = menu;
		this.ticketType = ticketType;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setAlignmentX(CENTER_ALIGNMENT);

		JLabel amount = new JLabel("How many children?");
		amount.setMaximumSize(new Dimension(150, 30));
		amount.setAlignmentX(CENTER_ALIGNMENT);
		
		if (i == 1) {
			children = new JComboBox<>(one);
		} else {
			children = new JComboBox<>(zero);
		}
		children.setMaximumSize(new Dimension(100, 30));
		children.setAlignmentX(CENTER_ALIGNMENT);

		choose = new JButton("Choose");
		choose.setMaximumSize(new Dimension(100, 30));
		choose.setAlignmentX(CENTER_ALIGNMENT);
		choose.setBorder(BorderFactory.createEtchedBorder());
		choose.addActionListener(this);

		add(amount);
		add(children);
		add(choose);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == back) {
			myMenu.dispose();
			myMenu = new VisitorManagementMenu();
			myMenu.repaint();
			return;
		}
		if (e.getSource() == accept) {
			removeAll();
			add(new PaymentPanel(myMenu, price));
			myMenu.repaint();
			return;
		}
		if (e.getSource() == choose) {
			removeAll();
			setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
			setAlignmentX(CENTER_ALIGNMENT);
			
			PurchasePanel.ticketCode = ticketType;
			PurchasePanel.ticketCode += children.getSelectedItem().toString() == "6+" ? "6"
					: children.getSelectedItem().toString();
			
			for (TicketOptionEnum ticket : TicketOptionEnum.values()) {
				if (ticket.getCode().equals(PurchasePanel.ticketCode)) {
					PurchasePanel.myTicketType = ticket;
					price = Application.price.currentPrice(ticket);
				}
			}
			
			JLabel priceLabel = new JLabel("Your price is: " + price);
			priceLabel.setAlignmentX(CENTER_ALIGNMENT);
			add(priceLabel);

			Random ran = new Random();
			Ticket myTicket = new Ticket(ran.nextInt(90000) + 10000, PurchasePanel.buyer.getID(), PurchasePanel.myTicketType, Application.price.getState());
			TicketDataBase.getTicketDB().addTicket(myTicket);

			JLabel ticketLabel = new JLabel(myTicket.toString());
			ticketLabel.setAlignmentX(CENTER_ALIGNMENT);
			add(ticketLabel);

			accept = new JButton("Make payment");
			accept.setAlignmentX(CENTER_ALIGNMENT);
			accept.setBorder(BorderFactory.createEtchedBorder());
			accept.setMaximumSize(new Dimension(100, 30));
			accept.addActionListener(this);
			add(accept);
			
			back = new JButton("Cancel");
			back.setAlignmentX(CENTER_ALIGNMENT);
			back.setBorder(BorderFactory.createEtchedBorder());
			back.setMaximumSize(new Dimension(100, 30));
			back.addActionListener(this);
			add(back);
			
			myMenu.repaint();
		}
	}

}
