package ticketPurchase;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.*;

import dataBases.TicketDataBase;
import mainPackage.Application;
import ticket.Ticket;
import ticket.TicketOptionEnum;
import visitorManagement.VisitorManagementMenu;
import visitorPayment.PaymentPanel;

public class YearlySpecialPanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JCheckBox adult, kid, psde, student;
	JButton accept, back;
	int price = 0;
	VisitorManagementMenu myMenu;

	YearlySpecialPanel(VisitorManagementMenu menu) {
		myMenu = menu;
		PurchasePanel.ticketCode = "Y";
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setAlignmentX(CENTER_ALIGNMENT);

		JLabel choose = new JLabel("What are you?");
		choose.setMaximumSize(new Dimension(300, 30));
		choose.setAlignmentX(CENTER_ALIGNMENT);

		adult = new JCheckBox("Adult");
		adult.setMaximumSize(new Dimension(300, 30));
		adult.setAlignmentX(CENTER_ALIGNMENT);
		adult.addActionListener(this);

		kid = new JCheckBox("Kid");
		kid.setMaximumSize(new Dimension(300, 30));
		kid.setAlignmentX(CENTER_ALIGNMENT);
		kid.addActionListener(this);

		psde = new JCheckBox("Police/Soldier/Disabled/Elderly");
		psde.setMaximumSize(new Dimension(300, 30));
		psde.setAlignmentX(CENTER_ALIGNMENT);
		psde.addActionListener(this);

		student = new JCheckBox("Student");
		student.setMaximumSize(new Dimension(300, 30));
		student.setAlignmentX(CENTER_ALIGNMENT);
		student.addActionListener(this);

		add(choose);
		add(adult);
		add(kid);
		add(psde);
		add(student);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == back) {
			myMenu.dispose();
			myMenu = new VisitorManagementMenu();
			myMenu.repaint();
			return;
		}
		if (e.getSource() == accept) {
			removeAll();
			add(new PaymentPanel(myMenu, price));
			myMenu.repaint();
			return;
		}

		removeAll();
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setAlignmentX(CENTER_ALIGNMENT);

		if (e.getSource() == adult) {
			PurchasePanel.ticketCode += "A";
		}
		if (e.getSource() == kid) {
			PurchasePanel.ticketCode += "K";
		}
		if (e.getSource() == psde) {
			PurchasePanel.ticketCode += "S";
		}
		if (e.getSource() == student) {
			PurchasePanel.ticketCode += "ST";
		}

		for (TicketOptionEnum ticket : TicketOptionEnum.values()) {
			if (ticket.getCode().equals(PurchasePanel.ticketCode)) {
				PurchasePanel.myTicketType = ticket;
				price = Application.price.currentPrice(ticket);
			}
		}

		JLabel priceLabel = new JLabel("Your price is: " + price);
		priceLabel.setAlignmentX(CENTER_ALIGNMENT);
		add(priceLabel);

		Random ran = new Random();
		Ticket myTicket = new Ticket(ran.nextInt(90000) + 1000, PurchasePanel.buyer.getID(), PurchasePanel.myTicketType, Application.price.getState());
		TicketDataBase.getTicketDB().addTicket(myTicket);

		JLabel ticketLabel = new JLabel(myTicket.toString());
		ticketLabel.setAlignmentX(CENTER_ALIGNMENT);
		add(ticketLabel);

		
		accept = new JButton("Make payment");
		accept.setAlignmentX(CENTER_ALIGNMENT);
		accept.setBorder(BorderFactory.createEtchedBorder());
		accept.setMaximumSize(new Dimension(100, 30));
		accept.addActionListener(this);
		add(accept);
		
		back = new JButton("Cancel");
		back.setAlignmentX(CENTER_ALIGNMENT);
		back.setBorder(BorderFactory.createEtchedBorder());
		back.setMaximumSize(new Dimension(100, 30));
		back.addActionListener(this);
		add(back);
		myMenu.repaint();
	}

}
