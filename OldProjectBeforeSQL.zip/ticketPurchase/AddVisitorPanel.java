package ticketPurchase;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.EventListener;

import javax.swing.*;

import dataBases.VisitorDataBase;
import humanRoles.Visitor;
import visitorManagement.VisitorManagementMenu;

public class AddVisitorPanel extends JPanel implements EventListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JTextField id, first, last, phone, date;
	JCheckBox distribution;
	JButton submit, reload;
	JLabel warning;
	boolean isDis = false;
	VisitorManagementMenu myMenu;

	AddVisitorPanel(VisitorManagementMenu menu) {
		myMenu = menu;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		JPanel inside = new JPanel();
		inside.setLayout(new GridLayout(5, 2, 0, 5));
		inside.setMaximumSize(new Dimension(350, 150));

		JLabel instructions = new JLabel("Enter following values to add new visitor");
		instructions.setAlignmentX(CENTER_ALIGNMENT);
		add(instructions);

		JLabel ID, firstName, lastName, phoneNumber, dateOfBirth;
		ID = new JLabel("ID: ");
		firstName = new JLabel("First name: ");
		lastName = new JLabel("Last name: ");
		phoneNumber = new JLabel("Phone number: ");
		dateOfBirth = new JLabel("Date of birth (dd.MM.yyyy): ");

		id = new JTextField(9);
		first = new JTextField(15);
		last = new JTextField(15);
		phone = new JTextField(10);
		date = new JTextField(10);
		distribution = new JCheckBox("Add to distribution list?");
		distribution.setMaximumSize(new Dimension(250, 30));
		distribution.addActionListener(addDistribution);

		inside.add(ID);
		inside.add(id);
		inside.add(firstName);
		inside.add(first);
		inside.add(lastName);
		inside.add(last);
		inside.add(phoneNumber);
		inside.add(phone);
		inside.add(dateOfBirth);
		inside.add(date);
		add(inside);
		add(distribution);

		JPanel inside2 = new JPanel();
		inside2.setLayout(new BoxLayout(inside2, BoxLayout.X_AXIS));
		inside2.setAlignmentX(CENTER_ALIGNMENT);
		inside2.setMaximumSize(new Dimension(200, 30));
		add(inside2);

		submit = new JButton("Submit");
		submit.addActionListener(action);
		submit.setBorder(BorderFactory.createEtchedBorder());
		submit.setMaximumSize(new Dimension(100, 30));
		submit.setAlignmentX(CENTER_ALIGNMENT);
		inside2.add(submit);

		reload = new JButton("Reload");
		reload.setBorder(BorderFactory.createEtchedBorder());
		reload.setMaximumSize(new Dimension(100, 30));
		reload.setAlignmentX(CENTER_ALIGNMENT);
		reload.addActionListener(action);
		inside2.add(reload);
	}

	ActionListener addDistribution = new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			isDis = true;

		}

	};

	ActionListener action = new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == submit) {
				String ID = checkID(id.getText());
				String firstName = checkName(first.getText());
				String lastName = checkName(last.getText());
				String phoneNumber = checkPhoneNumber(phone.getText());
				LocalDate dateOfBirth;
				dateOfBirth = scanToLocalDate(date.getText());

				if (dateOfBirth != null && firstName != null && lastName != null && phoneNumber != null && ID != null) {
					Visitor newVisitor = new Visitor(ID, firstName, lastName, dateOfBirth, phoneNumber);
					newVisitor.setDistribution(isDis);
					VisitorDataBase.getVisitorDB().addVisitor(newVisitor);

					JLabel newV = new JLabel("Vistor: " + newVisitor.toString() + " added successfuly!");
					newV.setAlignmentX(CENTER_ALIGNMENT);
					newV.setForeground(Color.GREEN);
					add(newV);
					distribution.setSelected(false);
					isDis =false;
					myMenu.repaint();
				}
			}
			if (e.getSource() == reload) {
				myMenu.dispose();
				myMenu = new VisitorManagementMenu();
				myMenu.repaint();
			} else {
				id.requestFocusInWindow();
				id.setText("");
				first.setText("");
				last.setText("");
				phone.setText("");
				date.setText("");
				myMenu.repaint();
			}

		}

	};

	public LocalDate scanToLocalDate(String dateS) {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
			return LocalDate.parse(dateS, formatter);
		} catch (Exception e) {
			if (warning == null) {
				warning = new JLabel("Date is not of right format!");
				warning.setForeground(Color.RED);
				warning.setAlignmentX(CENTER_ALIGNMENT);
				add(warning);
				warning = null;
			}
			return null;
		}
	}

	public String checkID(String ID) {
		try {
			if (!ID.matches("[0-9]+"))
				throw new IllegalCallerException();
			if (ID.length() > 9)
				throw new RuntimeException();
			return ID;
		} catch (IllegalCallerException e) {
			if (warning == null) {
				warning = new JLabel("The ID contains illigal characters");
				warning.setForeground(Color.RED);
				warning.setAlignmentX(CENTER_ALIGNMENT);
				add(warning);
				warning = null;
			}
		} catch (RuntimeException b) {
			if (warning == null) {
				warning = new JLabel("The ID is too long");
				warning.setForeground(Color.RED);
				warning.setAlignmentX(CENTER_ALIGNMENT);
				add(warning);
				warning = null;
			}
		}
		return null;
	}

	public String checkName(String name) {
		try {
			if (!name.matches("[a-zA-Z]+"))
				throw new Exception();
			return name;
		} catch (Exception e) {
			if (warning == null) {
				warning = new JLabel("Name can consist of only letters!");
				warning.setForeground(Color.RED);
				warning.setAlignmentX(CENTER_ALIGNMENT);
				add(warning);
				warning = null;
			}
			return null;
		}
	}

	public String checkPhoneNumber(String phoneNum) {
		try {
			if (!phoneNum.matches("[0-9]+"))
				throw new Exception();
			return phoneNum;
		} catch (Exception e) {
			if (warning == null) {
				warning = new JLabel("Phone number can consist of only numbers!");
				warning.setForeground(Color.RED);
				warning.setAlignmentX(CENTER_ALIGNMENT);
				add(warning);
				warning = null;
			}
			return null;
		}
	}
}
