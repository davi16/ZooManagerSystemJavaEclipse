package ticketPurchase;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import visitorManagement.VisitorManagementMenu;

public class YearlySubPanel extends JPanel implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JCheckBox singleParent , couple , other;
	VisitorManagementMenu myMenu;
	YearlySubPanel(VisitorManagementMenu menu){
		myMenu = menu;
		setLayout(new BoxLayout(this , BoxLayout.Y_AXIS));
		setAlignmentX(CENTER_ALIGNMENT);
		
		JLabel choose = new JLabel("What are you?");
		choose.setMaximumSize(new Dimension(100, 30));
		choose.setAlignmentX(CENTER_ALIGNMENT);
		
		singleParent = new JCheckBox("Single parent");
		singleParent.setMaximumSize(new Dimension(200, 30));
		singleParent.setAlignmentX(CENTER_ALIGNMENT);
		singleParent.addActionListener(this);
		
		couple = new JCheckBox("Couple");
		couple.setMaximumSize(new Dimension(200, 30));
		couple.setAlignmentX(CENTER_ALIGNMENT);
		couple.addActionListener(this);
		
		other = new JCheckBox("Other");
		other.setMaximumSize(new Dimension(200, 30));
		other.setAlignmentX(CENTER_ALIGNMENT);
		other.addActionListener(this);
		
		add(choose);
		add(singleParent);
		add(couple);
		add(other);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == singleParent) {
			removeAll();
			add(new HowManyChildrenPanel(1 , "YP" , myMenu));
			myMenu.repaint();
		}
		if (e.getSource() == couple) {
			removeAll();
			add(new HowManyChildrenPanel(0 , "YC" , myMenu));
			myMenu.repaint();
		}
		if (e.getSource() == other) {
			removeAll();
			add(new YearlySpecialPanel(myMenu));
			myMenu.repaint();
		}
	}

}
