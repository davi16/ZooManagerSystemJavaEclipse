package animalSuperClasses;

public interface Animal {

	public double feed();

	public String makeNoise();

	public void ageOneYear();

	void removeHappiness();

	public String toString(boolean consoleColor);
}
