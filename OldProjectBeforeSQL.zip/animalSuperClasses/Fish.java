package animalSuperClasses;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;

import animalEnums.FishColorEnum;
import animalEnums.FishPrintEnum;

public abstract class Fish implements Animal {

	private final String ANSI_RESET = "\u001B[0m"; // Console black text color
	private final String ANSI_BOLD = "\u001B[1m";

	protected int age; // The age of the Fish
	protected double length; // The length of the Fish
	protected ArrayList<FishColorEnum> fishColors; // The colors of the Fish
	protected FishPrintEnum fishPrint; // The print of the Fish
	protected boolean alive;
	protected int happiness = 100;
	NumberFormat formatter = new DecimalFormat("#0.00"); // A new decimal formatter

	public Fish(int age, double length, ArrayList<FishColorEnum> fishColors, FishPrintEnum fishPrint) {
		// Constructor
		this.age = age;
		this.length = length;
		this.fishColors = fishColors;
		this.fishPrint = fishPrint;
		this.alive = true;
		addColorToCounter(fishColors);
	}

	/** Basic Methods */

	public boolean isAlive() {
		// Returns the state of this Fish
		return alive;
	}

	public ArrayList<FishColorEnum> getFishColors() {
		// Returns the colors of the Fish
		return fishColors;
	}

	public FishPrintEnum getFishPrint() {
		// Returns the print of the Fish
		return fishPrint;
	}

	private void addColorToCounter(ArrayList<FishColorEnum> fishColors) {
		// Adds the colors to the counter
		// Counter -> saves all colors that the Fish have
		for (int i = 0; i < fishColors.size(); i++) {
			fishColors.get(i).addToCounter(1);
		}
	}

	protected String happinessPrint() {
		// Changes the happiness print color based on its value
		if (happiness > 80)
			return "\033[0;32m" + happiness + "\033[0;30m";
		else if (happiness <= 80 && happiness > 60)
			return "\033[0;33m" + happiness + "\033[0;30m";
		else if (happiness <= 60 && happiness > 30)
			return "\033[0;91m" + happiness + "\033[0;30m";
		else
			return "\033[0;31m" + happiness + "\033[0;30m";
	}

	/** All Overridden Methods */

	@Override
	public void removeHappiness() {
		// Removes happiness from this Fish
		this.happiness -= Math.random() * 20;
		if (this.happiness < 1) {
			this.alive = false;
			this.happiness = 0;
		}
	}

	@Override
	public String makeNoise() {
		// Returns the sound this Fish makes
		return "blob";
	}

	@Override
	public String toString(boolean consoleColor) {
		// Returns a string with all values of this fish
		if (consoleColor) {
			return ANSI_BOLD + "Type: " + ANSI_RESET + getClass().getSimpleName() + ANSI_BOLD + " Age: " + ANSI_RESET
					+ this.age + ANSI_BOLD + " Length: " + ANSI_RESET + formatter.format(this.length) + ANSI_BOLD
					+ " Colors: " + ANSI_RESET + FishColorEnum.convertToColorfulList(this.fishColors).toString()
					+ ANSI_BOLD + " Print: " + ANSI_RESET + this.fishPrint + ANSI_BOLD + " Happiness: " + ANSI_RESET
					+ happinessPrint();
		} else {
			return "Type: " + getClass().getSimpleName() + " Age: " + this.age + " Length: "
					+ formatter.format(this.length) + " Colors: "
					+ this.fishColors.toString() + " Print: "
					+ this.fishPrint + " Happiness: " + happiness;
		}
	}

}
