package animalSuperClasses;

import java.text.DecimalFormat;
import java.text.NumberFormat;

import animalEnums.GenderEnum;

public abstract class Predator extends Mamal {

	public static final int LIFESPAN = 15;

	NumberFormat formatter = new DecimalFormat("#0.0");
	private final String ANSI_RESET = "\u001B[0m"; // Console black text color
	private final String ANSI_BOLD = "\u001B[1m";

	public Predator(String name, int age, double weight, GenderEnum gender) {
		// Constructor
		super(name, age, weight, gender);
		this.alive = true;
	}

	/** Basic Methods */

	public boolean isAlive() {
		// Returns the state of this Predator
		return alive;
	}

	/** All Overridden Methods */

	@Override
	public void ageOneYear() {
		// Ages this Predator by one year
		if (this.age >= LIFESPAN) {
			this.alive = false;
			this.happiness = 0;
			return;
		}
		removeHappiness();
		this.age++;
	}

	@Override
	public void removeHappiness() {
		// Removes happiness from this Predator
		this.happiness -= Math.random() * 10;
		if (this.happiness < 1) {
			this.alive = false;
			this.happiness = 0;
		}
	}

	@Override
	public String toString(boolean consoleColor) {
		// Return all values of this Predator in string format
		if (consoleColor) {
			return ANSI_BOLD + "Type: " + ANSI_RESET + getClass().getSimpleName() + ANSI_BOLD + " Name: " + ANSI_RESET
					+ this.name + ANSI_BOLD + " Age: " + ANSI_RESET + this.age + ANSI_BOLD + " Weight: " + ANSI_RESET
					+ formatter.format(this.weight) + ANSI_BOLD + " Gender: " + ANSI_RESET + this.gender + ANSI_BOLD
					+ " Happiness: " + ANSI_RESET + happinessPrint();
		} else {
			return "Type: " + getClass().getSimpleName() + " Name: " + this.name + " Age: " + this.age + " Weight: "
					+ formatter.format(this.weight) + " Gender: " + this.gender + " Happiness: " + happiness;
		}
	}
}
