package ticketCancel;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import dataBases.VisitorDataBase;
import humanRoles.Visitor;
import visitorManagement.VisitorManagementMenu;

public class CancelPanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTextField visitorID;
	JButton show;
	JLabel warning;
	VisitorManagementMenu myMenu;

	public CancelPanel(VisitorManagementMenu menu) {
		myMenu = menu;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		add(Box.createRigidArea(new Dimension(0, 10)));

		JPanel inside = new JPanel();
		inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
		inside.setMaximumSize(new Dimension(300, 30));
		inside.setAlignmentX(CENTER_ALIGNMENT);
		add(inside);

		JLabel visitorId = new JLabel("Enter visitor ID: ");
		inside.add(visitorId);

		visitorID = new JTextField(9); // set length of the text
		visitorID.setMaximumSize(new Dimension(150, 30));
		inside.add(visitorID);

		show = new JButton("Show");
		show.setBorder(BorderFactory.createEtchedBorder());
		show.setMaximumSize(new Dimension(100, 30));
		show.addActionListener(this);
		inside.add(show);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == show) {
			String visiID = visitorID.getText(); // get user entered username from textField1
			for (Visitor visitor : VisitorDataBase.getVisitorDB().getVisitors()) {
				if (visitor.getID().compareTo(visiID) == 0) {
					removeAll();
					add(Box.createRigidArea(new Dimension(0, 10)));
					JLabel visitorInfo = new JLabel("Cancelling for: " + visitor.toString());
					visitorInfo.setAlignmentX(CENTER_ALIGNMENT);
					add(visitorInfo);
					add(Box.createRigidArea(new Dimension(0, 50)));
					myMenu.cancelTicket(visiID);
					return;
				}
			}
			if (warning == null) {
				Toolkit.getDefaultToolkit().beep();
				visitorID.requestFocusInWindow();
				visitorID.setText("");
				warning = new JLabel("ID not found!");
				warning.setForeground(Color.RED);
				warning.setAlignmentX(CENTER_ALIGNMENT);
				add(warning);
				myMenu.repaint();
			}
		}
	}

}
