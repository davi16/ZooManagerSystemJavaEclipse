package vistorDistributionGroup;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import dataBases.jdbc;
import visitorManagement.VisitorManagementMenu;

public class VisitorMailingPanel extends JPanel implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton send, again;
	VisitorManagementMenu myMenu;
	JPanel inside;
	int myDiscount;

	public VisitorMailingPanel(VisitorManagementMenu menu, int discount) {

		myMenu = menu;
		myDiscount = discount;
		setAlignmentX(CENTER_ALIGNMENT);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		JLabel m = new JLabel(
				"The discount is " + discount + "% Would you like to send notification to the distribution group?");
		m.setMaximumSize(new Dimension(500, 30));
		m.setAlignmentX(CENTER_ALIGNMENT);

		JPanel inside = new JPanel();
		inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
		inside.setAlignmentX(CENTER_ALIGNMENT);
		inside.setMaximumSize(new Dimension(200, 30));

		again = new JButton("Go back");
		again.setBorder(BorderFactory.createEtchedBorder());
		again.setMaximumSize(new Dimension(100, 30));
		again.addActionListener(this);
		inside.add(again);

		send = new JButton("send");
		send.setBorder(BorderFactory.createEtchedBorder());
		send.setMaximumSize(new Dimension(100, 30));
		send.addActionListener(this);
		inside.add(send);

		add(m);
		add(inside);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == again) {
			jdbc.save.restoreMemento();
			//System.out.println(Application.price);
			myMenu.dispose();
			try {
				myMenu = new VisitorManagementMenu();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			myMenu.repaint();
		}
		if (e.getSource() == send) {
			jdbc.price.setState(myDiscount / 10);
			jdbc.save = jdbc.price.saveMemento();
			//System.out.println(Application.price);
			VisitorDiscountDistribution.getDistribution().notifyAllObservers();
			
			removeAll();
		    add(new SentMailPanel(myMenu));
			myMenu.repaint();
		}

	}

}
