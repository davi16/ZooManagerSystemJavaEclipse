package vistorDistributionGroup;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public interface Observer {

	public void notify(Observable obs);
}
