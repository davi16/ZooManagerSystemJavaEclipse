package vistorDistributionGroup;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Color;
//Students submitting: Kristina goldin 317958799, David Ben Yaacov 320759921
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import visitorManagement.VisitorManagementMenu;

public class SentMailPanel extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton again;
	VisitorManagementMenu myMenu;
	int observers;


	public SentMailPanel(VisitorManagementMenu menu) {
		myMenu = menu;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setAlignmentX(CENTER_ALIGNMENT);
		
		observers = VisitorDiscountDistribution.getDistribution().countObservers();

		JLabel m = new JLabel("The notification sent to "+ observers + " visitors!");
		m.setForeground(Color.GREEN);
		m.setMaximumSize(new Dimension(200, 30));
		m.setAlignmentX(CENTER_ALIGNMENT);
		
		again = new JButton("Accept");
		again.setBorder(BorderFactory.createEtchedBorder());
		again.setMaximumSize(new Dimension(100, 30));
		again.setAlignmentX(CENTER_ALIGNMENT);
		again.addActionListener(this);
		
		add(m);
		add(again);
	
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		myMenu.dispose();
		try {
			myMenu = new VisitorManagementMenu();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		myMenu.repaint();
		return;
		
	}

}
