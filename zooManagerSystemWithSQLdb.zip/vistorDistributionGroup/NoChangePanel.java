package vistorDistributionGroup;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import visitorManagement.VisitorManagementMenu;

public class NoChangePanel extends JPanel implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton again;
	VisitorManagementMenu myMenu;


	public NoChangePanel(VisitorManagementMenu menu) {
		myMenu = menu;
		setAlignmentX(CENTER_ALIGNMENT);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		JLabel m = new JLabel("No change was made");
		m.setMaximumSize(new Dimension(200, 30));
		m.setAlignmentX(CENTER_ALIGNMENT);
		
		JPanel inside = new JPanel();
		inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
		inside.setAlignmentX(CENTER_ALIGNMENT);
		inside.setMaximumSize(new Dimension(200, 30));
		

		again = new JButton("Go back");
		again.setBorder(BorderFactory.createEtchedBorder());
		again.setMaximumSize(new Dimension(100, 30));
		again.setAlignmentX(CENTER_ALIGNMENT);
		again.addActionListener(this);
		inside.add(again);
		add(m);
		add(inside);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		myMenu.dispose();
		try {
			myMenu = new VisitorManagementMenu();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		myMenu.repaint();
		return;
	}
}
