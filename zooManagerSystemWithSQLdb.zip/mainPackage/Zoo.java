package mainPackage;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

import animalEnums.*;
import animalExceptions.*;
import animalSuperClasses.*;
import animals.*;
import dataStractures.PenguinLine;
import dataBases.*;

public class Zoo {

	private Random random = new Random(); // New randomizer

	static final String ANSI_RESET = "\u001B[0m"; // Console text color reset
	static final String ANSI_GREEN = "\033[1;32m"; // Console green + BOLD text color
	static final String ANSI_RED = "\u001B[31m"; // Console red text color
	static final String ANSI_BOLD = "\u001B[1m"; // Console bold text

	static int pandasIndex = 0; // Index for pandas

	private String zooName, zooAdress; // Basic zoo info
	PenguinLine penguinLine;
	public Zoo() throws SQLException {
		penguinLine = new PenguinLine();
	}
	  // Line of Penguins in the zoo

	public String getZooName() {
		// Returns the name of the zoo
		return zooName;
	}

	public void setZooName(String zooName) {
		// Sets the name of the zoo
		this.zooName = zooName;
	}

	public String getZooAddress() {
		// Returns the address of the zoo
		return zooAdress;
	}

	public void setZooAddress(String zooAddress) {
		// Sets the address of the zoo
		this.zooAdress = zooAddress;
	}

	/** Panda methods 
	 * @throws SQLException */

//	private void removeNullPandas() {
//		// Removes the null Pandas from the array
//		Panda[] temp = new Panda[8];
//		int counter = 0;
//		for (Panda panda : pandas) {
//			if (panda != null) {
//				temp[counter] = panda;
//				counter++;
//			}
//		}
//		pandas = temp;
//	}

	public void relapsePandas() throws SQLException {
		// Gets older Pandas ready to make a new baby
		jdbc.relapsePandas();
	}

	public String checkNewPandaBirth() throws SQLException, PandaArrayFullException {
		// Checking if there can be a new panda born, if true than creates a new Panda
		// and sets up the hierarchy of Pandas
		return jdbc.checkNewPandaBirth();
	}

	public ArrayList<Panda> getPandas() throws SQLException {
		// Returns the array of Pandas
		return jdbc.getPandas();
	}

	public void setPanda(Panda newPanda) throws PandaArrayFullException, SQLException {
		// Adds a new Panda to the array
		jdbc.addPanda(newPanda);
	}

	public String pandaNoise() throws SQLException {
		// Returns the noise all Pandas make
		String noise = "";
		for (Panda panda : jdbc.getPandas()) {
			noise += panda.makeNoise() + " ";
		}
		return noise;
	}

	public double numberOfMealsPandas() throws SQLException {
		// Returns the number of bamboo all Pandas eat
		double bamboos = 0;
		for (Panda panda : jdbc.getPandas()) {
			if (panda != null)
				bamboos += panda.feed();
		}
		return bamboos;
	}

	public int getNumberOfPandas() throws SQLException {
		// Returns the number of Pandas in the zoo
		int counter = 0;
		for (Panda panda : jdbc.getPandas()) {
			if (panda != null) {
				counter++;
			}
		}
		return counter;
	}

	/** Elephant methods 
	 * @throws SQLException */

	public LinkedList<Elephant> getHerd() throws SQLException {
		return jdbc.getHerd();
	}

	public int getNumberOfElephants() throws SQLException {
		// Returns the number of Elephants in herd
		return jdbc.howManyEkephants();
	}

	public void setElephant(Elephant elephant) throws SQLException {
		// sets hard-coded Elephants to the herd
		jdbc.addElephant(elephant);
	}

	public void addElephant(Elephant newElephant) throws OlderThanMatriarchException, MaleTooOldInHerdExeption, SQLException {
		// Adds new elephant
		if (newElephant.getAge() > getMatriarchAge())
			throw new OlderThanMatriarchException("You can't add a female elephant older than the matriarch\n"
					+ "Matriarch age is: " + getMatriarchAge());
		if (newElephant.getGender() == GenderEnum.MALE && newElephant.getAge() > Elephant.MAX_MALE_AGE)
			throw new MaleTooOldInHerdExeption(
					"You can't add a male elephant older then " + Elephant.MAX_MALE_AGE + " to the herd");
		jdbc.addElephant(newElephant);
	}

	public int getMatriarchAge() throws SQLException {
		// Returns the age of the matriarch in the herd
		int max = 0;
		for (Elephant elephant : jdbc.getHerd()) {
			if (elephant.getGender() == GenderEnum.FEMALE && elephant.getAge() > max) {
				max = elephant.getAge();
			}
		}
		return max;
	}

	public void sortElephantsByAge() {
		// Sorts Elephants by age
		jdbc.setElephantOrder("age");
	}

	public String elephantNoise() throws SQLException {
		// Returns all the noise the Elephants make
		String noise = "";
		for (Elephant elephant : jdbc.getHerd()) {
			noise += elephant.makeNoise() + " ";
		}
		return noise;
	}

	public double numberOfMealsElephants() throws SQLException {
		// Returns the number of plants the Elephants ate
		double meals = 0;
		for (Elephant elephant : jdbc.getHerd()) {
			meals += elephant.feed();
		}
		return meals;
	}

	/** Penguin methods 
	 * @throws SQLException */

	public void setPenguin(Penguin penguin) throws SQLException {
		// sets hard-coded Penguins to the line
		this.penguinLine.add(penguin);
	}

	public void addPenguin(Penguin newPenguin) throws HigherThanLeaderException, SQLException {
		// Adds a new Penguin to the line
		if (newPenguin.getHeight() > getLeaderHeight())
			throw new HigherThanLeaderException(
					"The penguin can't be higher than leader, Leader height: " + getLeaderHeight());
		this.penguinLine.add(newPenguin);
	}

	public void printPenguins() {
		// Prints all Penguins in the zoo
		this.penguinLine.printPenguins();
	}

	public double getLeaderHeight() {
		// Returns the height of the leader Penguin
		return this.penguinLine.getLeaderHeight();
	}

	public int countPenguinsInLine() {
		// Returns the number of Penguins there are in the zoo
		return this.penguinLine.countPenguinsInLine();
	}

	public double numberOfFishPenguins() {
		// Returns the number of fish the Penguins ate
		return this.penguinLine.feed();
	}

	public String penguinNoise() {
		// Making all penguins in the zoo make a noise
		return this.penguinLine.noise();
	}

	public void sortPenguinsByName() throws SQLException {
		// Rearranges the Penguins in the zoo by name
		this.penguinLine.sortByName();
	}

	public void sortPenguinsByHeight() throws SQLException {
		// Rearranges the Penguins in the zoo by height
		this.penguinLine.sortByHeight();
	}

	public void sortPenguinsByAge() throws SQLException {
		// Rearranges the Penguins in the zoo by age
		this.penguinLine.sortByAge();
	}

	/** Predator methods 
	 * @throws SQLException */

	public void setPredator(Predator newPredator) throws SQLException {
		// Adds a Lion to the zoo
		jdbc.addPredator(newPredator);
	}

	public int getNumberOfLions() throws SQLException {
		// Returns the number of Lions there are in the zoo
		int counter = 0;
		for (Predator lion : jdbc.getPredators()) {
			if (lion instanceof Lion) {
				counter++;
			}
		}
		return counter;
	}

	public int getNumberOfTigers() throws SQLException {
		// Returns the number of Lions there are in the zoo
		int counter = 0;
		for (Predator tiger : jdbc.getPredators()) {
			if (tiger instanceof Tiger) {
				counter++;
			}
		}
		return counter;
	}

	public ArrayList<Predator> getPredators() throws SQLException {
		// Returns the data about all the predators in the zoo
		return jdbc.getPredators();
	}

	public double numberOfMealsLions() throws SQLException {
		// Returns the number of meat the Lions ate
		double meals = 0;
		for (Predator lion : jdbc.getPredators()) {
			if (lion instanceof Lion) {
				meals += lion.feed();
			}
		}
		return meals;
	}

	public double numberOfMealsTigers() throws SQLException {
		// Returns the number of meat the Tiger ate
		double meals = 0;
		for (Predator tiger : jdbc.getPredators()) {
			if (tiger instanceof Tiger) {
				meals += tiger.feed();
			}
		}
		return meals;
	}

	public String lionNoise() throws SQLException {
		// Returns the noise the Lions make
		String noise = "";
		for (Predator lion : jdbc.getPredators()) {
			if (lion instanceof Lion) {
				noise += lion.makeNoise() + " ";
			}
		}
		return noise;
	}

	public String tigerNoise() throws SQLException {
		// Returns the noise the Tigers make
		String noise = "";
		for (Predator tiger : jdbc.getPredators()) {
			if (tiger instanceof Tiger) {
				noise += tiger.makeNoise() + " ";
			}
		}
		return noise;
	}

	/** Fish methods 
	 * @throws SQLException 
	 * @throws NumberFormatException */

	public void setFish(Fish newFish) throws NumberFormatException, SQLException {
		// Adds a specific fish to the zoo
		jdbc.addFish(newFish);
	}

	public void addFish(int amount) throws SQLException {
		// Adds Random fish to aquarium
		int randomTypeIndex;
		for (int i = 0; i < amount; i++) {
			randomTypeIndex = random.nextInt(FishTypeEnum.values().length);
			FishTypeEnum fishType = FishTypeEnum.values()[randomTypeIndex];
			if (fishType == FishTypeEnum.AQUARIUM)
				jdbc.addFish(generateRandomAquariumFish());
			if (fishType == FishTypeEnum.GOLD)
				jdbc.addFish(generateRandomGoldFish());
			if (fishType == FishTypeEnum.CLOWN)
				jdbc.addFish(generateRandomClownFish());
		}
	}

	private AquariumFish generateRandomAquariumFish() throws SQLException {
		// Generates a random AquariumFish
		int randomPrint = random.nextInt(FishPrintEnum.values().length);
		FishPrintEnum fishPrint = FishPrintEnum.values()[randomPrint];
		if (fishPrint == FishPrintEnum.SMOOTH) {
			Fish newFish = new AquariumFish(random.nextInt(AquariumFish.LIFESPAN), random.nextDouble(149.5) + 0.5, fishPrint,
					1);
			return (AquariumFish) newFish;
		}
		else {
			Fish newFish = new AquariumFish(random.nextInt(AquariumFish.LIFESPAN), random.nextDouble(149.5) + 0.5, fishPrint,
					random.nextInt(4) + 1);
			return (AquariumFish) newFish;
		}
		// We think 4 colors in a single fish is enough
	}

	private GoldFish generateRandomGoldFish() throws SQLException {
		// Generates a random GoldFish
		Fish newFish = new GoldFish(random.nextInt(GoldFish.LIFESPAN), random.nextDouble(40.5) + 0.5);
		return (GoldFish) newFish;
	}

	private ClownFish generateRandomClownFish() throws SQLException {
		// Generates a random ClownFish
		Fish newFish = new ClownFish(random.nextInt(ClownFish.LIFESPAN), random.nextDouble(14.5) + 0.5);
		return (ClownFish) newFish;
	}

	public ArrayList<Fish> getAquarium() throws SQLException {
		// Returns the whole aquarium of Fish
		return jdbc.getFish();
	}

	public double numberOfMealsAquariumFish() throws SQLException {
		// Returns the number of portions the AquariumFish ate
		double meals = 0;
		for (Fish fish : jdbc.getFish()) {
			if (fish instanceof AquariumFish) {
				meals += fish.feed();
			}
		}
		return meals;
	}

	public double numberOfMealsGoldFish() throws SQLException {
		// Returns the number of portions the GoldFish ate
		double meals = 0;
		for (Fish fish : jdbc.getFish()) {
			if (fish instanceof GoldFish) {
				meals += fish.feed();
			}
		}
		return meals;
	}

	public double numberOfMealsClownFish() throws SQLException {
		// Returns the number of portions the ClownFish ate
		double meals = 0;
		for (Fish fish : jdbc.getFish()) {
			if (fish instanceof ClownFish) {
				meals += fish.feed();
			}
		}
		return meals;
	}

	public int getNumberOfGoldFish() throws SQLException {
		// Returns the number of Gold fish there are in the zoo
		int count = 0;
		for (Fish fish : jdbc.getFish()) {
			if (fish instanceof GoldFish)
				count++;
		}
		return count;
	}

	public int getNumberOfAquariumFish() throws SQLException {
		// Returns the number of Aquarium fish there are in the zoo
		int count = 0;
		for (Fish fish : jdbc.getFish()) {
			if (fish instanceof AquariumFish)
				count++;
		}
		return count;
	}

	public int getNumberOfClownFish() throws SQLException {
		// Returns the number of Clown fish there are in the zoo
		int count = 0;
		for (Fish fish : jdbc.getFish()) {
			if (fish instanceof ClownFish)
				count++;
		}
		return count;
	}

	public int getNumberOfAllFish() throws SQLException {
		// Returns the total number of Fish in the zoo
		return getNumberOfAquariumFish() + getNumberOfClownFish() + getNumberOfGoldFish();
	}

	public Collection<FishColorEnum> getAllColorsOfAllFish() throws SQLException {
		// Returns all colors of Fish in the zoo
		Collection<FishColorEnum> allColorsExistInFish = new HashSet<FishColorEnum>();
		for (Fish fish : jdbc.getFish()) {
			for (int i = 0; i < fish.getFishColors().size(); i++) {
				allColorsExistInFish.add(fish.getFishColors().get(i));
			}
		}
		return allColorsExistInFish;
	}

	public String getDominantColorsOfAllFish() {
		// Returns the 2 most dominant Fish colors in the zoo
		FishColorEnum[] dominantColors = FishColorEnum.values();
		FishColorEnum temp;
		for (int i = 0; i < dominantColors.length; i++) {
			for (int j = i + 1; j < dominantColors.length; j++) {
				if (dominantColors[i].getCounter() > dominantColors[j].getCounter()) {
					temp = dominantColors[i];
					dominantColors[i] = dominantColors[j];
					dominantColors[j] = temp;
				}
			}
		}
		return dominantColors[dominantColors.length - 1].getCode() + dominantColors[dominantColors.length - 1].name()
				+ ANSI_RESET + " + " + dominantColors[dominantColors.length - 2].getCode()
				+ dominantColors[dominantColors.length - 2].name() + ANSI_RESET;
	}

	public String fishNoise() throws SQLException {
		// Returns the noise the Fish make
		String noise = "";
		for (Fish fish : jdbc.getFish()) {
			noise += fish.makeNoise() + " ";
		}
		return noise;
	}

	/** Animal methods 
	 * @throws SQLException */
	
	public String ageAllAnimals() throws SQLException {
		// Returns a string representation of all animals saved in this zoo
		String output = "These are the animals that died because they got old:\n" + ANSI_RESET;
		String temp = output;
		Iterator<Fish> fishIterator = jdbc.getFish().iterator();
		while (fishIterator.hasNext()) {
			Fish fish = fishIterator.next();
			fish.ageOneYear();
			if (!fish.isAlive()) {
				output += fish.toString(true) + "\n";
				fishIterator.remove();
			}

		}
		Iterator<Predator> predatorIterator = jdbc.getPredators().iterator();
		while (predatorIterator.hasNext()) {
			Predator predator = predatorIterator.next();
			predator.ageOneYear();
			if (!predator.isAlive()) {
				output += predator.toString(true) + "\n";
				predatorIterator.remove();
			}
		}
		output += this.penguinLine.ageAllPenguins(true);

		Iterator<Elephant> elephantIterator = jdbc.getHerd().iterator();
		while (elephantIterator.hasNext()) {
			Elephant elephant = elephantIterator.next();
			elephant.ageOneYear();
			if (!elephant.isAlive()) {
				output += elephant.toString(true) + "\n";
				elephantIterator.remove();
			}
		}
		for (Panda panda : jdbc.getPandas()) {
			if (panda != null) {
				panda.ageOneYear();
				if (!panda.isAlive()) {
					output += panda.toString(true) + "\n";
				}
			}
		}
		if (output.contentEquals(temp))
			return " - No animals died this year.\n";
		return output;
	}

	public String ageMaleElephants() throws SQLException {

		String output = "These are the male elephants reached their max age to be in herd and left the zoo:\n"
				+ ANSI_RESET;
		String temp = output;
		Iterator<Elephant> elephantIterator = jdbc.getHerd().iterator();
		while (elephantIterator.hasNext()) {
			Elephant elephant = elephantIterator.next();
			if (elephant.getGender() == GenderEnum.MALE && elephant.getAge() > Elephant.MAX_MALE_AGE) {
				output += elephant.toString(true) + "\n";
				elephantIterator.remove();
			}
		}
		if (output == temp)
			return " - No male elephants left the herd this year.\n";
		return output;
	}

	public String makeAnimalsHungry() throws SQLException {
		// Makes the happiness of all animals in the zoo go down (representing them
		// getting hungry)
		String output = "These are the animals that died because they were hungry: \n";
		String temp = output;
		Iterator<Fish> fishIterator = jdbc.getFish().iterator();
		while (fishIterator.hasNext()) {
			Fish fish = fishIterator.next();
			fish.removeHappiness();
			if (!fish.isAlive()) {
				output += fish.toString(false) + "\n";
				fishIterator.remove();
			}

		}
		Iterator<Predator> predatorIterator = jdbc.getPredators().iterator();
		while (predatorIterator.hasNext()) {
			Predator predator = predatorIterator.next();
			predator.removeHappiness();
			if (!predator.isAlive()) {
				output += predator.toString(false) + "\n";
				predatorIterator.remove();
			}
		}
		output += this.penguinLine.removeHappiness(false);

		Iterator<Elephant> elephantIterator = jdbc.getHerd().iterator();
		while (elephantIterator.hasNext()) {
			Elephant elephant = elephantIterator.next();
			elephant.removeHappiness();
			if (!elephant.isAlive()) {
				output += elephant.toString(false) + "\n";
				elephantIterator.remove();
			}
		}
		for (Panda panda : jdbc.getPandas()) {
			if (panda != null) {
				panda.removeHappiness();
				if (!panda.isAlive()) {
					output += panda.toString(false) + "\n";
				}
			}
		}
		if (output.contentEquals(temp)) {
			output = "All animals are fine, for now.\n";
		}
		return output;
	}

}
