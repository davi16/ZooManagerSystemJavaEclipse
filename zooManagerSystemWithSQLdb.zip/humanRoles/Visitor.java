package humanRoles;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import dataBases.*;
import ticket.Ticket;
import vistorDistributionGroup.Observable;
import vistorDistributionGroup.Observer;
import vistorDistributionGroup.VisitorDiscountDistribution;

public class Visitor extends Human implements Observer {

	public ArrayList<Ticket> tickets;
	public boolean isDistribution;

	public Visitor(String ID, String firstName, String lastName, String phoneNumber, LocalDate dateOfBirth) throws SQLException {
		super(ID, firstName, lastName, dateOfBirth, phoneNumber);
		tickets = jdbc.findTickets(ID);
	}

	public ArrayList<Ticket> getTickets() {
		return tickets;
	}

	public void setDistribution(boolean dist) {
		isDistribution = dist;

	}

	@Override
	public String toString() {
		return "[Visitor] ID:" + ID + ", First Name:" + firstName + ", Last Name:" + lastName + ", Birth Date:"
				+ dateOfBirth + ", Phone Number:" + phoneNumber + ", Distribution: " + isDistribution;
	}

	@Override
	public void notify(Observable obs) {
		if (obs instanceof VisitorDiscountDistribution) {
			int discount = VisitorDiscountDistribution.getDistribution().getDiscount();
			if (discount > 0) {
				System.out.printf(
						"\nHello %s.\n All tickets are now %d precent off!\n Hurry up and come to a fun day at the zoo!\nSee you (:\n\n",
						firstName, discount);
			}
			else
				System.out.printf(
						"\nHello %s.\n The sale is over :( \nBut don't worry, there is another one just around the corner!\n\n",
						firstName);

		}
	}

}
