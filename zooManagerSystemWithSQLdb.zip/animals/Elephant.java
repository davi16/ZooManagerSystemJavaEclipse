package animals;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Random;

import animalEnums.GenderEnum;
import animalSuperClasses.Mamal;
import dataBases.jdbc;

public class Elephant extends Mamal {

	private double trunkLength;

	public double getTrunkLength() {
		return trunkLength;
	}

	public void setTrunkLength(double trunkLength) {
		this.trunkLength = trunkLength;
	}

	private final String ANSI_RESET = "\u001B[0m"; // Console black text color
	private final String ANSI_BOLD = "\u001B[1m"; // Console bold text
	NumberFormat formatter = new DecimalFormat("#0.0");
	private Random random = new Random();
	public static final int LIFESPAN = 65;
	public static final int MAX_IN_HERD = 12;
	public static final int MAX_MALE_AGE = 17;

	public Elephant(String name, int age, GenderEnum gender, double weight) {
		// Constructor
		super(name, age, weight, gender);
		this.trunkLength = random.nextDouble(50) + 200;
		this.alive = true;
	}
	
	public Elephant(String name, int age, int happiness, GenderEnum gender, double weight , double trunkLength) {
		// Constructor
		super(name, age, weight, gender);
		this.trunkLength = trunkLength;
		this.alive = true;
		this.happiness = happiness;
	}

	/** Basic Methods */

	public int getAge() {
		// Returns this Elephants age
		return age;
	}

	public GenderEnum getGender() {
		// Returns this Elephants gender
		return gender;
	}

	public boolean isAlive() {
		// Returns the state of this Elephant
		return alive;
	}

	/** All Overridden Methods */

	@Override
	public double feed() {
		// Returns the amount of plants this Elephant eats
		this.happiness = 100;
		if (this.gender == GenderEnum.FEMALE)
			return this.weight / this.trunkLength;
		else
			return this.weight * this.age;
	}

	@Override
	public String makeNoise() {
		// Returns the sound this Elephant makes
		return "Pawoo!!";
	}

	@Override
	public void ageOneYear() throws SQLException {
		// Ages this Elephant by one year
		if (this.age >= LIFESPAN) {
			this.alive = false;
			this.happiness = 0;
			return;
		}
		removeHappiness();
		this.age++;
	}

	@Override
	public void removeHappiness() throws SQLException {
		// Removes happiness from this Elephant
		this.happiness -= Math.random() * 10;
		if (this.happiness < 1) {
			this.alive = false;
			this.happiness = 0;
		}
		jdbc.updateElephant(this);
	}

	@Override
	public String toString(boolean consoleColor) {
		// Return all values of this Elephant in string format
		if (consoleColor) {
			return ANSI_BOLD + "Type: " + ANSI_RESET + getClass().getSimpleName() + ANSI_BOLD + " Name: " + ANSI_RESET
					+ this.name + ANSI_BOLD + " Gender: " + ANSI_RESET + this.gender + ANSI_BOLD + " Age: " + ANSI_RESET
					+ this.age + ANSI_BOLD + " Weight: " + ANSI_RESET + formatter.format(this.weight) + ANSI_BOLD
					+ " Trunk Length: " + ANSI_RESET + formatter.format(this.trunkLength) + ANSI_BOLD + " Happiness: "
					+ ANSI_RESET + happinessPrint();
		} else {
			return "Type: " + getClass().getSimpleName() + " Name: " + this.name + " Gender: " + this.gender + " Age: "
					+ this.age + " Weight: " + formatter.format(this.weight) + " Trunk Length: "
					+ formatter.format(this.trunkLength) + " Happiness: " + happiness;
		}
	}
}
