package animals;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import animalEnums.FishColorEnum;
import animalEnums.FishPrintEnum;
import animalSuperClasses.Fish;

public class GoldFish extends Fish {
	public static final int LIFESPAN = 12;
	private static Random random = new Random(); // A new randomizer

	public GoldFish(int age, double length, ArrayList<FishColorEnum> fishColor) {
		// Constructor for GoldFish
		super(age, length, fishColor, FishPrintEnum.SMOOTH);
	}

	public GoldFish(int age, int happiness, double length, ArrayList<FishColorEnum> color) {
		// Constructor for random fish
		super(age, length, color, FishPrintEnum.SMOOTH);
		this.happiness = happiness;
	}
	
	public GoldFish(int age, double length) {
		// Constructor for random fish
		super(age, length, generateRandomColor(), FishPrintEnum.SMOOTH);
	}

	/** Basic Methods */

	private static ArrayList<FishColorEnum> generateRandomColor() {
		int randomIndex = random.nextInt(FishColorEnum.goldFishColors().size());
		ArrayList<FishColorEnum> fishColor = new ArrayList<FishColorEnum>();
		fishColor.add(FishColorEnum.goldFishColors().get(randomIndex));
		return fishColor;
	}

	/** All Overridden Methods */

	@Override
	public double feed() {
		// Returns the number of portions this Fish eats
		this.happiness = 100;
		return 1;
	}

	@Override
	public void ageOneYear() throws SQLException {
		// Ages this Fish by one year
		if (this.age >= LIFESPAN) {
			this.alive = false;
			this.happiness = 0;
			return;
		}
		removeHappiness();
		this.age++;
	}

}
