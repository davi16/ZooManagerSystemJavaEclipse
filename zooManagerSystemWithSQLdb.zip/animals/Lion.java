package animals;

import animalEnums.GenderEnum;
import animalSuperClasses.Predator;

public class Lion extends Predator {

	public Lion(String name, int age, double weight, GenderEnum gender) {
		// Constructor
		super(name, age, weight, gender);
	}
	
	public Lion(String name, int age,int happiness, double weight, GenderEnum gender) {
		// Constructor
		super(name, age, weight, gender);
		this.happiness = happiness;
	}

	/**All Overridden Methods */
	
	@Override
	public double feed() {
		// Returns the amount of meat this Lion eats
		this.happiness = 100;
		return switch (this.gender) {
		case MALE -> (int) ((double) this.weight * this.age * 0.02 > 25 ? 25 : (int) this.weight * this.age * 0.02);
		case FEMALE -> (int) ((double) this.weight * this.age * 0.03 > 25 ? 25 : (int) this.weight * this.age * 0.03);
		};
	}

	@Override
	public String makeNoise() {
		// Returns the noise this Lion makes
		return "ROAR";
	}
}
