package animals;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import animalEnums.GenderEnum;
import animalSuperClasses.Mamal;
import dataBases.jdbc;

public class Panda extends Mamal {

	private final String ANSI_RESET = "\u001B[0m"; // Console black text color
	private final String ANSI_BOLD = "\u001B[1m";
	NumberFormat formatter = new DecimalFormat("#0.0");
	public static final int LIFESPAN = 20;
	private Panda father;
	private Panda mother;
	private Panda child;
	public int babyRelapseCounter;
	public int getBabyRelapseCounter() {
		return babyRelapseCounter;
	}

	public void setBabyRelapseCounter(int babyRelapseCounter) {
		this.babyRelapseCounter = babyRelapseCounter;
	}

	public boolean isCanMakeBaby() {
		return canMakeBaby;
	}

	public void setCanMakeBaby(boolean canMakeBaby) {
		this.canMakeBaby = canMakeBaby;
	}

	public boolean canMakeBaby = false;

	public Panda(String name, int age, double weight, GenderEnum gender) {
		// Constructor
		super(name, age, weight, gender);
		if (age > 6) {
			babyRelapseCounter = 3;
			canMakeBaby = true;
		}
		this.alive = true;
	}
	
	public Panda(String name, int age, double weight, GenderEnum gender , int babyRelapseCounter , boolean canMakeBaby , int happiness , Panda father , Panda mother , Panda child) {
		// Constructor
		super(name, age, weight, gender);
		this.babyRelapseCounter = babyRelapseCounter;
		this.canMakeBaby = canMakeBaby;
		this.happiness = happiness;
		this.alive = true;
		this.father = father;
		this.mother = mother;
		this.child = child;
	}

	/** Basic Methods */

	public Panda getFather() {
		// Returns the Panda saves as this Pandas father
		return father;
	}

	public void setFather(Panda father) {
		// Sets this Pandas father
		this.father = father;
	}

	public Panda getMother() {
		// Returns the Panda saves as this Pandas mother
		return mother;
	}

	public void setMother(Panda mother) {
		// Sets this Pandas mother
		this.mother = mother;
	}

	public Panda getChild() {
		// Returns the Panda saves as this Pandas child
		return child;
	}

	public void setChild(Panda child) {
		// Sets this Pandas child
		this.child = child;
	}

	public GenderEnum getGender() {
		// Returns this Pandas gender
		return gender;
	}

	public boolean isAlive() {
		// Returns the state of this Panda
		return alive;
	}

	public int getAge() {
		// Returns the age of this Panda
		return age;
	}

	/** All Overridden Methods */

	@Override
	public double feed() {
		// Returns the amount of bamboo this Panda eats
		this.happiness = 100;
		return 2;
	}

	@Override
	public String makeNoise() {
		// Returns the noise this Panda makes
		return "Grhahahah...hh";
	}

	@Override
	public void ageOneYear() throws SQLException {
		// Ages this Panda by 1 year
		if (this.age >= LIFESPAN) {
			this.alive = false;
			this.happiness = 0;
			return;
		}
		this.age++;
		if (age == 6) {
			babyRelapseCounter = 3;
			canMakeBaby = true;
		}
		if (age < 6) {
			weight += 10 + Math.random() * 15;
		}
		removeHappiness();
	}

	@Override
	public void removeHappiness() throws SQLException {
		// Removes happiness from this Panda
		this.happiness -= Math.random() * 30;
		if (this.happiness < 1) {
			this.alive = false;
			this.happiness = 0;
		}
		jdbc.updatePanda(this);
	}

	@Override
	public String toString(boolean consoleColor) {
		// Return all values of this Panda in string format
		if (consoleColor) {
			return ANSI_BOLD + "Type: " + ANSI_RESET + getClass().getSimpleName() + ANSI_BOLD + " Name: " + ANSI_RESET
					+ this.name + ANSI_BOLD + " Gender: " + ANSI_RESET + this.gender + ANSI_BOLD + " Age: " + ANSI_RESET
					+ this.age + ANSI_BOLD + " Weight: " + ANSI_RESET + formatter.format(this.weight) + ANSI_BOLD
					+ " Happiness: " + ANSI_RESET + happinessPrint();
		} else {
			return "Type: " + getClass().getSimpleName() + " Name: " + this.name + " Gender: " + this.gender + " Age: "
					+ this.age + " Weight: " + formatter.format(this.weight) + " Happiness: " + happiness;
		}
	}

}
