package animals;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import animalEnums.FishColorEnum;
import animalEnums.FishPrintEnum;
import animalSuperClasses.Fish;

public class AquariumFish extends Fish {
	public static final int LIFESPAN = 25;
	private static FishColorEnum[] fishColorValues = FishColorEnum.values(); // All available values for Fish print
	private static Random random = new Random(); // A new randomizer

	public AquariumFish(int age, double length, ArrayList<FishColorEnum> fishColors, FishPrintEnum fishPrint) {
		// Constructor for AquariumFish
		super(age, length, fishColors, fishPrint);
	}

	public AquariumFish(int age, double length, FishPrintEnum fishPrint, int numberOfColors) {
		// Constructor for random fish
		super(age, length, generateRandomColors(numberOfColors), fishPrint);

	}
	
	public AquariumFish(int age,int happiness, double length, FishPrintEnum fishPrint, ArrayList<FishColorEnum> numberOfColors) {
		// Constructor for random fish
		super(age, length, numberOfColors, fishPrint);
		this.alive = true;
		this.happiness = happiness;
	}

	/** Basic Methods */

	private static ArrayList<FishColorEnum> generateRandomColors(int randomColorNumber) {
		// The method returns a list with random fish colors
		int randomIndex;
		ArrayList<FishColorEnum> fishColors = new ArrayList<FishColorEnum>();
		for (int i = 0; i < randomColorNumber; i++) {
			randomIndex = random.nextInt(fishColorValues.length);
			while (fishColors.contains(fishColorValues[randomIndex]))
				randomIndex = random.nextInt(fishColorValues.length);
			fishColors.add(fishColorValues[randomIndex]);
		}
		return fishColors;
	}

	/** All Overridden Methods */

	@Override
	public double feed() {
		// Returns the number of portions this Fish eats
		this.happiness = 100;
		if (this.age < 3)
			return 3;
		else
			return this.length + 3;
	}

	@Override
	public void ageOneYear() throws SQLException {
		// Ages this Fish by one year
		if (this.age >= LIFESPAN) {
			this.alive = false;
			this.happiness = 0;
			return;
		}
		removeHappiness();
		this.age++;
	}

}
