package animalEnums;

public enum PandaNameEnum {
	// This enum contains all names available to Pandas
	Spot, Checkers, Oreo, Daisy, Piano, Penguin, Rocky, Keys, Puffin, Tumbles, Sushi, Sundae, Tux, Dice, Pepper, Orca,
	Figaro, Cookie, Harlequin, Bamboo, Dotty, Patches, Minnie, Nita, Precious, Kyra, Bella, Wilhelmina, Winona, Beara,
	Maddy, Millie, Bitsy, Maggie, Jumbo, Frankie, Polly, Fiona, Princess, Louise, Suzie, Ellie, Irene, Gypsy, Coco,
	Holiday, Nizie, Effie, Bruce, Bono, William, Eddie, Rupert, Rex, Jasper, Oscar, Barney, Franklin, Lex, Stevie,
	Lester, Dexter, Chad, Bobo, Bear, Knight, Charlie_Brown, Clover, Ernie, Berny, Moby, Ralph, Mr_Cuddlesworth,
	Frankenstein, Pumpkin, Bamboozled, Bowzer, Sir_Clings, Clutz, Teddy, Madam_Trips, Beethoven, Shaggy, Beary_Potter,
	Mops, Mr_Tubs, Bearly_Chubs, Hungry, Champ, Tubby_Tubs, Ding_Dong, Rollie_Pollie, Lazy_Bear, Bearly_There, Fluffy,
	Muffin_top, Pretzel, Fuzzy, Lucky, Noodle, Cuddlebug, Baloo, Buttons, Hugs, Bear_Hugz, Muppet, Sprinkles, Winnie,
	Socks, Baby, Twinkie, Chip, Buttercup, Squirt, Softie, Biscuit, Benji, Squishy, Snuggles, Bubbles, Apocalypse, Tank,
	Axel, Rambo, Bruiser, Rage, Hercules, Boomerang, Claw, Fang, Cruiser, Bruno, Arrow, Shade, Maverick, Zeus, Trigger,
	Killer, Atilla, Thunder, The_Rock, Hulk, Mei_Ziang, Xiang, Jake_The_Panda, Tai_Shan, Hong_Liu, Koo, Po, Mojo,
	Stormstout, Milton, Bao_Bao, Raiden, Er_Shun, Kungfu_Panda, Hau_Mei, Hei_Bai, Pandaren_Race, Hungry_Panda,
	Chen_Stormstout, Jing_King, Chou_Ling_Sing, Kolo, Shinjo_Greatpaw, Master_Yo, Bane, Ghost, Harley, Whiskey, Phoenix,
	Ryder, Galileo, Chase, Flint, Sarge, Blaze, Remi, Aspen, Jet, Kane, Duke, Silver, River, Gunner, Nixie, Dozer,
	Pirate, Jax, Luna;
}
