package animalEnums;

public enum FishPrintEnum {
	//This enum contains all prints available for Fish
	SPOTTED , STRIPED ,STAINED , SMOOTH;
	

}
