package animalEnums;

import java.util.ArrayList;
import java.util.Collection;

public enum FishColorEnum {
	// This enum contains all available colors for Fish
	BLACK("\033[0;30m", 0), WHITE("\033[0;37m", 0), GREEN("\033[0;32m", 0), ORANGE("\033[0;91m", 0),
	BLUE("\033[0;34m", 0), YELLOW("\033[0;33m", 0), BROWN("\033[0;90m", 0), GOLD("\033[0;93m", 0), RED("\033[0;31m", 0),
	CYAN("\033[0;36m", 0);

	private static final String ANSI_RESET = "\u001B[0m"; // Console black text color
	private String code; // The code representing the color in the console
	private int counter; // Counter for color instances

	private FishColorEnum(String code, int counter) {
		// Constructor
		this.code = code;
		this.counter = counter;
	}

	/**Basic Methods */
	
	public int getCounter() {
		// Returns the number of times this specific color was created
		return counter;
	}

	public void addToCounter(int counter) {
		// Counts the number of times this specific color was created
		this.counter += counter;
	}

	public String getCode() {
		// Returns the color code
		return this.code;
	}

	public static Collection<String> convertToColorfulList(Collection<FishColorEnum> originalList) {
		// Converts an enum list of color to the corresponding color code
		ArrayList<String> newList = new ArrayList<String>();
		for (FishColorEnum color : originalList) {
			newList.add(color.getCode() + color.name() + ANSI_RESET);
		}

		return newList;
	}

	public static ArrayList<FishColorEnum> goldFishColors() {
		// Creates a new arraylist containing all available color for gold fish
		ArrayList<FishColorEnum> goldColors = new ArrayList<FishColorEnum>();
		goldColors.add(ORANGE);
		goldColors.add(YELLOW);
		goldColors.add(GOLD);
		goldColors.add(BLACK);
		return goldColors;
	}
}