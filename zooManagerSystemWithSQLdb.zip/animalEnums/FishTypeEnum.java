package animalEnums;

public enum FishTypeEnum {
	// This enum contains all types available to Fish
	AQUARIUM, GOLD, CLOWN;

}
