package dataStractures;

import animals.Penguin;

//This class is responsible to create a new node in the Tree that contains a Penguin as its main value,
//the Penguin that is taller as the parameter in its left position 
//and the shorter Penguin in its right position
public class PenguinLineNode {
	//// PenguinLineNodes basic parameters
	private Penguin value;
	private PenguinLineNode left;
	private PenguinLineNode right;

	public PenguinLineNode(Penguin penguin) {
		// Constructor
		this.value = penguin;
	}

	public Penguin getPenguin() {
		// Returns the current Penguin
		return value;
	}

	public PenguinLineNode getLeft() {
		// Returns the Penguin taller from the current
		return left;
	}

	public void setLeft(PenguinLineNode taller) {
		// Sets the Penguin taller from the current
		this.left = taller;
	}

	public PenguinLineNode getRight() {
		// Returns the Penguin shorter from the current
		return right;
	}

	public void setRight(PenguinLineNode shorter) {
		// Sets the Penguin shorter from the current
		this.right = shorter;
	}

	public void setPenguin(Penguin penguin) {
		// Sets the value of the current Penguin
		this.value = penguin;
	}

}