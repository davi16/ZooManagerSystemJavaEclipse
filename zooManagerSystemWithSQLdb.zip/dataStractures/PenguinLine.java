package dataStractures;

import java.sql.SQLException;

import animals.Penguin;
import dataBases.jdbc;

//This class is responsible for creating a new Penguin Tree that contains all the Penguins ordered by Height (from tallest to shortest)
public class PenguinLine {
	// PenguinLines basic parameters
	private PenguinLineNode root;
	public static boolean arrangePinguinByName;
	public static boolean arrangePinguinByHeight;
	public static boolean arrangePinguinByAge;
	public static Penguin leader;

	public PenguinLine() throws SQLException {
		// Constructor
		arrangePinguinByHeight = true;
		jdbc.initializePenguins(this, this.root);
	}
	public void initialize(Penguin penguin) throws SQLException {
		this.root = this.addByHeight(this.root, penguin);
	}
	public void add(Penguin penguin) throws SQLException {
		// Add a new Penguin to the line
		jdbc.addPenguin(penguin);
		if (arrangePinguinByHeight) {
			this.root = this.addByHeight(this.root, penguin);
		}
		if (arrangePinguinByAge) {
			this.root = this.addByAge(this.root, penguin);
		}
		if (arrangePinguinByName) {
			this.root = this.addByName(this.root, penguin);
		}
	}

	public PenguinLineNode addByHeight(PenguinLineNode node, Penguin penguin) throws SQLException {
		// Sorting the Penguin added by height
		if (node == null) {
			return new PenguinLineNode(penguin);
		} else if (penguin.getHeight() > node.getPenguin().getHeight()) {
			node.setLeft(addByHeight(node.getLeft(), penguin));
		} else if (penguin.getHeight() <= node.getPenguin().getHeight()) {
			node.setRight(addByHeight(node.getRight(), penguin));
		}
		return node;
	}

	private PenguinLineNode addByAge(PenguinLineNode node, Penguin penguin) throws SQLException {
		// Sorting the Penguin added by age
		if (node == null) {
			return new PenguinLineNode(penguin);
		} else if (penguin.getAge() > node.getPenguin().getAge()) {
			node.setRight(addByAge(node.getRight(), penguin));
		} else if (penguin.getAge() <= node.getPenguin().getAge()) {
			node.setLeft(addByAge(node.getLeft(), penguin));
		}
		return node;
	}

	private PenguinLineNode addByName(PenguinLineNode node, Penguin penguin) throws SQLException {
		// Sorting the Penguin added by name
		if (node == null) {
			return new PenguinLineNode(penguin);
		} else if (penguin.getName().compareTo(node.getPenguin().getName()) > 0) {
			node.setRight(addByName(node.getRight(), penguin));
		} else if (penguin.getName().compareTo(node.getPenguin().getName()) <= 0) {
			node.setLeft(addByName(node.getLeft(), penguin));
		}
		return node;
	}

	public void sortByHeight() throws SQLException {
		// Rearranges the current line by height
		arrangePinguinByHeight = true;
		arrangePinguinByAge = false;
		arrangePinguinByName = false;
		PenguinLineNode temp = this.root;
		this.root = null;
		makeNew(temp);

	}

	public void sortByAge() throws SQLException {
		// Rearranges the current line by age
		arrangePinguinByHeight = false;
		arrangePinguinByAge = true;
		arrangePinguinByName = false;
		PenguinLineNode temp = this.root;
		this.root = null;
		makeNew(temp);
	}

	public void sortByName() throws SQLException {
		// Rearranges the current line by name
		arrangePinguinByHeight = false;
		arrangePinguinByAge = false;
		arrangePinguinByName = true;
		PenguinLineNode temp = this.root;
		this.root = null;
		makeNew(temp);
	}

	private void makeNew(PenguinLineNode node) throws SQLException {
		// Saves a new line into this root from input node
		if (node != null) {
			makeNew(node.getLeft());
			add(node.getPenguin());
			makeNew(node.getRight());
		}
	}

	public void remove(Penguin penguin) {
		// Add a new Penguin to the line
		this.root = this.remove(this.root, penguin);
	}

	private PenguinLineNode remove(PenguinLineNode node, Penguin penguin) {
		// Sorting the Penguin added by height
		if (node != null) {
			if (node.getPenguin().equals(penguin)) {
				if (node.getLeft() != null) {
					node = node.getLeft();

				} else if (node.getRight() != null) {
					node = node.getRight();
				} else {
					node = null;
				}
			} else {
				node.setLeft(remove(node.getLeft(), penguin));
				node.setRight(remove(node.getRight(), penguin));
			}
		}
		return node;
	}

	public int countPenguinsInLine() {
		// Counts how many Penguins are in the line
		int count = 0;
		return this.countPenguinsInLine(this.root, count);
	}

	public int countPenguinsInLine(PenguinLineNode node, int count) {
		// Counts how many Penguins are in the tree
		if (node != null) {
			count++;
			count = countPenguinsInLine(node.getLeft(), count);
			count = countPenguinsInLine(node.getRight(), count);
		}
		return count;
	}

	public double getLeaderHeight() {
		return getLeaderHeight(this.root);
	}

	public double getLeaderHeight(PenguinLineNode node) {
		// Returns the height of the leading Penguin in the line
		if (node != null) {
			leader = node.getPenguin();
			getLeaderHeight(node.getLeft());
			getLeaderHeight(node.getRight());
			if (node.getPenguin().getHeight() > leader.getHeight())
				leader = node.getPenguin();
			return leader.getHeight();
		} else {
			return 1000.0;
		}
	}

	public void printPenguins() {
		// Prints all Penguins
		this.printPenguins(this.root);
	}

	private void printPenguins(PenguinLineNode node) {
		// Prints the whole Tree by order
		if (node != null) {
			printPenguins(node.getLeft());
			System.out.println(node.getPenguin().toString(true));
			printPenguins(node.getRight());
		}
	}

	public String noise() {
		// Making all Penguins make noise
		String noise = "";
		return this.noise(this.root, noise);
	}

	private String noise(PenguinLineNode node, String noise) {
		// Going through the Penguin line and getting each Penguins sound
		if (node != null) {
			noise += node.getPenguin().makeNoise() + " ";
			noise = noise(node.getLeft(), noise);
			noise = noise(node.getRight(), noise);
		}
		return noise;
	}

	public double feed() {
		// Returns the amount of fish this line eats
		double fish = 0;
		return this.feed(this.root, fish);
	}

	private double feed(PenguinLineNode node, double fish) {
		// Gets the amount of fish this line eats
		if (node != null) {
			fish += node.getPenguin().feed();
			fish = feed(node.getLeft(), fish);
			fish = feed(node.getRight(), fish);
		}
		return fish;
	}

	public String ageAllPenguins(boolean color) throws SQLException {
		// Ages all the line by one year
		String output = "";
		return ageAllPenguins(this.root, output, color);
	}

	private String ageAllPenguins(PenguinLineNode node, String output, boolean color) throws SQLException {
		// Ages each Penguins saved in this line individually
		if (node != null) {
			node.getPenguin().ageOneYear();
			if (!node.getPenguin().isAlive()) {
				output += node.getPenguin().toString(color) + "\n";
				this.remove(node.getPenguin());
			}
			output = ageAllPenguins(node.getLeft(), output, color);
			output = ageAllPenguins(node.getRight(), output, color);
		}
		return output;
	}

	public String removeHappiness(boolean color) throws SQLException {
		// TODO Auto-generated method stub
		String output = "";
		return removeHappiness(this.root, output, color);
	}

	private String removeHappiness(PenguinLineNode node, String output, boolean color) throws SQLException {
		// TODO Auto-generated method stub
		if (node != null) {
			node.getPenguin().removeHappiness();
			if (!node.getPenguin().isAlive()) {
				output += node.getPenguin().toString(color) + " ";
				this.remove(node.getPenguin());
			}
			output = removeHappiness(node.getLeft(), output, color);
			output = removeHappiness(node.getRight(), output, color);
		}
		return output;
	}

}
