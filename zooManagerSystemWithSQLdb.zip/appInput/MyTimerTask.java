package appInput;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.EventListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import mainPackage.Application;

public class MyTimerTask extends TimerTask implements EventListener {

	public Timer timer = new Timer(true); // New timer
	// A timer that sends a massage to remind to feed the animals
	JFrame popup;
	JFrame popup2;
	JFrame popup3 = new JFrame();
	JFrame popup4;
	JButton buttonFeed;
	JButton buttonIgnore;

	@Override
	public void run() {
		popup = new JFrame("WARNING");
		popup.setAlwaysOnTop(true);
		JPanel panel1 = new JPanel();
		buttonFeed = new JButton();
		buttonIgnore = new JButton();
		JLabel mainLabel = new JLabel("All animals are getting hungry!\n");
		panel1.setLayout(new FlowLayout());
		panel1.add(mainLabel);
		panel1.add(buttonFeed);
		panel1.add(buttonIgnore);
		popup.add(panel1);
		buttonFeed.setText("Feed");
		buttonFeed.addActionListener(feedButton);
		buttonIgnore.setText("Ignore");
		buttonIgnore.addActionListener(ignoreButton);
		popup.setSize(250, 100);
		popup.setLocationRelativeTo(null);
		popup.setResizable(false);
		popup.setVisible(true);

		popup.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

	}

	ActionListener feedButton = new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			popup.dispose();
			popup3.dispose();
			popup2 = new JFrame();
			JPanel panel2 = new JPanel();
			panel2.setLayout(new FlowLayout());
			popup2.setSize(250, 100);
			popup2.setLocationRelativeTo(null);
			popup2.setResizable(false);
			popup2.setVisible(true);
			popup2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			try {
				Application.myZoo.numberOfMealsLions();
				Application.myZoo.numberOfMealsTigers();
				Application.myZoo.numberOfMealsAquariumFish();
				Application.myZoo.numberOfMealsGoldFish();
				Application.myZoo.numberOfMealsClownFish();
				Application.myZoo.numberOfMealsElephants();
				Application.myZoo.numberOfMealsPandas();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Application.myZoo.countPenguinsInLine();
			JLabel fedLabel = new JLabel("You fed the animals, they are happy :)");
			panel2.add(fedLabel);
			popup2.add(panel2);
			JButton buttonOK = new JButton();
			buttonOK.setText("OK");
			ActionListener okButton = new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					popup2.dispose();
				}
			};
			buttonOK.addActionListener(okButton);
			panel2.add(buttonOK);
		}
	};
	ActionListener ignoreButton = new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			popup.dispose();
			JPanel panel2 = new JPanel();
			panel2.setLayout(new FlowLayout());
			popup3.setSize(250, 100);
			popup3.setLocationRelativeTo(null);
			popup3.setResizable(false);
			popup3.setVisible(true);
			popup3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			JLabel ignorelabel = new JLabel("Are you sure? the animals will be sad :(");
			panel2.add(ignorelabel);
			popup3.add(panel2);
			JButton buttonYes = new JButton();
			buttonYes.setText("YES");
			ActionListener yesButton = new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					popup3.dispose();
					popup4 = new JFrame();
					JPanel panel3 = new JPanel();
					panel3.setLayout(new FlowLayout());
//					String output = Application.myZoo.makeAnimalsHungry();
//					if (output == "All animals are fine, for now.\n") {
//						JLabel yeslabel = new JLabel(output);
//						popup4.setSize(250, 100);
//						panel3.add(yeslabel);
//					} else {
//						JLabel yeslabel = new JLabel();
//						yeslabel.setText("<html><body>"
//								+ output.replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\n", "<br/>")
//								+ "</body></html>");
//						popup4.setSize(800, 200);
//						panel3.add(yeslabel);
//					}
					popup4.add(panel3);
					popup4.setLocationRelativeTo(null);
					popup4.setResizable(false);
					popup4.setVisible(true);
					popup4.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					new Timer().schedule(new TimerTask() {
						public void run() {
							popup4.dispose();
						}
					}, 5000);
				}
			};

			buttonYes.addActionListener(yesButton);
			buttonFeed = new JButton();
			buttonFeed.setText("Feed");
			panel2.add(buttonFeed);
			panel2.add(buttonYes);
			buttonFeed.addActionListener(feedButton);

		}
	};
}
