package ticketSearch;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.*;

import dataBases.*;
import humanRoles.Visitor;
import visitorManagement.VisitorManagementMenu;

public class SearchPanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTextField visitorID;
	JButton show;
	JLabel warning;
	VisitorManagementMenu myMenu;

	public SearchPanel(VisitorManagementMenu menu) {
		myMenu = menu;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		add(Box.createRigidArea(new Dimension(0, 10)));

		JPanel inside = new JPanel();
		inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
		inside.setMaximumSize(new Dimension(300, 30));
		inside.setAlignmentX(CENTER_ALIGNMENT);
		add(inside);

		JLabel visitorId = new JLabel("Enter visitor ID: ");
		inside.add(visitorId);

		visitorID = new JTextField(9); // set length of the text
		visitorID.setMaximumSize(new Dimension(150, 30));
		inside.add(visitorID);

		show = new JButton("Show");
		show.setBorder(BorderFactory.createEtchedBorder());
		show.setMaximumSize(new Dimension(100, 30));
		show.addActionListener(this);
		inside.add(show);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == show) {
			String visiID = visitorID.getText(); // get user entered username from textField1
			Visitor found;
			try {
				found = jdbc.findVisitor(visiID);
				if (found != null) {
					removeAll();
					add(Box.createRigidArea(new Dimension(0, 10)));
					JLabel visitorInfo = new JLabel("Visitor: " + found.toString() + ", active tickets are:");
					visitorInfo.setAlignmentX(CENTER_ALIGNMENT);
					add(visitorInfo);
					add(Box.createRigidArea(new Dimension(0, 50)));
					myMenu.searchTicket(visiID);
					return;
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if (warning == null) {
				Toolkit.getDefaultToolkit().beep();
				visitorID.requestFocusInWindow();
				visitorID.setText("");
				warning = new JLabel("ID not found!");
				warning.setForeground(Color.RED);
				warning.setAlignmentX(CENTER_ALIGNMENT);
				add(warning);
				myMenu.repaint();
			}
		}
	}

}
