package ticketHistory;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import javax.swing.*;

import dataBases.*;
import ticket.Ticket;
import visitorManagement.VisitorManagementMenu;

public class TicketHistoryPanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton cancel, again;
	JList<Ticket> list;
	DefaultListModel<Ticket> listModel;
	VisitorManagementMenu myMenu; 

	TicketHistoryPanel(VisitorManagementMenu menu, String ID) throws SQLException {
		myMenu = menu;
		setAlignmentX(CENTER_ALIGNMENT);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		listModel = new DefaultListModel<>();
		ArrayList<Ticket> tickets = jdbc.findTickets(ID);
		sortTicketsByDate(tickets);
		for (Ticket ticket : tickets)
			listModel.addElement(ticket);

		// Create the list and put it in a scroll pane.
		list = new JList<Ticket>(listModel);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.setSelectedIndex(0);
		list.setVisibleRowCount(5);

		JScrollPane listScrollPane = new JScrollPane(list);
		listScrollPane.setMaximumSize(new Dimension(1200, 100));
		listScrollPane.setAlignmentX(CENTER_ALIGNMENT);
		add(listScrollPane);

        again = new JButton("Go back");
        again.setBorder(BorderFactory.createEtchedBorder());
        again.setMaximumSize(new Dimension(100, 30));
        again.setAlignmentX(CENTER_ALIGNMENT);
        again.addActionListener(this);
		add(again);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == again) {
			myMenu.dispose();
			try {
				myMenu = new VisitorManagementMenu();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			myMenu.repaint();
		}
	}
	
	public static void sortTicketsByDate(ArrayList<Ticket> tickets) {

		Comparator<Ticket> compareByDate = new Comparator<Ticket>() {

			@Override
			public int compare(Ticket t1, Ticket t2) {
				int rv;
				if (t1.getCreationDate().isAfter(t2.getCreationDate()))
					rv = -1;
				else if (t1.getCreationDate().isBefore(t2.getCreationDate()))
					rv = 1;
				else
					rv = 0;
				return rv;
			}
		};
		Collections.sort(tickets, compareByDate);
	}
}
