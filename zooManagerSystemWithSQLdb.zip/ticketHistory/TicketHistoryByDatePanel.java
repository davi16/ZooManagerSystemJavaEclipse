package ticketHistory;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.*;

import dataBases.*;
import ticket.Ticket;
import visitorManagement.*;

public class TicketHistoryByDatePanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static JTextField purchaseD;
	JButton show, reload;
	JLabel warning;
	JList<Ticket> list;
	DefaultListModel<Ticket> listModel;
	VisitorManagementMenu myMenu;

	public TicketHistoryByDatePanel(VisitorManagementMenu menu) {
		myMenu = menu;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		add(Box.createRigidArea(new Dimension(0, 10)));

		JPanel inside = new JPanel();
		inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
		inside.setMaximumSize(new Dimension(300, 30));
		inside.setAlignmentX(CENTER_ALIGNMENT);
		add(inside);

		JLabel purchaseDate = new JLabel("Enter date (dd.MM.yyyy):");
		inside.add(purchaseDate);

		purchaseD = new JTextField(9); // set length of the text
		purchaseD.setMaximumSize(new Dimension(150, 30));
		inside.add(purchaseD);

		show = new JButton("Show");
		show.setBorder(BorderFactory.createEtchedBorder());
		show.setMaximumSize(new Dimension(100, 30));
		show.addActionListener(this);
		inside.add(show);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == show) {
			LocalDate purID = scanToLocalDate(purchaseD.getText()); // get user entered username from textField1
			if (purID == null) {
				Toolkit.getDefaultToolkit().beep();
				purchaseD.requestFocusInWindow();
				if (warning == null) {
					warning = new JLabel("You need to enter something else");
					warning.setForeground(Color.RED);
					warning.setAlignmentX(CENTER_ALIGNMENT);
					add(warning);
				}
				myMenu.repaint();
				return;
			}
			if (purID != null) {
				removeAll();
				add(Box.createRigidArea(new Dimension(0, 10)));
				listModel = new DefaultListModel<>();
				try {
					for (Ticket ticket : jdbc.getTicketsByDate(purID))
						listModel.addElement(ticket);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				// Create the list and put it in a scroll pane.
				list = new JList<Ticket>(listModel);
				list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				list.setSelectedIndex(0);
				list.setVisibleRowCount(5);

				JScrollPane listScrollPane = new JScrollPane(list);
				listScrollPane.setMaximumSize(new Dimension(1200, 100));
				listScrollPane.setAlignmentX(CENTER_ALIGNMENT);
				add(listScrollPane);
				
				reload = new JButton("Go back");
				reload.setBorder(BorderFactory.createEtchedBorder());
				reload.setMaximumSize(new Dimension(100, 30));
				reload.setAlignmentX(CENTER_ALIGNMENT);
				reload.addActionListener(this);
				add(reload);
			}
		}
		if (e.getSource() == reload) {
			myMenu.dispose();
			try {
				myMenu = new VisitorManagementMenu();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			myMenu.repaint();
		}
	}

	public LocalDate scanToLocalDate(String dateS) {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
			return LocalDate.parse(dateS, formatter);
		} catch (Exception e) {
			return null;
		}
	}

}
