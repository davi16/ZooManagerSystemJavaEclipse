package parkEntranceHistory;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

import dataBases.*;
import parkEntrance.*;
import visitorManagement.VisitorManagementMenu;

public class EntranceHistoryPanel  extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton cancel, again;
	JList<Entrance> list;
	DefaultListModel<Entrance> listModel;
	VisitorManagementMenu myMenu; 

	EntranceHistoryPanel(VisitorManagementMenu menu, String ID) throws SQLException {
		myMenu = menu;
		setAlignmentX(CENTER_ALIGNMENT);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		listModel = new DefaultListModel<>();
		ArrayList<Entrance> entrances = jdbc.findEntrances(ID);
		for (Entrance entrance : entrances)
			listModel.addElement(entrance);

		// Create the list and put it in a scroll pane.
		list = new JList<Entrance>(listModel);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.setSelectedIndex(0);
		list.setVisibleRowCount(5);

		JScrollPane listScrollPane = new JScrollPane(list);
		listScrollPane.setMaximumSize(new Dimension(1200, 100));
		listScrollPane.setAlignmentX(CENTER_ALIGNMENT);
		add(listScrollPane);

        again = new JButton("Go back");
        again.setBorder(BorderFactory.createEtchedBorder());
        again.setMaximumSize(new Dimension(100, 30));
        again.setAlignmentX(CENTER_ALIGNMENT);
        again.addActionListener(this);
		add(again);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == again) {
			myMenu.dispose();
			try {
				myMenu = new VisitorManagementMenu();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			myMenu.repaint();
		}
	}
	
	

}
