package visitorPayment;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import visitorManagement.VisitorManagementMenu;

public class PaymentPanel extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int myAmount;
	JButton cash, card;
	VisitorManagementMenu myMenu;
	
	
	public PaymentPanel(VisitorManagementMenu menu, int amount) {
		myMenu = menu;
		myAmount = amount;
		setAlignmentX(CENTER_ALIGNMENT);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		JPanel inside = new JPanel();
		inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
		inside.setAlignmentX(CENTER_ALIGNMENT);
		inside.setMaximumSize(new Dimension(200, 30));
		add(inside);

		cash = new JButton("By cash");
		cash.setBorder(BorderFactory.createEtchedBorder());
		cash.setMaximumSize(new Dimension(100, 30));
		//cash.setAlignmentX(CENTER_ALIGNMENT);
		cash.addActionListener(this);
		inside.add(cash);

		card = new JButton("By card");
		card.setBorder(BorderFactory.createEtchedBorder());
		card.setMaximumSize(new Dimension(100, 30));
		//card.setAlignmentX(CENTER_ALIGNMENT);
		card.addActionListener(this);
		inside.add(card);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == cash) {
			PaymentGateway cashGateway = new CashAdapter(new Cash());
			cashGateway.processPayment(myAmount);
			removeAll();
			add(new SuccessfulPaymentPanel(myMenu));
			myMenu.repaint();
		}
		if (e.getSource() == card) {
			PaymentGateway cardGateway = new CreditCardAdapter(new CreditCard());
			cardGateway.processPayment(myAmount);
			removeAll();
			add(new SuccessfulPaymentPanel(myMenu));
			myMenu.repaint();
		}
	}

}
