package visitorPayment;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public interface PaymentGateway {
	//Adapter design pattern 
    void processPayment(int amount);
}
