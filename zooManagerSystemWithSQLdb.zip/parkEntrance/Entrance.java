package parkEntrance;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.time.LocalDate;
import java.time.LocalTime;

import ticket.Ticket;
import ticket.TicketStatusEnum;

public class Entrance {

	private Ticket ticket;
	private LocalDate entranceDate;
	private LocalTime entranceTime;

	public Entrance(Ticket ticket, LocalDate entranceDate, LocalTime entranceTime) {
		// Constructor
		this.ticket = ticket;
		this.entranceDate = entranceDate;
		this.entranceTime = entranceTime;
		this.ticket.setCanCancel(false);
		if (ticket.getType().getCode().charAt(0) != 'Y')
			ticket.setStatus(TicketStatusEnum.USED);
	}

	public Ticket getTicket() {
		return ticket;
	}

	public LocalDate getEntranceDate() {
		return entranceDate;
	}

	public LocalTime getEntranceTime() {
		return entranceTime;
	}

	@Override
	public String toString() {
		return "Entrance: ticket:" + " Number: " + ticket.getNumber() + " ,ID: " + ticket.getHolderID() + ", Type: "
				+ ticket.getType() + ", entranceDate:" + entranceDate + ", entranceTime:" + entranceTime;
	}
}
