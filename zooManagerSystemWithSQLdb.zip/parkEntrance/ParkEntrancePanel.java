package parkEntrance;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import dataBases.*;
import ticket.Ticket;
import ticket.TicketStatusEnum;
import visitorManagement.VisitorManagementMenu;

public class ParkEntrancePanel extends JPanel implements ActionListener, ListSelectionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton enter, again;
	JList<Ticket> list;
	DefaultListModel<Ticket> listModel;
	VisitorManagementMenu myMenu;
	String myID;

	public ParkEntrancePanel(VisitorManagementMenu menu, String ID) throws SQLException {
		myMenu = menu;
		myID = ID;
		setAlignmentX(CENTER_ALIGNMENT);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		listModel = new DefaultListModel<>();
		for (Ticket ticket : jdbc.fintActiveTickets(myID))
			listModel.addElement(ticket);

		// Create the list and put it in a scroll pane.
		list = new JList<Ticket>(listModel);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.setSelectedIndex(0);
		list.addListSelectionListener(this);
		list.setVisibleRowCount(5);

		JScrollPane listScrollPane = new JScrollPane(list);
		listScrollPane.setMaximumSize(new Dimension(1200, 150));
		listScrollPane.setAlignmentX(CENTER_ALIGNMENT);
		add(listScrollPane);

		JPanel inside = new JPanel();
		inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
		inside.setAlignmentX(CENTER_ALIGNMENT);
		inside.setMaximumSize(new Dimension(200, 30));
		add(inside);

		enter = new JButton("Enter zoo");
		enter.setBorder(BorderFactory.createEtchedBorder());
		enter.setMaximumSize(new Dimension(100, 30));
		enter.setAlignmentX(CENTER_ALIGNMENT);
		enter.addActionListener(this);
		inside.add(enter);

		again = new JButton("Go back");
		again.setBorder(BorderFactory.createEtchedBorder());
		again.setMaximumSize(new Dimension(100, 30));
		again.setAlignmentX(CENTER_ALIGNMENT);
		again.addActionListener(this);
		inside.add(again);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == enter) {
			int index = list.getSelectedIndex();
			list.setForeground(Color.red);
			Ticket enter = listModel.get(index);
			if (enter.getStatus() == TicketStatusEnum.USED) {
				this.enter.setEnabled(false);
				myMenu.repaint();
			}	
			else {
				Entrance entrance = new Entrance(enter, LocalDate.now(), LocalTime.now());
				try {
					jdbc.addEntrance(entrance);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JLabel entranceInfo = new JLabel(entrance.toString());
				entranceInfo.setAlignmentX(CENTER_ALIGNMENT);
				add(entranceInfo);
				enter.setStatus(TicketStatusEnum.USED);
				try {
					jdbc.updateTicket(enter);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				myMenu.repaint();
			}
		}
		if (e.getSource() == again) {
			myMenu.dispose();
			try {
				myMenu = new VisitorManagementMenu();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			myMenu.repaint();
			return;
		}
	}

	public void valueChanged(ListSelectionEvent e) {
		if (e.getValueIsAdjusting() == false) {

			if (list.getSelectedIndex() == -1) {
				// No selection, disable fire button.
				enter.setEnabled(false);

			} else {
				// Selection, enable the fire button.
				enter.setEnabled(true);
			}
		}
	}
}