package animalExceptions;

public class PandaArrayFullException extends Exception {

	/**
	 * An exception for trying to add a Panda when the zoo capacity of Pandas is already met
	 */
	private static final long serialVersionUID = 1L;

	public PandaArrayFullException(String errorMessage) {
		// Constructor
		super(errorMessage);
	}

}
