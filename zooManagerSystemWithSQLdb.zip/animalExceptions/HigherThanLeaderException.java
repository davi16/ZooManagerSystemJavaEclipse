package animalExceptions;

public class HigherThanLeaderException extends Exception {

	/**
	 * An exception for trying to add an penguin higher than the leader
	 */
	private static final long serialVersionUID = 1L;

	public HigherThanLeaderException(String errorMessage) {
		// Constructor
		super(errorMessage);
	}

}
