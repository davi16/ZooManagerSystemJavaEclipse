package animalExceptions;

public class OlderThanMatriarchException extends Exception {
	
	/**
	 * An exception for trying to add an Elephant older than the matriarch
	 */
	private static final long serialVersionUID = 1L;

	public OlderThanMatriarchException(String errorMessage) {
		// Constructor
		super(errorMessage);
	}

}
