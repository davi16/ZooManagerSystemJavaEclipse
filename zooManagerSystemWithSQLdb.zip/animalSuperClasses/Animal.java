package animalSuperClasses;

import java.sql.SQLException;

public interface Animal {

	public double feed();

	public String makeNoise();

	public void ageOneYear() throws SQLException;

	void removeHappiness() throws SQLException;

	public String toString(boolean consoleColor);
}
