package animalSuperClasses;

import animalEnums.GenderEnum;

public abstract class Mamal implements Animal {

	protected String name;
	protected int age;
	protected double weight;
	protected GenderEnum gender;
	
	protected boolean alive;
	protected int happiness = 100;

	protected Mamal(String name, int age, double weight, GenderEnum gender) {
		// Constructor
		this.name = name;
		this.age = age;
		this.weight = weight;
		this.gender = gender;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public GenderEnum getGender() {
		return gender;
	}

	public void setGender(GenderEnum gender) {
		this.gender = gender;
	}

	public boolean isAlive() {
		return alive;
	}

	public void setAlive(boolean alive) {
		this.alive = alive;
	}

	public int getHappiness() {
		return happiness;
	}

	public void setHappiness(int happiness) {
		this.happiness = happiness;
	}

	/**Basic Methods */
	
	protected String happinessPrint() {
		// Changes the happiness print color based on its value
		if (happiness > 80)
			return "\033[0;32m" + happiness + "\033[0;30m";
		else if (happiness <= 80 && happiness > 60)
			return "\033[0;33m" + happiness + "\033[0;30m";
		else if (happiness <= 60 && happiness > 30)
			return "\033[0;91m" + happiness + "\033[0;30m";
		else
			return "\033[0;31m" + happiness + "\033[0;30m";
	}

}
