package dataBases;

import java.sql.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

import animalEnums.*;
import animalExceptions.PandaArrayFullException;
import animalSuperClasses.*;
import animals.AquariumFish;
import animals.ClownFish;
import animals.Elephant;
import animals.GoldFish;
import animals.Lion;
import animals.Panda;
import animals.Penguin;
import animals.Tiger;
import dataStractures.PenguinLine;
import dataStractures.PenguinLineNode;
import humanRoles.*;
import mainPackage.Application;
import parkEntrance.Entrance;
import ticket.Ticket;
import ticket.TicketOptionEnum;
import ticket.TicketPrice;
import ticket.TicketPriceMemento;

public class jdbc {
	static Connection conn = null;
	static PreparedStatement checkEmployee, findEmployee, findVisitor, getAllVisitors, addVisitor, findTickets,
			ticketsByDate, activeTickets, deletePreviousTicket, addTicket, findEntrances, entrancesByDate, addEntrance;
	static PreparedStatement addFish, updateFish, getFish, addPanda, updatePanda, relapsePandas, checkHowManyPandas,
			findFathers, findMothers, findPanda, getPandas, addElephant, updateElephant, checkHowManyElephants,
			getElephants, getElephantsByAge, addPredator, updatePredator, getPredators, addPenguin, updatePenguin,
			initializePenguins;
	public static TicketPrice price = new TicketPrice();
	public static TicketPriceMemento save = price.saveMemento();
	static NumberFormat formatter = new DecimalFormat("#0.00");
	static String elephantOrder;

	static final String ANSI_RED = "\u001B[31m"; // Console red text color
	static final String ANSI_BOLD = "\u001B[1m"; // Console bold text
	static final String ANSI_RESET = "\u001B[0m"; // Console black text color

	public jdbc() {
		try {
			Class.forName("org.postgresql.Driver");
			String dbUrl = "jdbc:postgresql:postgres";
			conn = DriverManager.getConnection(dbUrl, "postgres", "afeka");
			checkEmployee = conn
					.prepareStatement("SELECT * FROM user_data JOIN employee_data USING (username) WHERE password = ?");
			findEmployee = conn
					.prepareStatement("SELECT * FROM user_data JOIN employee_data USING (username) WHERE username = ?");
			findVisitor = conn.prepareStatement("SELECT * FROM visitor_data WHERE ID = ?");
			getAllVisitors = conn.prepareStatement("SELECT * FROM visitor_data");
			addVisitor = conn.prepareStatement(
					"INSERT INTO visitor_data(ID , first_name , last_name , phone_number , date_of_birth , distribute) VALUES (? , ? , ? , ? , ? , ?)");
			findTickets = conn.prepareStatement(
					"SELECT * FROM visitor_data JOIN ticket_data ON visitor_data.ID = ticket_data.holder_id WHERE ID = ?");
			ticketsByDate = conn.prepareStatement("SELECT * FROM ticket_data WHERE creation_date = ?");
			activeTickets = conn.prepareStatement("SELECT * FROM ticket_data WHERE holder_id = ? AND status = 'A'");
			deletePreviousTicket = conn.prepareStatement("DELETE FROM ticket_data WHERE number = ?");
			addTicket = conn.prepareStatement(
					"INSERT INTO ticket_data(number , holder_id , type_code , price , can_cancel , creation_date , expiration_date , status) VALUES (? , ? , ? , ? , ? , ? , ? , ?)");
			findEntrances = conn.prepareStatement(
					"SELECT * FROM entrance_data JOIN ticket_data ON entrance_data.ticket_id = ticket_data.number WHERE holder_id = ?");
			entrancesByDate = conn.prepareStatement(
					"SELECT * FROM entrance_data JOIN ticket_data ON entrance_data.ticket_id = ticket_data.number WHERE entrance_date = ?");
			addEntrance = conn.prepareStatement(
					"INSERT INTO entrance_data(ticket_id , entrance_date , entrance_time) VALUES (? , ? , ?)");
			addFish = conn.prepareStatement(
					"INSERT INTO fish_data (age , length , color , print , type) VALUES (? , ? , ? , ? , ?)");
			updateFish = conn.prepareStatement(
					"UPDATE fish_data SET age = ? , alive = ? , happiness = ? WHERE length = ? AND print = ?");
			getFish = conn.prepareStatement("SELECT * FROM fish_data WHERE alive = 'Y'");
			addPanda = conn.prepareStatement(
					"INSERT INTO panda_data (age , name , weight , gender , father , mother , child, baby_relapse_counter, can_make_baby) VALUES (? , ? , ? , ? , ?, ?, ?, ?, ?)");
			updatePanda = conn.prepareStatement(
					"UPDATE panda_data SET age = ? , alive = ? , happiness = ? , child = ? , baby_relapse_counter = ? , can_make_baby = ? WHERE name = ?");
			relapsePandas = conn
					.prepareStatement("UPDATE panda_data SET baby_relapse_counter = baby_relapse_counter + 1");
			checkHowManyPandas = conn.prepareStatement("SELECT count(*) FROM panda_data");
			findFathers = conn.prepareStatement(
					"SELECT * FROM panda_data WHERE alive = 'Y' AND child = null AND gender = 'M' AND can_make_baby = 'Y' AND baby_relapse_counter > 2");
			findMothers = conn.prepareStatement(
					"SELECT * FROM panda_data WHERE alive = 'Y' AND child = null AND gender = 'F' AND can_make_baby = 'Y' AND baby_relapse_counter > 2");
			findPanda = conn.prepareStatement("SELECT * FROM panda_data WHERE name = ?");
			getPandas = conn.prepareStatement("SELECT * FROM panda_data WHERE alive = 'Y'");
			addElephant = conn.prepareStatement(
					"INSERT INTO panda_data (age , name , weight , gender , trunk_length) VALUES (? , ? , ? , ? , ?)");
			updateElephant = conn.prepareStatement(
					"UPDATE elephant_data SET age = ? , alive = ? , happiness = ? WHERE name = ? AND trunk_length = ?");
			checkHowManyElephants = conn.prepareStatement("SELECT count(*) FROM elephant_data");
			getElephants = conn.prepareStatement("SELECT * FROM elephant_data WHERE alive = 'Y'");
			getElephantsByAge = conn.prepareStatement("SELECT * FROM elephant_data WHERE alive = 'Y' ORDER BY age");
			addPredator = conn.prepareStatement(
					"INSERT INTO panda_data (age , name , weight , gender , type) VALUES (? , ? , ? , ? , ?)");
			updatePredator = conn.prepareStatement(
					"UPDATE predator_data SET age = ? , alive = ? , happiness = ? WHERE name = ? AND weight = ? AND type = ?");
			getPredators = conn.prepareStatement("SELECT * FROM predator_data WHERE alive = 'Y'");
			addPenguin = conn.prepareStatement("INSERT INTO penguin_data (age , height, name) VALUES (? , ? , ?)");
			updatePenguin = conn.prepareStatement(
					"UPDATE penguin_data SET age = ? , alive = ? , happiness = ? WHERE name = ? AND height = ?");
			initializePenguins = conn.prepareStatement("SELECT * FROM penguin_data WHERE alive = 'Y'");
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	public static Employee checkEmployee(String password, String username) throws SQLException {
		checkEmployee.setString(1, password); // includes verifying input is legit
		ResultSet rs = checkEmployee.executeQuery();
		while (rs.next()) {
			Employee found = new Employee(rs.getString("id"), rs.getString("first_name"), rs.getString("last_name"),
					rs.getString("phone_number"), LocalDate.parse(rs.getString("date_of_birth")),
					rs.getInt("employee_number"), rs.getString("username"));
			if (username.compareTo(found.getUsername()) == 0) {
				return found;
			}
		}
		return null;
	}

	public static Employee findEmployee(String username) throws SQLException {
		findEmployee.setString(1, username); // includes verifying input is legit
		ResultSet rs = findEmployee.executeQuery();
		while (rs.next()) {
			Employee found = new Employee(rs.getString("id"), rs.getString("first_name"), rs.getString("last_name"),
					rs.getString("phone_number"), LocalDate.parse(rs.getString("date_of_birth")),
					rs.getInt("employee_number"), rs.getString("username"));
			return found;
		}
		return null;
	}

	public static Visitor findVisitor(String ID) throws SQLException {
		findVisitor.setString(1, ID); // includes verifying input is legit
		ResultSet rs = findVisitor.executeQuery();
		while (rs.next()) {
			Visitor found = new Visitor(rs.getString("id"), rs.getString("first_name"), rs.getString("last_name"),
					rs.getString("phone_number"), LocalDate.parse(rs.getString("date_of_birth")));
			found.setDistribution(rs.getString("distribute").charAt(0) == 'Y' ? true : false);
			return found;
		}
		return null;
	}

	public static ArrayList<Visitor> getAllObservers() throws SQLException {
		// TODO Auto-generated method stub
		ResultSet rs = getAllVisitors.executeQuery();
		ArrayList<Visitor> obs = new ArrayList<>();
		while (rs.next()) {
			if (rs.getString("distribute").charAt(0) == 'Y') {
				Visitor observer = new Visitor(rs.getString("id"), rs.getString("first_name"),
						rs.getString("last_name"), rs.getString("phone_number"),
						LocalDate.parse(rs.getString("date_of_birth")));
				obs.add(observer);
			}
		}
		return obs;
	}

	public static void addVisitor(Visitor newVisitor) throws SQLException {
		// TODO Auto-generated method stub
		addVisitor.setString(1, newVisitor.getID());
		addVisitor.setString(2, newVisitor.getFirstName());
		addVisitor.setString(3, newVisitor.getLastName());
		addVisitor.setString(4, newVisitor.getPhoneNumber());
		addVisitor.setDate(5, java.sql.Date.valueOf(newVisitor.getDateOfBirth()));
		System.out.println(newVisitor.isDistribution);
		addVisitor.setString(6, newVisitor.isDistribution ? "Y" : "N");
		addVisitor.execute();
	}

	public static ArrayList<Ticket> findTickets(String iD) throws SQLException {
		// TODO Auto-generated method stub
		findTickets.setString(1, iD);
		ResultSet rs = findTickets.executeQuery();
		ArrayList<Ticket> found = new ArrayList<>();
		while (rs.next()) {
			String type = checkType(rs.getString("type_code"));
			found.add(new Ticket(rs.getInt("number"), rs.getString("holder_id"), TicketOptionEnum.valueOf(type),
					LocalDate.parse(rs.getString("creation_date")), rs.getString("status"), price.getState()));
		}
		return found;
	}

	public static ArrayList<Ticket> findCanTickets(String myID) throws SQLException {
		// TODO Auto-generated method stub
		findTickets.setString(1, myID);
		ResultSet rs = findTickets.executeQuery();
		ArrayList<Ticket> found = new ArrayList<>();
		while (rs.next()) {
			String type = checkType(rs.getString("type_code"));
			Ticket current = new Ticket(rs.getInt("number"), rs.getString("holder_id"), TicketOptionEnum.valueOf(type),
					LocalDate.parse(rs.getString("creation_date")), rs.getString("status"), price.getState());
			if (current.isCanCancel())
				found.add(current);
		}
		return found;
	}

	public static ArrayList<Ticket> getTicketsByDate(LocalDate purID) throws SQLException {
		// TODO Auto-generated method stub
		ticketsByDate.setDate(1, java.sql.Date.valueOf(purID));
		ResultSet rs = ticketsByDate.executeQuery();
		ArrayList<Ticket> found = new ArrayList<>();
		while (rs.next()) {
			String type = checkType(rs.getString("type_code"));
			found.add(new Ticket(rs.getInt("number"), rs.getString("holder_id"), TicketOptionEnum.valueOf(type),
					LocalDate.parse(rs.getString("creation_date")), rs.getString("status"), price.getState()));
		}
		return found;
	}

	public static ArrayList<Ticket> fintActiveTickets(String myID) throws SQLException {
		// TODO Auto-generated method stub
		activeTickets.setString(1, myID);
		ResultSet rs = activeTickets.executeQuery();
		ArrayList<Ticket> found = new ArrayList<>();
		while (rs.next()) {
			String type = checkType(rs.getString("type_code"));
			found.add(new Ticket(rs.getInt("number"), rs.getString("holder_id"), TicketOptionEnum.valueOf(type),
					LocalDate.parse(rs.getString("creation_date")), rs.getString("status"), price.getState()));
		}
		return found;
	}

	public static void updateTicket(Ticket update) throws SQLException {
		// TODO Auto-generated method stub
		deletePreviousTicket.setInt(1, update.getNumber());
		deletePreviousTicket.execute();
		addTicket(update);
	}

	// Not Working!!!
	public static void addTicket(Ticket myTicket) throws SQLException {
		// TODO Auto-generated method stub
		addTicket.setInt(1, myTicket.getNumber());
		addTicket.setString(2, myTicket.getHolderID());
		addTicket.setString(3, myTicket.getType().getCode());
		addTicket.setInt(4, myTicket.getPrice());
		addTicket.setString(5, myTicket.isCanCancel() ? "Y" : "N");
		addTicket.setDate(6, java.sql.Date.valueOf(myTicket.getCreationDate()));
		addTicket.setDate(7, java.sql.Date.valueOf(myTicket.getExpirationDate()));
		addTicket.setString(8, myTicket.getStatus().toString().charAt(0) + "");
		addTicket.execute();
	}

	public static ArrayList<Entrance> findEntrances(String iD) throws SQLException {
		// TODO Auto-generated method stub
		findEntrances.setString(1, iD);
		ResultSet rs = findEntrances.executeQuery();
		ArrayList<Entrance> found = new ArrayList<>();
		while (rs.next()) {
			for (Ticket ticket : findTickets(rs.getString("holder_id"))) {
				if (ticket.getNumber() == rs.getInt("ticket_id")) {
					found.add(new Entrance(ticket, LocalDate.parse(rs.getString("entrance_date")),
							LocalTime.parse(rs.getString("entrance_time"))));
				}
			}
		}
		return found;
	}

	public static ArrayList<Entrance> entrancesByDate(LocalDate purID) throws SQLException {
		// TODO Auto-generated method stub
		entrancesByDate.setDate(1, java.sql.Date.valueOf(purID));
		ResultSet rs = entrancesByDate.executeQuery();
		ArrayList<Entrance> found = new ArrayList<>();
		while (rs.next()) {
			for (Ticket ticket : findTickets(rs.getString("holder_id"))) {
				if (ticket.getNumber() == rs.getInt("ticket_id")) {
					found.add(new Entrance(ticket, LocalDate.parse(rs.getString("entrance_date")),
							LocalTime.parse(rs.getString("entrance_time"))));
				}
			}
		}
		return found;
	}

	public static void addEntrance(Entrance entrance) throws SQLException {
		// TODO Auto-generated method stub
		addEntrance.setInt(1, entrance.getTicket().getNumber());
		addEntrance.setDate(2, java.sql.Date.valueOf(entrance.getEntranceDate()));
		addEntrance.setTime(3, new java.sql.Time(entrance.getEntranceTime().toNanoOfDay()));
		addEntrance.execute();
	}

	public static void addFish(Fish newFish) throws SQLException, NumberFormatException {
		String type = null;
		switch (newFish.getClass().getName()) {
		case "animals.AquariumFish":
			type = "A";
			break;
		case "animals.ClownFish":
			type = "C";
			break;
		case "animals.GoldFish":
			type = "G";
			break;
		}
		String[] colors = new String[newFish.getFishColors().size()];
		for (int i = 0; i < newFish.getFishColors().size(); i++) {
			colors[i] = newFish.getFishColors().get(i).toString();
		}
		addFish.setInt(1, newFish.getAge());
		addFish.setDouble(2, Double.parseDouble(formatter.format(newFish.getLength())));
		addFish.setArray(3, conn.createArrayOf("varchar", colors));
		addFish.setString(4, newFish.getFishPrint().toString());
		addFish.setString(5, type);
		addFish.executeUpdate();
	}

	public static String checkType(String code) {
		String type = "";
		switch (code.charAt(0)) {
		case 'Y':
			type += "Yearly_";
			switch (code.charAt(1)) {
			case 'A':
				type += "Adult";
				break;
			case 'K':
				type += "Kid";
				break;
			case 'S':
				if (code.length() < 2) {
					type += "Special";
				} else {
					type += "Student";
				}
				break;
			case 'C':
				switch (code.charAt(2)) {
				case '0':
					type += "Couple";
					break;
				case '1':
					type += "Couple_Plus_One";
					break;
				case '2':
					type += "Couple_Plus_Two";
					break;
				case '3':
					type += "Couple_Plus_Three";
					break;
				case '4':
					type += "Couple_Plus_Four";
					break;
				case '5':
					type += "Couple_Plus_Five";
					break;
				case '6':
					type += "Couple_Plus_Six";
					break;
				}
				break;
			case 'P':
				switch (code.charAt(2)) {
				case '1':
					type += "Parent_Plus_One";
					break;
				case '2':
					type += "Parent_Plus_Two";
					break;
				case '3':
					type += "Parent_Plus_Three";
					break;
				case '4':
					type += "Parent_Plus_Four";
					break;
				case '5':
					type += "Parent_Plus_Five";
					break;
				case '6':
					type += "Parent_Plus_Six";
					break;
				}
				break;
			}
			break;
		case 'B':
			type += "Basic_";
			switch (code.charAt(1)) {
			case 'A':
				type += "Adult";
				break;
			case 'K':
				type += "Kid";
				break;
			case 'S':
				type += "Special_And_Elderly";
				break;
			case 'D':
				type += "Disability";
				break;
			}
			break;
		}
		return type;
	}

	public void closeConnectionToDB() {
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void relapsePandas() throws SQLException {
		// TODO Auto-generated method stub
		relapsePandas.execute();
	}

	public static String checkNewPandaBirth() throws SQLException, PandaArrayFullException {
		// TODO Auto-generated method stub
		relapsePandas();
		ResultSet count = checkHowManyPandas.executeQuery();
		while (count.next()) {
			if (count.getInt("count") < 8) {
				ArrayList<Panda> mothers = findMothers(), fathers = findFathers();
				if (!mothers.isEmpty() && !fathers.isEmpty()) {
					Panda father = fathers.get(0);
					Panda mother = mothers.get(0);
					int random = Math.random() > 0.5 ? 1 : 0;
					GenderEnum newGender;
					double minWeight = 0;
					int maxWeight = 0;
					switch (random) {
					case 0:
						newGender = GenderEnum.MALE;
						minWeight = 0.5;
						maxWeight = 5;
						break;
					case 1:
						newGender = GenderEnum.FEMALE;
						minWeight = 0.2;
						maxWeight = 3;
						break;
					default:
						throw new IllegalArgumentException("Unexpected value: " + random);
					}
					double newWeight = minWeight + (Math.random() * maxWeight);
					int newAge = 0;
					String newName = Application.generateRandomName().toString().replace("_", " ");
					Panda child = new Panda(newName, newAge, newWeight, newGender);
					child.setFather(fathers.get(1));
					child.setMother(mothers.get(1));
					String output;
					addPanda(child);
					father.setChild(child);
					mother.setChild(child);
					father.babyRelapseCounter = 0;
					mother.babyRelapseCounter = 0;
					father.canMakeBaby = false;
					mother.canMakeBaby = false;
					updatePanda(father);
					updatePanda(mother);
					output = "The following panda was born: \n" + ANSI_RESET + child.toString(true) + "!\n";
					return output;
				}
				return " - No panda was born this year.\n";
			}
			return " - There is no more space for a newborn panda\n";
		}
		return null;
	}

	public static void updatePanda(Panda panda) throws SQLException {
		// TODO Auto-generated method stub
		updatePanda.setInt(1, panda.getAge());
		updatePanda.setString(2, panda.isAlive() ? "Y" : "N");
		updatePanda.setInt(3, panda.getHappiness());
		updatePanda.setString(4, panda.getChild() != null ? panda.getChild().getName() : null);
		updatePanda.setInt(5, panda.getBabyRelapseCounter());
		updatePanda.setString(6, panda.isCanMakeBaby() ? "Y" : "N");
		updatePanda.setString(7, panda.getName());
		updatePanda.execute();
	}

	public static void addPanda(Panda panda) throws PandaArrayFullException, SQLException {
		// TODO Auto-generated method stub
		ResultSet count = checkHowManyPandas.executeQuery();
		while (count.next()) {
			if (count.getInt("count") < 8) {
				addPanda.setInt(1, panda.getAge());
				addPanda.setString(2, panda.getName());
				addPanda.setDouble(3, panda.getWeight());
				addPanda.setString(4, panda.getGender() == GenderEnum.MALE ? "M" : "F");
				addPanda.setString(5, panda.getFather() != null ? panda.getFather().getName() : null);
				addPanda.setString(6, panda.getMother() != null ? panda.getMother().getName() : null);
				addPanda.setString(7, panda.getChild() != null ? panda.getChild().getName() : null);
				addPanda.setInt(8, panda.getBabyRelapseCounter());
				addPanda.setString(9, panda.isCanMakeBaby() ? "Y" : "N");
				addPanda.execute();
			} else {
				throw new PandaArrayFullException(
						ANSI_RED + ANSI_BOLD + "The Panda wasn't added to the zoo, the array is full" + ANSI_RESET);
			}
		}
	}

	private static ArrayList<Panda> findFathers() throws SQLException {
		// TODO Auto-generated method stub
		ArrayList<Panda> fathers = new ArrayList<>();
		ResultSet foundF = findFathers.executeQuery();
		while (foundF.next()) {
			fathers.add(new Panda(foundF.getString("name"), foundF.getInt("age"), foundF.getDouble("weight"),
					GenderEnum.MALE, foundF.getInt("baby_relapse_counter"), true, foundF.getInt("happiness"),
					findPanda(foundF.getString("father")), findPanda(foundF.getString("mother")),
					findPanda(foundF.getString("child"))));
		}
		return fathers;
	}

	private static Panda findPanda(String string) throws SQLException {
		// TODO Auto-generated method stub
		findPanda.setString(1, string);
		ResultSet found = findPanda.executeQuery();
		Panda re = null;
		while (found.next()) {
			re = new Panda(found.getString("name"), found.getInt("age"), found.getDouble("weight"), GenderEnum.MALE,
					found.getInt("baby_relapse_counter"), true, found.getInt("happiness"),
					findPanda(found.getString("father")), findPanda(found.getString("mother")),
					findPanda(found.getString("child")));
		}
		return re;
	}

	private static ArrayList<Panda> findMothers() throws SQLException {
		// TODO Auto-generated method stub
		ArrayList<Panda> mothers = new ArrayList<>();
		ResultSet foundM = findMothers.executeQuery();
		while (foundM.next()) {
			mothers.add(new Panda(foundM.getString("name"), foundM.getInt("age"), foundM.getDouble("weight"),
					GenderEnum.MALE, foundM.getInt("baby_relapse_counter"), true, foundM.getInt("happiness"),
					findPanda(foundM.getString("father")), findPanda(foundM.getString("mother")),
					findPanda(foundM.getString("child"))));
		}
		return mothers;
	}

	public static ArrayList<Panda> getPandas() throws SQLException {
		// TODO Auto-generated method stub
		ResultSet pandas = getPandas.executeQuery();
		ArrayList<Panda> re = new ArrayList<>();
		int i = 0;
		while (pandas.next()) {
			if (i < 8)
				re.add(new Panda(pandas.getString("name"), pandas.getInt("age"), pandas.getDouble("weight"),
						GenderEnum.MALE, pandas.getInt("baby_relapse_counter"),
						pandas.getString("can_make_baby").compareTo("Y") == 0 ? true : false,
						pandas.getInt("happiness"), findPanda(pandas.getString("father")),
						findPanda(pandas.getString("mother")), findPanda(pandas.getString("child"))));
			i++;
		}
		return re;
	}

	public static LinkedList<Elephant> getHerd() throws SQLException {
		// TODO Auto-generated method stub
		LinkedList<Elephant> herd = new LinkedList<>();
		ResultSet elephants;
		if (elephantOrder == "age") {
			elephants = getElephantsByAge.executeQuery();
			while (elephants.next()) {
				herd.add(new Elephant(elephants.getString("name"), elephants.getInt("age"),
						elephants.getInt("happiness"),
						elephants.getString("gender").compareTo("M") == 0 ? GenderEnum.MALE : GenderEnum.FEMALE,
						elephants.getDouble("weight"), elephants.getDouble("trunk_length")));
			}
		} else {
			elephants = getElephants.executeQuery();
			while (elephants.next()) {
				herd.add(new Elephant(elephants.getString("name"), elephants.getInt("age"),
						elephants.getInt("happiness"),
						elephants.getString("gender").compareTo("M") == 0 ? GenderEnum.MALE : GenderEnum.FEMALE,
						elephants.getDouble("weight"), elephants.getDouble("trunk_length")));
			}
		}
		return herd;
	}

	public static void addElephant(Elephant elephant) throws SQLException {
		// TODO Auto-generated method stub
		addElephant.setInt(1, elephant.getAge());
		addElephant.setString(2, elephant.getName());
		addElephant.setDouble(3, elephant.getWeight());
		addElephant.setString(4, elephant.getGender() == GenderEnum.MALE ? "M" : "F");
		addElephant.setDouble(5, elephant.getTrunkLength());
		addElephant.execute();
	}

	public static int howManyEkephants() throws SQLException {
		// TODO Auto-generated method stub
		ResultSet count = checkHowManyElephants.executeQuery();
		while (count.next()) {
			return count.getInt("count");
		}
		return 0;
	}

	public static void setElephantOrder(String string) {
		// TODO Auto-generated method stub
		elephantOrder = string;
	}

	public static ArrayList<Fish> getFish() throws SQLException {
		// TODO Auto-generated method stub
		ArrayList<Fish> re = new ArrayList<>();
		ResultSet fish = getFish.executeQuery();
		Array co;
		ResultSet c;
		ArrayList<FishColorEnum> colors = new ArrayList<>();
		while (fish.next()) {
			switch (fish.getString("type")) {
			case "A":
				co = fish.getArray("color");
				c = co.getResultSet();
				colors = new ArrayList<>();
				while (c.next()) {
					colors.add(FishColorEnum.valueOf(c.getString(2)));
				}
				re.add(new AquariumFish(fish.getInt("age"), fish.getInt("happiness"), fish.getDouble("length"),
						FishPrintEnum.valueOf(fish.getString("print")), colors));
				break;
			case "C":
				re.add(new ClownFish(fish.getInt("age"), fish.getInt("happiness"), fish.getDouble("length")));
				break;
			case "G":
				co = fish.getArray("color");
				c = co.getResultSet();
				colors = new ArrayList<>();
				while (c.next()) {
					colors.add(FishColorEnum.valueOf(c.getString(2)));
				}
				re.add(new GoldFish(fish.getInt("age"), fish.getInt("happiness"), fish.getDouble("length"), colors));
				break;
			}

		}
		return re;
	}

	public static void addPredator(Predator newPredator) throws SQLException {
		// TODO Auto-generated method stub
		String type = null;
		switch (newPredator.getClass().getName()) {
		case "animals.Tiger":
			type = "T";
			break;
		case "animals.Lion":
			type = "L";
			break;
		}
		addPredator.setInt(1, newPredator.getAge());
		addPredator.setString(2, newPredator.getName());
		addPredator.setDouble(3, newPredator.getWeight());
		addPredator.setString(4, newPredator.getGender() == GenderEnum.MALE ? "M" : "F");
		addPredator.setString(5, type);
		addPredator.execute();
	}

	public static ArrayList<Predator> getPredators() throws SQLException {
		// TODO Auto-generated method stub
		ArrayList<Predator> pre = new ArrayList<>();
		ResultSet predators = getPredators.executeQuery();
		while (predators.next()) {
			switch (predators.getString("type")) {
			case "T":
				pre.add(new Tiger(predators.getString("name"), predators.getInt("age"), predators.getInt("happiness"),
						predators.getDouble("weight"),
						predators.getString("gender").compareTo("M") == 0 ? GenderEnum.MALE : GenderEnum.FEMALE));
				break;
			case "L":
				pre.add(new Lion(predators.getString("name"), predators.getInt("age"), predators.getInt("happiness"),
						predators.getDouble("weight"),
						predators.getString("gender").compareTo("M") == 0 ? GenderEnum.MALE : GenderEnum.FEMALE));
				break;
			}

		}
		return pre;
	}

	public static void addPenguin(Penguin penguin) throws SQLException {
		// TODO Auto-generated method stub
		addPenguin.setInt(1, penguin.getAge());
		addPenguin.setDouble(2, penguin.getHeight());
		addPenguin.setString(3, penguin.getName());
		addPenguin.execute();
	}

	public static void updatePenguin(Penguin penguin) throws SQLException {
		// TODO Auto-generated method stub
		updatePenguin.setInt(1, penguin.getAge());
		updatePenguin.setString(2, penguin.isAlive() ? "Y" : "N");
		updatePenguin.setInt(3, penguin.getHappiness());
		updatePenguin.setString(4, penguin.getName());
		updatePenguin.setDouble(5, penguin.getHeight());
		updatePenguin.execute();
	}

	public static void updateFish(Fish Fish) throws SQLException {
		// TODO Auto-generated method stub
		updateFish.setInt(1, Fish.getAge());
		updateFish.setString(2, Fish.isAlive() ? "Y" : "N");
		updateFish.setInt(3, Fish.getHappiness());
		updateFish.setDouble(4, Fish.getLength());
		updateFish.setString(5, Fish.getFishPrint().toString());
		updateFish.execute();
	}

	public static void updateElephant(Elephant elephant) throws SQLException {
		// TODO Auto-generated method stub
		updateElephant.setInt(1, elephant.getAge());
		updateElephant.setString(2, elephant.isAlive() ? "Y" : "N");
		updateElephant.setInt(3, elephant.getHappiness());
		updateElephant.setString(4, elephant.getName());
		updateElephant.setDouble(5, elephant.getTrunkLength());
		updateElephant.execute();
	}

	public static void updatePredator(Predator predator) throws SQLException {
		// TODO Auto-generated method stub
		updatePredator.setInt(1, predator.getAge());
		updatePredator.setString(2, predator.isAlive() ? "Y" : "N");
		updatePredator.setInt(3, predator.getHappiness());
		updatePredator.setString(4, predator.getName());
		updatePredator.setDouble(5, predator.getWeight());
		updatePredator.setString(6, predator.getClass().getName() == "animals.Tiger" ? "T" : "L");
		updatePredator.execute();
	}

	public static void initializePenguins(PenguinLine penguinLine, PenguinLineNode root) throws SQLException {
		// TODO Auto-generated method stub
		ResultSet penguins = initializePenguins.executeQuery();
		while (penguins.next()) {
			penguinLine.initialize(new Penguin(penguins.getDouble("height"), penguins.getInt("age"),
					penguins.getString("name"), (penguins.getString("alive").compareTo("Y") == 0 ? true : false),
					penguins.getInt("happiness")));
			System.out.println(
					penguins.getDouble("height") + " " + penguins.getInt("age") + " " + penguins.getString("name") + " "
							+ (penguins.getString("alive").compareTo("Y") == 0 ? "true" : "false") + " "
							+ penguins.getInt("happiness"));
		}
	}
}
