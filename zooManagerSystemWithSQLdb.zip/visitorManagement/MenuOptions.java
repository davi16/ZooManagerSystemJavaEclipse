package visitorManagement;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.sql.SQLException;

public interface MenuOptions {
	// This interface contains all available options for zoo employee interactions with the system
	public void purchaseTicket();
	public void cancelTicket(String visiID) throws SQLException;
	public void searchTicket(String visiID) throws SQLException;
	public void printPurchaseHistory(String type);
	public void parkEntrance(String visiID) throws SQLException;
	public void printEntranceHistory(String type);
	public void mailingSystem(int price);
	public void exit();
}
