package visitorManagement;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import javax.swing.*;

import dataBases.*;

import humanRoles.Employee;
import humanRoles.Visitor;
import vistorDistributionGroup.VisitorDiscountDistribution;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.*;
import java.lang.Exception;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

//class extends JFrame to create a window where our component add  
//class implements ActionListener to perform an action on button click  
public class EmployeeLoginForm extends JFrame implements ActionListener {
	/**
	 * 
	 */
	public static LocalDate loginDate;
	public static LocalTime loginTime;
	public static int cash = 0;
	public static int card = 0;
	public static String userValue;

	private static final long serialVersionUID = 1L;

	private static EmployeeLoginForm systemLogin;

	// initialize button, panel, label, and text field
	JButton check;
	JPanel login;
	JLabel username, password, request, warning;
	final JTextField userText, passText;

	public synchronized static EmployeeLoginForm getSystemLogin() throws SQLException {
		if (systemLogin == null) {
			startBasicInfo();
			systemLogin = new EmployeeLoginForm();
		} else
			systemLogin = new EmployeeLoginForm();
		return systemLogin;
	}

	// private constructor
	private EmployeeLoginForm() {
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setAlwaysOnTop(true);
		setSize(400, 250);
		setLocationByPlatform(true);
		setVisible(true);
		setLocationRelativeTo(null);
		setTitle("Login");
		setResizable(false);

		login = new JPanel(null);
		add(login);

		request = new JLabel();
		request.setText("Please enter your credentials:");
		request.setBounds(48, 10, 220, 30);
		login.add(request);

		username = new JLabel();
		username.setText("Enter Username: ");
		username.setBounds(48, 57, 110, 30);
		login.add(username);

		userText = new JTextField(15);
		userText.setBounds(150, 58, 200, 30);
		login.add(userText);

		password = new JLabel();
		password.setText("Enter Password: ");
		password.setBounds(48, 100, 110, 30);
		login.add(password);

		passText = new JPasswordField(15);
		passText.setBounds(150, 100, 200, 30);
		login.add(passText);

		check = new JButton("Ok");
		check.setBounds(150, 150, 100, 30);
		check.setBorder(BorderFactory.createEtchedBorder());
		check.addActionListener(this);
		getRootPane().setDefaultButton(check);
		login.add(check);
		repaint();
	}

	private static void startBasicInfo() throws SQLException {
		ArrayList<Visitor> obs = jdbc.getAllObservers();
		for (Visitor current : obs) {
			VisitorDiscountDistribution.getDistribution().addObserver(current);
		}
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == check) {
			userValue = userText.getText();
			String passValue = passText.getText();
			try {
				Employee found = jdbc.checkEmployee(passValue , userValue);
				if (found != null) {
					request.setText("The authentication was succesesful");
					loginDate = LocalDate.now();
					loginTime = LocalTime.now();
					dispose();
					// create instance of the VisitorManagmentMenu
					new VisitorManagementMenu();
					return;
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(null, ex.getMessage());
			}	
			passText.requestFocusInWindow();
			passText.setText("");
			Toolkit.getDefaultToolkit().beep();
			request.setText("Wrong username/password");
			request.setForeground(Color.RED);
			repaint();
		}
	}
}