package visitorManagement;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

//import required classes and packages  
import javax.swing.*;

import dataBases.jdbc;
import parkEntrance.EntrancePanel;
import parkEntrance.ParkEntrancePanel;
import parkEntranceHistory.EHistoryPanel;
import parkEntranceHistory.EntranceHistoryByDatePanel;
import parkEntranceHistory.EntranceHistoryByIDPanel;
import ticketCancel.*;
import ticketHistory.*;
import ticketPurchase.*;
import ticketSearch.*;
import visitorPayment.CashRegisterPanel;
import vistorDistributionGroup.MailingPanel;
import vistorDistributionGroup.NoChangePanel;
import vistorDistributionGroup.VisitorDiscountDistribution;
import vistorDistributionGroup.VisitorMailingPanel;

import java.awt.event.KeyEvent;
import java.sql.SQLException;

//create VisitorManagmentMenu class to create a new page on which user will navigate  
public class VisitorManagementMenu extends JFrame implements MenuOptions {
	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;
	JPanel purchase = new PurchasePanel(this);
	JPanel cancel = new CancelPanel(this);
	JPanel search = new SearchPanel(this);
	JPanel history = new HistoryPanel(this);
	JPanel entrance = new EntrancePanel(this);
	JPanel entranceHistory = new EHistoryPanel(this);
	JPanel mailing = new MailingPanel(this);
	JPanel cashRegister;
	JPanel exit = new ExitPanel(this);

	// constructor
	public VisitorManagementMenu() throws SQLException {
		cashRegister = new CashRegisterPanel(this);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		setSize(1200, 600);
		setLocationByPlatform(true);
		setAlwaysOnTop(true);
		setVisible(true);
		setLocationRelativeTo(null);
		add(createTabs());
		setTitle("VISITOR MANAGMENT SYSTEM"); // set title to the login form
		setResizable(false);
	}

	public JTabbedPane createTabs() {
		JTabbedPane tabbedPane = new JTabbedPane();

		tabbedPane.addTab("Purchase a ticket", purchase);
		tabbedPane.addTab("Cancel a ticket", cancel);
		tabbedPane.addTab("Search ticket", search);
		tabbedPane.addTab("Show purchase history", history);
		tabbedPane.addTab("Zoo entrance", entrance);
		tabbedPane.addTab("Show entrance history", entranceHistory);
		tabbedPane.addTab("Mailing system", mailing);
		tabbedPane.addTab("Cash Register", cashRegister);
		tabbedPane.addTab("Exit system", exit);

		tabbedPane.setMnemonicAt(0, KeyEvent.VK_1);
		tabbedPane.setMnemonicAt(1, KeyEvent.VK_2);
		tabbedPane.setMnemonicAt(2, KeyEvent.VK_3);
		tabbedPane.setMnemonicAt(3, KeyEvent.VK_4);
		tabbedPane.setMnemonicAt(4, KeyEvent.VK_5);
		tabbedPane.setMnemonicAt(5, KeyEvent.VK_6);
		tabbedPane.setMnemonicAt(6, KeyEvent.VK_7);
		tabbedPane.setMnemonicAt(7, KeyEvent.VK_8);

		return tabbedPane;
	}

	@Override
	public void purchaseTicket() {
		purchase.add(new TicketPurchasePanel(this));
	}

	@Override
	public void cancelTicket(String visiID) throws SQLException {
		repaint();
		cancel.add(new TicketCancelPanel(this, visiID));
	}

	@Override
	public void searchTicket(String visiID) throws SQLException {
		repaint();
		search.add(new TicketSearchPanel(this, visiID));
	}

	@Override
	public void printPurchaseHistory(String type) {
		repaint();
		if (type == "ID")
			history.add(add(new TicketHistoryByIDPanel(this)));
		if (type == "Date")
			history.add(add(new TicketHistoryByDatePanel(this)));
	}

	@Override
	public void parkEntrance(String visiID) throws SQLException {
		repaint();
		entrance.add(new ParkEntrancePanel(this, visiID));
	}

	@Override
	public void printEntranceHistory(String type) {
		repaint();
		if (type == "ID")
			entranceHistory.add(add(new EntranceHistoryByIDPanel(this)));
		if (type == "Date")
			entranceHistory.add(add(new EntranceHistoryByDatePanel(this)));
	}

	@Override
	public void mailingSystem(int discount) {
		repaint();
		if (jdbc.price.getState() != discount) {
			VisitorDiscountDistribution.getDistribution().setDiscount(discount);
			if (VisitorDiscountDistribution.getDistribution().isChanged())
				mailing.add(new VisitorMailingPanel(this, discount));
			else
				mailing.add(new NoChangePanel(this));
		}
		else
			mailing.add(new NoChangePanel(this));
	}

	@Override
	public void exit() {
		dispose();
	}

}
