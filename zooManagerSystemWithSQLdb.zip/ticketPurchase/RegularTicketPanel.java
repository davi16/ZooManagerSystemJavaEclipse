package ticketPurchase;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Random;
import javax.swing.*;

import dataBases.*;
import ticket.Ticket;
import ticket.TicketOptionEnum;
import visitorManagement.VisitorManagementMenu;
import visitorPayment.PaymentPanel;

public class RegularTicketPanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JCheckBox adult, kid, psse, disabled;
	JButton accept, back;
	int price = 0;
	VisitorManagementMenu myMenu;

	RegularTicketPanel(VisitorManagementMenu menu) {
		myMenu = menu;
		PurchasePanel.ticketCode = "B";
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		JLabel choose = new JLabel("What are you?");
		choose.setMaximumSize(new Dimension(300, 30));

		adult = new JCheckBox("Adult");
		adult.setMaximumSize(new Dimension(300, 30));
		adult.addActionListener(this);

		kid = new JCheckBox("Kid");
		kid.setMaximumSize(new Dimension(300, 30));
		kid.addActionListener(this);

		psse = new JCheckBox("Police/Soldier/Student/Elderly");
		psse.setMaximumSize(new Dimension(300, 30));
		psse.addActionListener(this);

		disabled = new JCheckBox("Disabled");
		disabled.setMaximumSize(new Dimension(300, 30));
		disabled.addActionListener(this);

		add(choose);
		add(adult);
		add(kid);
		add(psse);
		add(disabled);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == back) {
			myMenu.dispose();
			try {
				myMenu = new VisitorManagementMenu();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			myMenu.repaint();
			return;
		}
		if (e.getSource() == accept) {
			removeAll();
			add(new PaymentPanel(myMenu, price));
			myMenu.repaint();
			return;
		}

		if (e.getSource() == adult) {
			PurchasePanel.ticketCode += "A";
		}
		if (e.getSource() == kid) {
			PurchasePanel.ticketCode += "K";
		}
		if (e.getSource() == psse) {
			PurchasePanel.ticketCode += "S";
		}
		if (e.getSource() == disabled) {
			PurchasePanel.ticketCode += "D";
		}

		removeAll();
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setAlignmentX(CENTER_ALIGNMENT);

		for (TicketOptionEnum ticket : TicketOptionEnum.values()) {
			if (ticket.getCode().equals(PurchasePanel.ticketCode)) {
				PurchasePanel.myTicketType = ticket;
				price = jdbc.price.currentPrice(ticket);
			}
		}

		JLabel priceLabel = new JLabel("Your price is: " + price);
		priceLabel.setAlignmentX(CENTER_ALIGNMENT);
		add(priceLabel);

		Random ran = new Random();
		Ticket myTicket = new Ticket(ran.nextInt(90000) + 10000, PurchasePanel.buyer.getID(), PurchasePanel.myTicketType, jdbc.price.getState());
		try {
			jdbc.addTicket(myTicket);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		JLabel ticketLabel = new JLabel(myTicket.toString());
		ticketLabel.setAlignmentX(CENTER_ALIGNMENT);
		add(ticketLabel);

		accept = new JButton("Make payment");
		accept.setAlignmentX(CENTER_ALIGNMENT);
		accept.setBorder(BorderFactory.createEtchedBorder());
		accept.setMaximumSize(new Dimension(100, 30));
		accept.addActionListener(this);
		add(accept);
		
		back = new JButton("Cancel");
		back.setAlignmentX(CENTER_ALIGNMENT);
		back.setBorder(BorderFactory.createEtchedBorder());
		back.setMaximumSize(new Dimension(100, 30));
		back.addActionListener(this);
		add(back);

		myMenu.repaint();
	}

}
