package ticketPurchase;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.*;

import dataBases.*;
import humanRoles.Visitor;
import ticket.TicketOptionEnum;
import visitorManagement.VisitorManagementMenu;

public class PurchasePanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JTextField visitorID;
	JButton purchaseButton, no, yes;
	static String ticketCode;
	static TicketOptionEnum myTicketType;
	static Visitor buyer;
	JPanel inside = new JPanel();
	JLabel warning;
	VisitorManagementMenu myMenu;

	public PurchasePanel(VisitorManagementMenu menu) {
		myMenu = menu;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		add(Box.createRigidArea(new Dimension(0, 10)));

		inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
		inside.setMaximumSize(new Dimension(300, 30));
		inside.setAlignmentX(CENTER_ALIGNMENT);
		add(inside);

		JLabel visitorId = new JLabel("Enter visitor ID: ");
		inside.add(visitorId);

		visitorID = new JTextField(9); // set length of the text
		visitorID.setMaximumSize(new Dimension(150, 30));
		inside.add(visitorID);

		purchaseButton = new JButton("Ok");
		purchaseButton.setBorder(BorderFactory.createEtchedBorder());
		purchaseButton.setMaximumSize(new Dimension(100, 30));
		purchaseButton.addActionListener(this);
		inside.add(purchaseButton);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == yes) {
			removeAll();
			add(new AddVisitorPanel(myMenu));
		} else if (e.getSource() == purchaseButton) {
			String visiID = checkID(visitorID.getText()); // get user entered username from textField1
			buyer = null;
			Visitor found;
			try {
				found = jdbc.findVisitor(visiID);
				if (found != null) {
					removeAll();
					buyer = found;
					add(Box.createRigidArea(new Dimension(0, 10)));
					JLabel visitorInfo = new JLabel("Purchasing for: " + buyer.toString());
					visitorInfo.setAlignmentX(CENTER_ALIGNMENT);
					add(visitorInfo);
					add(Box.createRigidArea(new Dimension(0, 50)));
					addTicketToVisitor();
					myMenu.repaint();
					return;
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			JLabel visitorInfo = new JLabel("Would you like to open new visitor file?");
			visitorInfo.setMaximumSize(new Dimension(250, 30));
			visitorInfo.setAlignmentX(CENTER_ALIGNMENT);
			add(visitorInfo);

			JPanel inside = new JPanel();
			inside.setLayout(new BoxLayout(inside, BoxLayout.X_AXIS));
			inside.setAlignmentX(CENTER_ALIGNMENT);
			inside.setMaximumSize(new Dimension(200, 30));

			yes = new JButton("Yes");
			yes.setBorder(BorderFactory.createEtchedBorder());
			yes.setMaximumSize(new Dimension(100, 30));
			yes.setAlignmentX(CENTER_ALIGNMENT);
			yes.addActionListener(this);

			no = new JButton("No");
			no.setBorder(BorderFactory.createEtchedBorder());
			no.setMaximumSize(new Dimension(100, 30));
			no.setAlignmentX(CENTER_ALIGNMENT);
			no.addActionListener(this);

			inside.add(yes);
			inside.add(no);

			add(inside);

			myMenu.repaint();
		}
		if (e.getSource() == no)

		{
			myMenu.dispose();
			try {
				myMenu = new VisitorManagementMenu();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			myMenu.repaint();
			return;
		}

	}

	public void addTicketToVisitor() {
		ticketCode = null;
		myTicketType = null;
		add(new TicketPurchasePanel(myMenu));
	}

	public String checkID(String ID) {
		System.out.println(ID);
		try {
			if (!ID.matches("[0-9]+"))
				throw new IllegalCallerException();
			if (ID.length() > 9) {
				System.out.println(ID);
				throw new RuntimeException();
			}
			if (jdbc.findVisitor(ID) == null)
				throw new Exception();
			return ID;
		} catch (IllegalCallerException e) {
			if (warning == null) {
				warning = new JLabel("The ID contains illigal characters");
				warning.setForeground(Color.RED);
				warning.setAlignmentX(CENTER_ALIGNMENT);
				add(warning);
				myMenu.repaint();
				warning = null;
			}
		} catch (RuntimeException b) {
			if (warning == null) {
				warning = new JLabel("The ID is too long");
				warning.setForeground(Color.RED);
				warning.setAlignmentX(CENTER_ALIGNMENT);
				add(warning);
				myMenu.repaint();
				warning = null;
			}
		} catch (Exception a) {
			if (warning == null) {
				warning = new JLabel("The visitor is not in database");
				warning.setForeground(Color.RED);
				warning.setAlignmentX(CENTER_ALIGNMENT);
				add(warning);
				myMenu.repaint();
				warning = null;
				return ID;
			}
		}
		return null;
	}

}
