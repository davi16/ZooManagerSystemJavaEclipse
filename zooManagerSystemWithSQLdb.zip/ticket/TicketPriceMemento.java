package ticket;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public class TicketPriceMemento implements Memento{

	private TicketPrice price;
	private int state;

	public TicketPriceMemento(TicketPrice ticketPrice, int state) {
		this.price = ticketPrice;
		this.state = state;
	}
	
	public TicketPrice getPrice() {
		return price;
	}

	public void setPrice(TicketPrice price) {
		this.price = price;
	}

	public int getState() {
		return state * 10 ;
	}

	public void setState(int state) {
		this.state = state;
	}
	
	@Override
	public void restoreMemento() {
		price.setState(state);
	}
	
	@Override
	public String toString() {
		return "TicketPriceMemento created";
	}
}
