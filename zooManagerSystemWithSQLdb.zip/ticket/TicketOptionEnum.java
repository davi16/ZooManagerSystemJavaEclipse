package ticket;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public enum TicketOptionEnum{
	// This enum contains all Tickets available for a Visitor
	Basic_Adult(71, "BA"), Basic_Kid(54, "BK"), Basic_Special_And_Elderly(54, "BS"), Basic_Disability(35, "BD"),
	Yearly_Kid(245, "YK"), Yearly_Adult(330, "YA"), Yearly_Student(245, "YST"), Yearly_Special(245, "YS"),
	Yearly_Couple(570, "YC0"), Yearly_Couple_Plus_One(690, "YC1"), Yearly_Couple_Plus_Two(750, "YC2"),
	Yearly_Couple_Plus_Three(810, "YC3"), Yearly_Couple_Plus_Four(860, "YC4"), Yearly_Couple_Plus_Five(915, "YC5"),
	Yearly_Couple_Plus_Six(970, "YC6"), Yearly_Parent_Plus_One(515, "YP1"), Yearly_Parent_Plus_Two(665, "YP2"),
	Yearly_Parent_Plus_Three(735, "YP3"), Yearly_Parent_Plus_Four(755, "YP4"), Yearly_Parent_Plus_Five(795, "YP5"),
	Yearly_Parent_Plus_Six(830, "YP6");

	private int price;
	private String code;

	private TicketOptionEnum(int price, String code) {
		// Constructor
		this.price = price;
		this.code = code;
	}

	public int getPrice() {
		return price;
	}

	public String getCode() {
		return code;
	}

}
