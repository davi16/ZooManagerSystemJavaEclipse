package ticket;
//Students submitting: Kristina goldin 317958700, David Ben Yaacov 320759921

public class TicketPrice implements Originator{
	
	private int state;

	public TicketPrice() {
		this.setState(0);
	}
	
	public int getState() {
		return state * 10;	
	}

	public void setState(int state) {
		this.state = state;
	}
	
	public int currentPrice(TicketOptionEnum price) {
		return removePercent(price.getPrice());
	}
	
	public int removePercent(int price) {
		price -= ((double)price / 100) * getState();
		return price;
	}
	
	@Override
	public TicketPriceMemento saveMemento() {
		return new TicketPriceMemento(this , state);
	}
	
	@Override
	public String toString() {
		return "TicketPrice [state=" + state + "]";
	}
}
